goog.provide('shadow.dom');
goog.require('cljs.core');
goog.require('goog.dom');
goog.require('goog.dom.forms');
goog.require('goog.dom.classlist');
goog.require('goog.style');
goog.require('goog.style.transition');
goog.require('goog.string');
goog.require('clojure.string');
goog.require('cljs.core.async');
shadow.dom.transition_supported_QMARK_ = (((typeof window !== 'undefined'))?goog.style.transition.isSupported():null);

/**
 * @interface
 */
shadow.dom.IElement = function(){};

shadow.dom._to_dom = (function shadow$dom$_to_dom(this$){
if((((!((this$ == null)))) && ((!((this$.shadow$dom$IElement$_to_dom$arity$1 == null)))))){
return this$.shadow$dom$IElement$_to_dom$arity$1(this$);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (shadow.dom._to_dom[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4434__auto__.call(null,this$));
} else {
var m__4431__auto__ = (shadow.dom._to_dom["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4431__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IElement.-to-dom",this$);
}
}
}
});


/**
 * @interface
 */
shadow.dom.SVGElement = function(){};

shadow.dom._to_svg = (function shadow$dom$_to_svg(this$){
if((((!((this$ == null)))) && ((!((this$.shadow$dom$SVGElement$_to_svg$arity$1 == null)))))){
return this$.shadow$dom$SVGElement$_to_svg$arity$1(this$);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (shadow.dom._to_svg[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4434__auto__.call(null,this$));
} else {
var m__4431__auto__ = (shadow.dom._to_svg["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4431__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("SVGElement.-to-svg",this$);
}
}
}
});

shadow.dom.lazy_native_coll_seq = (function shadow$dom$lazy_native_coll_seq(coll,idx){
if((idx < coll.length)){
return (new cljs.core.LazySeq(null,(function (){
return cljs.core.cons((coll[idx]),(function (){var G__52608 = coll;
var G__52609 = (idx + (1));
return (shadow.dom.lazy_native_coll_seq.cljs$core$IFn$_invoke$arity$2 ? shadow.dom.lazy_native_coll_seq.cljs$core$IFn$_invoke$arity$2(G__52608,G__52609) : shadow.dom.lazy_native_coll_seq.call(null,G__52608,G__52609));
})());
}),null,null));
} else {
return null;
}
});

/**
* @constructor
 * @implements {cljs.core.IIndexed}
 * @implements {cljs.core.ICounted}
 * @implements {cljs.core.ISeqable}
 * @implements {cljs.core.IDeref}
 * @implements {shadow.dom.IElement}
*/
shadow.dom.NativeColl = (function (coll){
this.coll = coll;
this.cljs$lang$protocol_mask$partition0$ = 8421394;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
shadow.dom.NativeColl.prototype.cljs$core$IDeref$_deref$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return self__.coll;
});

shadow.dom.NativeColl.prototype.cljs$core$IIndexed$_nth$arity$2 = (function (this$,n){
var self__ = this;
var this$__$1 = this;
return (self__.coll[n]);
});

shadow.dom.NativeColl.prototype.cljs$core$IIndexed$_nth$arity$3 = (function (this$,n,not_found){
var self__ = this;
var this$__$1 = this;
var or__4131__auto__ = (self__.coll[n]);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return not_found;
}
});

shadow.dom.NativeColl.prototype.cljs$core$ICounted$_count$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return self__.coll.length;
});

shadow.dom.NativeColl.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return shadow.dom.lazy_native_coll_seq(self__.coll,(0));
});

shadow.dom.NativeColl.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL;

shadow.dom.NativeColl.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return self__.coll;
});

shadow.dom.NativeColl.getBasis = (function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"coll","coll",-1006698606,null)], null);
});

shadow.dom.NativeColl.cljs$lang$type = true;

shadow.dom.NativeColl.cljs$lang$ctorStr = "shadow.dom/NativeColl";

shadow.dom.NativeColl.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"shadow.dom/NativeColl");
});

/**
 * Positional factory function for shadow.dom/NativeColl.
 */
shadow.dom.__GT_NativeColl = (function shadow$dom$__GT_NativeColl(coll){
return (new shadow.dom.NativeColl(coll));
});

shadow.dom.native_coll = (function shadow$dom$native_coll(coll){
return (new shadow.dom.NativeColl(coll));
});
shadow.dom.dom_node = (function shadow$dom$dom_node(el){
if((el == null)){
return null;
} else {
if((((!((el == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === el.shadow$dom$IElement$))))?true:false):false)){
return el.shadow$dom$IElement$_to_dom$arity$1(null);
} else {
if(typeof el === 'string'){
return document.createTextNode(el);
} else {
if(typeof el === 'number'){
return document.createTextNode(cljs.core.str.cljs$core$IFn$_invoke$arity$1(el));
} else {
return el;

}
}
}
}
});
shadow.dom.query_one = (function shadow$dom$query_one(var_args){
var G__52635 = arguments.length;
switch (G__52635) {
case 1:
return shadow.dom.query_one.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.query_one.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.query_one.cljs$core$IFn$_invoke$arity$1 = (function (sel){
return document.querySelector(sel);
});

shadow.dom.query_one.cljs$core$IFn$_invoke$arity$2 = (function (sel,root){
return shadow.dom.dom_node(root).querySelector(sel);
});

shadow.dom.query_one.cljs$lang$maxFixedArity = 2;

shadow.dom.query = (function shadow$dom$query(var_args){
var G__52643 = arguments.length;
switch (G__52643) {
case 1:
return shadow.dom.query.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.query.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.query.cljs$core$IFn$_invoke$arity$1 = (function (sel){
return (new shadow.dom.NativeColl(document.querySelectorAll(sel)));
});

shadow.dom.query.cljs$core$IFn$_invoke$arity$2 = (function (sel,root){
return (new shadow.dom.NativeColl(shadow.dom.dom_node(root).querySelectorAll(sel)));
});

shadow.dom.query.cljs$lang$maxFixedArity = 2;

shadow.dom.by_id = (function shadow$dom$by_id(var_args){
var G__52649 = arguments.length;
switch (G__52649) {
case 2:
return shadow.dom.by_id.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return shadow.dom.by_id.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.by_id.cljs$core$IFn$_invoke$arity$2 = (function (id,el){
return shadow.dom.dom_node(el).getElementById(id);
});

shadow.dom.by_id.cljs$core$IFn$_invoke$arity$1 = (function (id){
return document.getElementById(id);
});

shadow.dom.by_id.cljs$lang$maxFixedArity = 2;

shadow.dom.build = shadow.dom.dom_node;
shadow.dom.ev_stop = (function shadow$dom$ev_stop(var_args){
var G__52654 = arguments.length;
switch (G__52654) {
case 1:
return shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$1 = (function (e){
if(cljs.core.truth_(e.stopPropagation)){
e.stopPropagation();

e.preventDefault();
} else {
e.cancelBubble = true;

e.returnValue = false;
}

return e;
});

shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$2 = (function (e,el){
shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$1(e);

return el;
});

shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$4 = (function (e,el,scope,owner){
shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$1(e);

return el;
});

shadow.dom.ev_stop.cljs$lang$maxFixedArity = 4;

/**
 * check wether a parent node (or the document) contains the child
 */
shadow.dom.contains_QMARK_ = (function shadow$dom$contains_QMARK_(var_args){
var G__52663 = arguments.length;
switch (G__52663) {
case 1:
return shadow.dom.contains_QMARK_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.contains_QMARK_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.contains_QMARK_.cljs$core$IFn$_invoke$arity$1 = (function (el){
var G__52665 = document;
var G__52666 = shadow.dom.dom_node(el);
return goog.dom.contains(G__52665,G__52666);
});

shadow.dom.contains_QMARK_.cljs$core$IFn$_invoke$arity$2 = (function (parent,el){
var G__52668 = shadow.dom.dom_node(parent);
var G__52669 = shadow.dom.dom_node(el);
return goog.dom.contains(G__52668,G__52669);
});

shadow.dom.contains_QMARK_.cljs$lang$maxFixedArity = 2;

shadow.dom.add_class = (function shadow$dom$add_class(el,cls){
var G__52673 = shadow.dom.dom_node(el);
var G__52674 = cls;
return goog.dom.classlist.add(G__52673,G__52674);
});
shadow.dom.remove_class = (function shadow$dom$remove_class(el,cls){
var G__52677 = shadow.dom.dom_node(el);
var G__52678 = cls;
return goog.dom.classlist.remove(G__52677,G__52678);
});
shadow.dom.toggle_class = (function shadow$dom$toggle_class(var_args){
var G__52682 = arguments.length;
switch (G__52682) {
case 2:
return shadow.dom.toggle_class.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return shadow.dom.toggle_class.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.toggle_class.cljs$core$IFn$_invoke$arity$2 = (function (el,cls){
var G__52684 = shadow.dom.dom_node(el);
var G__52685 = cls;
return goog.dom.classlist.toggle(G__52684,G__52685);
});

shadow.dom.toggle_class.cljs$core$IFn$_invoke$arity$3 = (function (el,cls,v){
if(cljs.core.truth_(v)){
return shadow.dom.add_class(el,cls);
} else {
return shadow.dom.remove_class(el,cls);
}
});

shadow.dom.toggle_class.cljs$lang$maxFixedArity = 3;

shadow.dom.dom_listen = (cljs.core.truth_((function (){var or__4131__auto__ = (!((typeof document !== 'undefined')));
if(or__4131__auto__){
return or__4131__auto__;
} else {
return document.addEventListener;
}
})())?(function shadow$dom$dom_listen_good(el,ev,handler){
return el.addEventListener(ev,handler,false);
}):(function shadow$dom$dom_listen_ie(el,ev,handler){
try{return el.attachEvent(["on",cljs.core.str.cljs$core$IFn$_invoke$arity$1(ev)].join(''),(function (e){
return (handler.cljs$core$IFn$_invoke$arity$2 ? handler.cljs$core$IFn$_invoke$arity$2(e,el) : handler.call(null,e,el));
}));
}catch (e52687){if((e52687 instanceof Object)){
var e = e52687;
return console.log("didnt support attachEvent",el,e);
} else {
throw e52687;

}
}}));
shadow.dom.dom_listen_remove = (cljs.core.truth_((function (){var or__4131__auto__ = (!((typeof document !== 'undefined')));
if(or__4131__auto__){
return or__4131__auto__;
} else {
return document.removeEventListener;
}
})())?(function shadow$dom$dom_listen_remove_good(el,ev,handler){
return el.removeEventListener(ev,handler,false);
}):(function shadow$dom$dom_listen_remove_ie(el,ev,handler){
return el.detachEvent(["on",cljs.core.str.cljs$core$IFn$_invoke$arity$1(ev)].join(''),handler);
}));
shadow.dom.on_query = (function shadow$dom$on_query(root_el,ev,selector,handler){
var seq__52693 = cljs.core.seq(shadow.dom.query.cljs$core$IFn$_invoke$arity$2(selector,root_el));
var chunk__52694 = null;
var count__52695 = (0);
var i__52696 = (0);
while(true){
if((i__52696 < count__52695)){
var el = chunk__52694.cljs$core$IIndexed$_nth$arity$2(null,i__52696);
var handler_53274__$1 = ((function (seq__52693,chunk__52694,count__52695,i__52696,el){
return (function (e){
return (handler.cljs$core$IFn$_invoke$arity$2 ? handler.cljs$core$IFn$_invoke$arity$2(e,el) : handler.call(null,e,el));
});})(seq__52693,chunk__52694,count__52695,i__52696,el))
;
var G__52714_53275 = el;
var G__52715_53276 = cljs.core.name(ev);
var G__52716_53277 = handler_53274__$1;
(shadow.dom.dom_listen.cljs$core$IFn$_invoke$arity$3 ? shadow.dom.dom_listen.cljs$core$IFn$_invoke$arity$3(G__52714_53275,G__52715_53276,G__52716_53277) : shadow.dom.dom_listen.call(null,G__52714_53275,G__52715_53276,G__52716_53277));


var G__53278 = seq__52693;
var G__53279 = chunk__52694;
var G__53280 = count__52695;
var G__53281 = (i__52696 + (1));
seq__52693 = G__53278;
chunk__52694 = G__53279;
count__52695 = G__53280;
i__52696 = G__53281;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__52693);
if(temp__5735__auto__){
var seq__52693__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__52693__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__52693__$1);
var G__53282 = cljs.core.chunk_rest(seq__52693__$1);
var G__53283 = c__4550__auto__;
var G__53284 = cljs.core.count(c__4550__auto__);
var G__53285 = (0);
seq__52693 = G__53282;
chunk__52694 = G__53283;
count__52695 = G__53284;
i__52696 = G__53285;
continue;
} else {
var el = cljs.core.first(seq__52693__$1);
var handler_53286__$1 = ((function (seq__52693,chunk__52694,count__52695,i__52696,el,seq__52693__$1,temp__5735__auto__){
return (function (e){
return (handler.cljs$core$IFn$_invoke$arity$2 ? handler.cljs$core$IFn$_invoke$arity$2(e,el) : handler.call(null,e,el));
});})(seq__52693,chunk__52694,count__52695,i__52696,el,seq__52693__$1,temp__5735__auto__))
;
var G__52723_53287 = el;
var G__52724_53288 = cljs.core.name(ev);
var G__52725_53289 = handler_53286__$1;
(shadow.dom.dom_listen.cljs$core$IFn$_invoke$arity$3 ? shadow.dom.dom_listen.cljs$core$IFn$_invoke$arity$3(G__52723_53287,G__52724_53288,G__52725_53289) : shadow.dom.dom_listen.call(null,G__52723_53287,G__52724_53288,G__52725_53289));


var G__53290 = cljs.core.next(seq__52693__$1);
var G__53291 = null;
var G__53292 = (0);
var G__53293 = (0);
seq__52693 = G__53290;
chunk__52694 = G__53291;
count__52695 = G__53292;
i__52696 = G__53293;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.dom.on = (function shadow$dom$on(var_args){
var G__52728 = arguments.length;
switch (G__52728) {
case 3:
return shadow.dom.on.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return shadow.dom.on.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.on.cljs$core$IFn$_invoke$arity$3 = (function (el,ev,handler){
return shadow.dom.on.cljs$core$IFn$_invoke$arity$4(el,ev,handler,false);
});

shadow.dom.on.cljs$core$IFn$_invoke$arity$4 = (function (el,ev,handler,capture){
if(cljs.core.vector_QMARK_(ev)){
return shadow.dom.on_query(el,cljs.core.first(ev),cljs.core.second(ev),handler);
} else {
var handler__$1 = (function (e){
return (handler.cljs$core$IFn$_invoke$arity$2 ? handler.cljs$core$IFn$_invoke$arity$2(e,el) : handler.call(null,e,el));
});
var G__52731 = shadow.dom.dom_node(el);
var G__52732 = cljs.core.name(ev);
var G__52733 = handler__$1;
return (shadow.dom.dom_listen.cljs$core$IFn$_invoke$arity$3 ? shadow.dom.dom_listen.cljs$core$IFn$_invoke$arity$3(G__52731,G__52732,G__52733) : shadow.dom.dom_listen.call(null,G__52731,G__52732,G__52733));
}
});

shadow.dom.on.cljs$lang$maxFixedArity = 4;

shadow.dom.remove_event_handler = (function shadow$dom$remove_event_handler(el,ev,handler){
var G__52735 = shadow.dom.dom_node(el);
var G__52736 = cljs.core.name(ev);
var G__52737 = handler;
return (shadow.dom.dom_listen_remove.cljs$core$IFn$_invoke$arity$3 ? shadow.dom.dom_listen_remove.cljs$core$IFn$_invoke$arity$3(G__52735,G__52736,G__52737) : shadow.dom.dom_listen_remove.call(null,G__52735,G__52736,G__52737));
});
shadow.dom.add_event_listeners = (function shadow$dom$add_event_listeners(el,events){
var seq__52738 = cljs.core.seq(events);
var chunk__52739 = null;
var count__52740 = (0);
var i__52741 = (0);
while(true){
if((i__52741 < count__52740)){
var vec__52750 = chunk__52739.cljs$core$IIndexed$_nth$arity$2(null,i__52741);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52750,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52750,(1),null);
shadow.dom.on.cljs$core$IFn$_invoke$arity$3(el,k,v);


var G__53295 = seq__52738;
var G__53296 = chunk__52739;
var G__53297 = count__52740;
var G__53298 = (i__52741 + (1));
seq__52738 = G__53295;
chunk__52739 = G__53296;
count__52740 = G__53297;
i__52741 = G__53298;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__52738);
if(temp__5735__auto__){
var seq__52738__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__52738__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__52738__$1);
var G__53299 = cljs.core.chunk_rest(seq__52738__$1);
var G__53300 = c__4550__auto__;
var G__53301 = cljs.core.count(c__4550__auto__);
var G__53302 = (0);
seq__52738 = G__53299;
chunk__52739 = G__53300;
count__52740 = G__53301;
i__52741 = G__53302;
continue;
} else {
var vec__52755 = cljs.core.first(seq__52738__$1);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52755,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52755,(1),null);
shadow.dom.on.cljs$core$IFn$_invoke$arity$3(el,k,v);


var G__53303 = cljs.core.next(seq__52738__$1);
var G__53304 = null;
var G__53305 = (0);
var G__53306 = (0);
seq__52738 = G__53303;
chunk__52739 = G__53304;
count__52740 = G__53305;
i__52741 = G__53306;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.dom.set_style = (function shadow$dom$set_style(el,styles){
var dom = shadow.dom.dom_node(el);
var seq__52761 = cljs.core.seq(styles);
var chunk__52762 = null;
var count__52763 = (0);
var i__52764 = (0);
while(true){
if((i__52764 < count__52763)){
var vec__52782 = chunk__52762.cljs$core$IIndexed$_nth$arity$2(null,i__52764);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52782,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52782,(1),null);
var G__52785_53307 = dom;
var G__52786_53308 = cljs.core.name(k);
var G__52787_53309 = (((v == null))?"":v);
goog.style.setStyle(G__52785_53307,G__52786_53308,G__52787_53309);


var G__53310 = seq__52761;
var G__53311 = chunk__52762;
var G__53312 = count__52763;
var G__53313 = (i__52764 + (1));
seq__52761 = G__53310;
chunk__52762 = G__53311;
count__52763 = G__53312;
i__52764 = G__53313;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__52761);
if(temp__5735__auto__){
var seq__52761__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__52761__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__52761__$1);
var G__53314 = cljs.core.chunk_rest(seq__52761__$1);
var G__53315 = c__4550__auto__;
var G__53316 = cljs.core.count(c__4550__auto__);
var G__53317 = (0);
seq__52761 = G__53314;
chunk__52762 = G__53315;
count__52763 = G__53316;
i__52764 = G__53317;
continue;
} else {
var vec__52792 = cljs.core.first(seq__52761__$1);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52792,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52792,(1),null);
var G__52795_53318 = dom;
var G__52796_53319 = cljs.core.name(k);
var G__52797_53320 = (((v == null))?"":v);
goog.style.setStyle(G__52795_53318,G__52796_53319,G__52797_53320);


var G__53321 = cljs.core.next(seq__52761__$1);
var G__53322 = null;
var G__53323 = (0);
var G__53324 = (0);
seq__52761 = G__53321;
chunk__52762 = G__53322;
count__52763 = G__53323;
i__52764 = G__53324;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.dom.set_attr_STAR_ = (function shadow$dom$set_attr_STAR_(el,key,value){
var G__52800_53326 = key;
var G__52800_53327__$1 = (((G__52800_53326 instanceof cljs.core.Keyword))?G__52800_53326.fqn:null);
switch (G__52800_53327__$1) {
case "id":
el.id = cljs.core.str.cljs$core$IFn$_invoke$arity$1(value);

break;
case "class":
el.className = cljs.core.str.cljs$core$IFn$_invoke$arity$1(value);

break;
case "for":
el.htmlFor = value;

break;
case "cellpadding":
el.setAttribute("cellPadding",value);

break;
case "cellspacing":
el.setAttribute("cellSpacing",value);

break;
case "colspan":
el.setAttribute("colSpan",value);

break;
case "frameborder":
el.setAttribute("frameBorder",value);

break;
case "height":
el.setAttribute("height",value);

break;
case "maxlength":
el.setAttribute("maxLength",value);

break;
case "role":
el.setAttribute("role",value);

break;
case "rowspan":
el.setAttribute("rowSpan",value);

break;
case "type":
el.setAttribute("type",value);

break;
case "usemap":
el.setAttribute("useMap",value);

break;
case "valign":
el.setAttribute("vAlign",value);

break;
case "width":
el.setAttribute("width",value);

break;
case "on":
shadow.dom.add_event_listeners(el,value);

break;
case "style":
if((value == null)){
} else {
if(typeof value === 'string'){
el.setAttribute("style",value);
} else {
if(cljs.core.map_QMARK_(value)){
shadow.dom.set_style(el,value);
} else {
goog.style.setStyle(el,value);

}
}
}

break;
default:
var ks_53330 = cljs.core.name(key);
if(cljs.core.truth_((function (){var or__4131__auto__ = goog.string.startsWith(ks_53330,"data-");
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return goog.string.startsWith(ks_53330,"aria-");
}
})())){
el.setAttribute(ks_53330,value);
} else {
(el[ks_53330] = value);
}

}

return el;
});
shadow.dom.set_attrs = (function shadow$dom$set_attrs(el,attrs){
return cljs.core.reduce_kv((function (el__$1,key,value){
shadow.dom.set_attr_STAR_(el__$1,key,value);

return el__$1;
}),shadow.dom.dom_node(el),attrs);
});
shadow.dom.set_attr = (function shadow$dom$set_attr(el,key,value){
return shadow.dom.set_attr_STAR_(shadow.dom.dom_node(el),key,value);
});
shadow.dom.has_class_QMARK_ = (function shadow$dom$has_class_QMARK_(el,cls){
var G__52808 = shadow.dom.dom_node(el);
var G__52809 = cls;
return goog.dom.classlist.contains(G__52808,G__52809);
});
shadow.dom.merge_class_string = (function shadow$dom$merge_class_string(current,extra_class){
if(cljs.core.seq(current)){
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(current)," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(extra_class)].join('');
} else {
return extra_class;
}
});
shadow.dom.parse_tag = (function shadow$dom$parse_tag(spec){
var spec__$1 = cljs.core.name(spec);
var fdot = spec__$1.indexOf(".");
var fhash = spec__$1.indexOf("#");
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((-1),fdot)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((-1),fhash)))){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [spec__$1,null,null], null);
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((-1),fhash)){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [spec__$1.substring((0),fdot),null,clojure.string.replace(spec__$1.substring((fdot + (1))),/\./," ")], null);
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((-1),fdot)){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [spec__$1.substring((0),fhash),spec__$1.substring((fhash + (1))),null], null);
} else {
if((fhash > fdot)){
throw ["cant have id after class?",spec__$1].join('');
} else {
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [spec__$1.substring((0),fhash),spec__$1.substring((fhash + (1)),fdot),clojure.string.replace(spec__$1.substring((fdot + (1))),/\./," ")], null);

}
}
}
}
});
shadow.dom.create_dom_node = (function shadow$dom$create_dom_node(tag_def,p__52815){
var map__52816 = p__52815;
var map__52816__$1 = (((((!((map__52816 == null))))?(((((map__52816.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__52816.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__52816):map__52816);
var props = map__52816__$1;
var class$ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__52816__$1,new cljs.core.Keyword(null,"class","class",-2030961996));
var tag_props = ({});
var vec__52818 = shadow.dom.parse_tag(tag_def);
var tag_name = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52818,(0),null);
var tag_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52818,(1),null);
var tag_classes = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52818,(2),null);
if(cljs.core.truth_(tag_id)){
(tag_props["id"] = tag_id);
} else {
}

if(cljs.core.truth_(tag_classes)){
(tag_props["class"] = shadow.dom.merge_class_string(class$,tag_classes));
} else {
}

var G__52821 = goog.dom.createDom(tag_name,tag_props);
shadow.dom.set_attrs(G__52821,cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(props,new cljs.core.Keyword(null,"class","class",-2030961996)));

return G__52821;
});
shadow.dom.append = (function shadow$dom$append(var_args){
var G__52825 = arguments.length;
switch (G__52825) {
case 1:
return shadow.dom.append.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.append.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.append.cljs$core$IFn$_invoke$arity$1 = (function (node){
if(cljs.core.truth_(node)){
var temp__5735__auto__ = shadow.dom.dom_node(node);
if(cljs.core.truth_(temp__5735__auto__)){
var n = temp__5735__auto__;
document.body.appendChild(n);

return n;
} else {
return null;
}
} else {
return null;
}
});

shadow.dom.append.cljs$core$IFn$_invoke$arity$2 = (function (el,node){
if(cljs.core.truth_(node)){
var temp__5735__auto__ = shadow.dom.dom_node(node);
if(cljs.core.truth_(temp__5735__auto__)){
var n = temp__5735__auto__;
shadow.dom.dom_node(el).appendChild(n);

return n;
} else {
return null;
}
} else {
return null;
}
});

shadow.dom.append.cljs$lang$maxFixedArity = 2;

shadow.dom.destructure_node = (function shadow$dom$destructure_node(create_fn,p__52829){
var vec__52831 = p__52829;
var seq__52832 = cljs.core.seq(vec__52831);
var first__52833 = cljs.core.first(seq__52832);
var seq__52832__$1 = cljs.core.next(seq__52832);
var nn = first__52833;
var first__52833__$1 = cljs.core.first(seq__52832__$1);
var seq__52832__$2 = cljs.core.next(seq__52832__$1);
var np = first__52833__$1;
var nc = seq__52832__$2;
var node = vec__52831;
if((nn instanceof cljs.core.Keyword)){
} else {
throw cljs.core.ex_info.cljs$core$IFn$_invoke$arity$2("invalid dom node",new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"node","node",581201198),node], null));
}

if((((np == null)) && ((nc == null)))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var G__52836 = nn;
var G__52837 = cljs.core.PersistentArrayMap.EMPTY;
return (create_fn.cljs$core$IFn$_invoke$arity$2 ? create_fn.cljs$core$IFn$_invoke$arity$2(G__52836,G__52837) : create_fn.call(null,G__52836,G__52837));
})(),cljs.core.List.EMPTY], null);
} else {
if(cljs.core.map_QMARK_(np)){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(create_fn.cljs$core$IFn$_invoke$arity$2 ? create_fn.cljs$core$IFn$_invoke$arity$2(nn,np) : create_fn.call(null,nn,np)),nc], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var G__52839 = nn;
var G__52840 = cljs.core.PersistentArrayMap.EMPTY;
return (create_fn.cljs$core$IFn$_invoke$arity$2 ? create_fn.cljs$core$IFn$_invoke$arity$2(G__52839,G__52840) : create_fn.call(null,G__52839,G__52840));
})(),cljs.core.conj.cljs$core$IFn$_invoke$arity$2(nc,np)], null);

}
}
});
shadow.dom.make_dom_node = (function shadow$dom$make_dom_node(structure){
var vec__52844 = shadow.dom.destructure_node(shadow.dom.create_dom_node,structure);
var node = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52844,(0),null);
var node_children = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52844,(1),null);
var seq__52848_53344 = cljs.core.seq(node_children);
var chunk__52849_53345 = null;
var count__52850_53346 = (0);
var i__52851_53347 = (0);
while(true){
if((i__52851_53347 < count__52850_53346)){
var child_struct_53349 = chunk__52849_53345.cljs$core$IIndexed$_nth$arity$2(null,i__52851_53347);
var children_53350 = shadow.dom.dom_node(child_struct_53349);
if(cljs.core.seq_QMARK_(children_53350)){
var seq__52870_53351 = cljs.core.seq(cljs.core.map.cljs$core$IFn$_invoke$arity$2(shadow.dom.dom_node,children_53350));
var chunk__52872_53352 = null;
var count__52873_53353 = (0);
var i__52874_53354 = (0);
while(true){
if((i__52874_53354 < count__52873_53353)){
var child_53356 = chunk__52872_53352.cljs$core$IIndexed$_nth$arity$2(null,i__52874_53354);
if(cljs.core.truth_(child_53356)){
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,child_53356);


var G__53357 = seq__52870_53351;
var G__53358 = chunk__52872_53352;
var G__53359 = count__52873_53353;
var G__53360 = (i__52874_53354 + (1));
seq__52870_53351 = G__53357;
chunk__52872_53352 = G__53358;
count__52873_53353 = G__53359;
i__52874_53354 = G__53360;
continue;
} else {
var G__53362 = seq__52870_53351;
var G__53363 = chunk__52872_53352;
var G__53364 = count__52873_53353;
var G__53365 = (i__52874_53354 + (1));
seq__52870_53351 = G__53362;
chunk__52872_53352 = G__53363;
count__52873_53353 = G__53364;
i__52874_53354 = G__53365;
continue;
}
} else {
var temp__5735__auto___53367 = cljs.core.seq(seq__52870_53351);
if(temp__5735__auto___53367){
var seq__52870_53368__$1 = temp__5735__auto___53367;
if(cljs.core.chunked_seq_QMARK_(seq__52870_53368__$1)){
var c__4550__auto___53369 = cljs.core.chunk_first(seq__52870_53368__$1);
var G__53370 = cljs.core.chunk_rest(seq__52870_53368__$1);
var G__53371 = c__4550__auto___53369;
var G__53372 = cljs.core.count(c__4550__auto___53369);
var G__53373 = (0);
seq__52870_53351 = G__53370;
chunk__52872_53352 = G__53371;
count__52873_53353 = G__53372;
i__52874_53354 = G__53373;
continue;
} else {
var child_53375 = cljs.core.first(seq__52870_53368__$1);
if(cljs.core.truth_(child_53375)){
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,child_53375);


var G__53376 = cljs.core.next(seq__52870_53368__$1);
var G__53377 = null;
var G__53378 = (0);
var G__53379 = (0);
seq__52870_53351 = G__53376;
chunk__52872_53352 = G__53377;
count__52873_53353 = G__53378;
i__52874_53354 = G__53379;
continue;
} else {
var G__53380 = cljs.core.next(seq__52870_53368__$1);
var G__53381 = null;
var G__53382 = (0);
var G__53383 = (0);
seq__52870_53351 = G__53380;
chunk__52872_53352 = G__53381;
count__52873_53353 = G__53382;
i__52874_53354 = G__53383;
continue;
}
}
} else {
}
}
break;
}
} else {
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,children_53350);
}


var G__53385 = seq__52848_53344;
var G__53386 = chunk__52849_53345;
var G__53387 = count__52850_53346;
var G__53388 = (i__52851_53347 + (1));
seq__52848_53344 = G__53385;
chunk__52849_53345 = G__53386;
count__52850_53346 = G__53387;
i__52851_53347 = G__53388;
continue;
} else {
var temp__5735__auto___53389 = cljs.core.seq(seq__52848_53344);
if(temp__5735__auto___53389){
var seq__52848_53390__$1 = temp__5735__auto___53389;
if(cljs.core.chunked_seq_QMARK_(seq__52848_53390__$1)){
var c__4550__auto___53391 = cljs.core.chunk_first(seq__52848_53390__$1);
var G__53392 = cljs.core.chunk_rest(seq__52848_53390__$1);
var G__53393 = c__4550__auto___53391;
var G__53394 = cljs.core.count(c__4550__auto___53391);
var G__53395 = (0);
seq__52848_53344 = G__53392;
chunk__52849_53345 = G__53393;
count__52850_53346 = G__53394;
i__52851_53347 = G__53395;
continue;
} else {
var child_struct_53398 = cljs.core.first(seq__52848_53390__$1);
var children_53399 = shadow.dom.dom_node(child_struct_53398);
if(cljs.core.seq_QMARK_(children_53399)){
var seq__52876_53400 = cljs.core.seq(cljs.core.map.cljs$core$IFn$_invoke$arity$2(shadow.dom.dom_node,children_53399));
var chunk__52878_53401 = null;
var count__52879_53402 = (0);
var i__52880_53403 = (0);
while(true){
if((i__52880_53403 < count__52879_53402)){
var child_53404 = chunk__52878_53401.cljs$core$IIndexed$_nth$arity$2(null,i__52880_53403);
if(cljs.core.truth_(child_53404)){
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,child_53404);


var G__53405 = seq__52876_53400;
var G__53406 = chunk__52878_53401;
var G__53407 = count__52879_53402;
var G__53408 = (i__52880_53403 + (1));
seq__52876_53400 = G__53405;
chunk__52878_53401 = G__53406;
count__52879_53402 = G__53407;
i__52880_53403 = G__53408;
continue;
} else {
var G__53409 = seq__52876_53400;
var G__53410 = chunk__52878_53401;
var G__53411 = count__52879_53402;
var G__53412 = (i__52880_53403 + (1));
seq__52876_53400 = G__53409;
chunk__52878_53401 = G__53410;
count__52879_53402 = G__53411;
i__52880_53403 = G__53412;
continue;
}
} else {
var temp__5735__auto___53413__$1 = cljs.core.seq(seq__52876_53400);
if(temp__5735__auto___53413__$1){
var seq__52876_53414__$1 = temp__5735__auto___53413__$1;
if(cljs.core.chunked_seq_QMARK_(seq__52876_53414__$1)){
var c__4550__auto___53415 = cljs.core.chunk_first(seq__52876_53414__$1);
var G__53416 = cljs.core.chunk_rest(seq__52876_53414__$1);
var G__53417 = c__4550__auto___53415;
var G__53418 = cljs.core.count(c__4550__auto___53415);
var G__53419 = (0);
seq__52876_53400 = G__53416;
chunk__52878_53401 = G__53417;
count__52879_53402 = G__53418;
i__52880_53403 = G__53419;
continue;
} else {
var child_53420 = cljs.core.first(seq__52876_53414__$1);
if(cljs.core.truth_(child_53420)){
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,child_53420);


var G__53421 = cljs.core.next(seq__52876_53414__$1);
var G__53422 = null;
var G__53423 = (0);
var G__53424 = (0);
seq__52876_53400 = G__53421;
chunk__52878_53401 = G__53422;
count__52879_53402 = G__53423;
i__52880_53403 = G__53424;
continue;
} else {
var G__53426 = cljs.core.next(seq__52876_53414__$1);
var G__53427 = null;
var G__53428 = (0);
var G__53429 = (0);
seq__52876_53400 = G__53426;
chunk__52878_53401 = G__53427;
count__52879_53402 = G__53428;
i__52880_53403 = G__53429;
continue;
}
}
} else {
}
}
break;
}
} else {
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,children_53399);
}


var G__53433 = cljs.core.next(seq__52848_53390__$1);
var G__53434 = null;
var G__53435 = (0);
var G__53436 = (0);
seq__52848_53344 = G__53433;
chunk__52849_53345 = G__53434;
count__52850_53346 = G__53435;
i__52851_53347 = G__53436;
continue;
}
} else {
}
}
break;
}

return node;
});
cljs.core.Keyword.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.Keyword.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return shadow.dom.make_dom_node(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [this$__$1], null));
});

cljs.core.PersistentVector.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.PersistentVector.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return shadow.dom.make_dom_node(this$__$1);
});

cljs.core.LazySeq.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.LazySeq.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return cljs.core.map.cljs$core$IFn$_invoke$arity$2(shadow.dom._to_dom,this$__$1);
});
if(cljs.core.truth_(((typeof HTMLElement) != 'undefined'))){
HTMLElement.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL;

HTMLElement.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return this$__$1;
});
} else {
}
if(cljs.core.truth_(((typeof DocumentFragment) != 'undefined'))){
DocumentFragment.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL;

DocumentFragment.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return this$__$1;
});
} else {
}
/**
 * clear node children
 */
shadow.dom.reset = (function shadow$dom$reset(node){
var G__52893 = shadow.dom.dom_node(node);
return goog.dom.removeChildren(G__52893);
});
shadow.dom.remove = (function shadow$dom$remove(node){
if((((!((node == null))))?(((((node.cljs$lang$protocol_mask$partition0$ & (8388608))) || ((cljs.core.PROTOCOL_SENTINEL === node.cljs$core$ISeqable$))))?true:false):false)){
var seq__52897 = cljs.core.seq(node);
var chunk__52898 = null;
var count__52899 = (0);
var i__52900 = (0);
while(true){
if((i__52900 < count__52899)){
var n = chunk__52898.cljs$core$IIndexed$_nth$arity$2(null,i__52900);
(shadow.dom.remove.cljs$core$IFn$_invoke$arity$1 ? shadow.dom.remove.cljs$core$IFn$_invoke$arity$1(n) : shadow.dom.remove.call(null,n));


var G__53443 = seq__52897;
var G__53444 = chunk__52898;
var G__53445 = count__52899;
var G__53446 = (i__52900 + (1));
seq__52897 = G__53443;
chunk__52898 = G__53444;
count__52899 = G__53445;
i__52900 = G__53446;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__52897);
if(temp__5735__auto__){
var seq__52897__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__52897__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__52897__$1);
var G__53449 = cljs.core.chunk_rest(seq__52897__$1);
var G__53450 = c__4550__auto__;
var G__53451 = cljs.core.count(c__4550__auto__);
var G__53452 = (0);
seq__52897 = G__53449;
chunk__52898 = G__53450;
count__52899 = G__53451;
i__52900 = G__53452;
continue;
} else {
var n = cljs.core.first(seq__52897__$1);
(shadow.dom.remove.cljs$core$IFn$_invoke$arity$1 ? shadow.dom.remove.cljs$core$IFn$_invoke$arity$1(n) : shadow.dom.remove.call(null,n));


var G__53455 = cljs.core.next(seq__52897__$1);
var G__53456 = null;
var G__53457 = (0);
var G__53458 = (0);
seq__52897 = G__53455;
chunk__52898 = G__53456;
count__52899 = G__53457;
i__52900 = G__53458;
continue;
}
} else {
return null;
}
}
break;
}
} else {
return goog.dom.removeNode(node);
}
});
shadow.dom.replace_node = (function shadow$dom$replace_node(old,new$){
var G__52903 = shadow.dom.dom_node(new$);
var G__52904 = shadow.dom.dom_node(old);
return goog.dom.replaceNode(G__52903,G__52904);
});
shadow.dom.text = (function shadow$dom$text(var_args){
var G__52908 = arguments.length;
switch (G__52908) {
case 2:
return shadow.dom.text.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return shadow.dom.text.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.text.cljs$core$IFn$_invoke$arity$2 = (function (el,new_text){
return shadow.dom.dom_node(el).innerText = new_text;
});

shadow.dom.text.cljs$core$IFn$_invoke$arity$1 = (function (el){
return shadow.dom.dom_node(el).innerText;
});

shadow.dom.text.cljs$lang$maxFixedArity = 2;

shadow.dom.check = (function shadow$dom$check(var_args){
var G__52913 = arguments.length;
switch (G__52913) {
case 1:
return shadow.dom.check.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.check.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.check.cljs$core$IFn$_invoke$arity$1 = (function (el){
return shadow.dom.check.cljs$core$IFn$_invoke$arity$2(el,true);
});

shadow.dom.check.cljs$core$IFn$_invoke$arity$2 = (function (el,checked){
return shadow.dom.dom_node(el).checked = checked;
});

shadow.dom.check.cljs$lang$maxFixedArity = 2;

shadow.dom.checked_QMARK_ = (function shadow$dom$checked_QMARK_(el){
return shadow.dom.dom_node(el).checked;
});
shadow.dom.form_elements = (function shadow$dom$form_elements(el){
return (new shadow.dom.NativeColl(shadow.dom.dom_node(el).elements));
});
shadow.dom.children = (function shadow$dom$children(el){
return (new shadow.dom.NativeColl(shadow.dom.dom_node(el).children));
});
shadow.dom.child_nodes = (function shadow$dom$child_nodes(el){
return (new shadow.dom.NativeColl(shadow.dom.dom_node(el).childNodes));
});
shadow.dom.attr = (function shadow$dom$attr(var_args){
var G__52919 = arguments.length;
switch (G__52919) {
case 2:
return shadow.dom.attr.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return shadow.dom.attr.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.attr.cljs$core$IFn$_invoke$arity$2 = (function (el,key){
return shadow.dom.dom_node(el).getAttribute(cljs.core.name(key));
});

shadow.dom.attr.cljs$core$IFn$_invoke$arity$3 = (function (el,key,default$){
var or__4131__auto__ = shadow.dom.dom_node(el).getAttribute(cljs.core.name(key));
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return default$;
}
});

shadow.dom.attr.cljs$lang$maxFixedArity = 3;

shadow.dom.del_attr = (function shadow$dom$del_attr(el,key){
return shadow.dom.dom_node(el).removeAttribute(cljs.core.name(key));
});
shadow.dom.data = (function shadow$dom$data(el,key){
return shadow.dom.dom_node(el).getAttribute(["data-",cljs.core.name(key)].join(''));
});
shadow.dom.set_data = (function shadow$dom$set_data(el,key,value){
return shadow.dom.dom_node(el).setAttribute(["data-",cljs.core.name(key)].join(''),cljs.core.str.cljs$core$IFn$_invoke$arity$1(value));
});
shadow.dom.set_html = (function shadow$dom$set_html(node,text){
return shadow.dom.dom_node(node).innerHTML = text;
});
shadow.dom.get_html = (function shadow$dom$get_html(node){
return shadow.dom.dom_node(node).innerHTML;
});
shadow.dom.fragment = (function shadow$dom$fragment(var_args){
var args__4736__auto__ = [];
var len__4730__auto___53480 = arguments.length;
var i__4731__auto___53481 = (0);
while(true){
if((i__4731__auto___53481 < len__4730__auto___53480)){
args__4736__auto__.push((arguments[i__4731__auto___53481]));

var G__53482 = (i__4731__auto___53481 + (1));
i__4731__auto___53481 = G__53482;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return shadow.dom.fragment.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

shadow.dom.fragment.cljs$core$IFn$_invoke$arity$variadic = (function (nodes){
var fragment = document.createDocumentFragment();
var seq__52933_53486 = cljs.core.seq(nodes);
var chunk__52934_53487 = null;
var count__52935_53488 = (0);
var i__52936_53489 = (0);
while(true){
if((i__52936_53489 < count__52935_53488)){
var node_53492 = chunk__52934_53487.cljs$core$IIndexed$_nth$arity$2(null,i__52936_53489);
fragment.appendChild(shadow.dom._to_dom(node_53492));


var G__53494 = seq__52933_53486;
var G__53495 = chunk__52934_53487;
var G__53496 = count__52935_53488;
var G__53497 = (i__52936_53489 + (1));
seq__52933_53486 = G__53494;
chunk__52934_53487 = G__53495;
count__52935_53488 = G__53496;
i__52936_53489 = G__53497;
continue;
} else {
var temp__5735__auto___53498 = cljs.core.seq(seq__52933_53486);
if(temp__5735__auto___53498){
var seq__52933_53499__$1 = temp__5735__auto___53498;
if(cljs.core.chunked_seq_QMARK_(seq__52933_53499__$1)){
var c__4550__auto___53500 = cljs.core.chunk_first(seq__52933_53499__$1);
var G__53501 = cljs.core.chunk_rest(seq__52933_53499__$1);
var G__53502 = c__4550__auto___53500;
var G__53503 = cljs.core.count(c__4550__auto___53500);
var G__53504 = (0);
seq__52933_53486 = G__53501;
chunk__52934_53487 = G__53502;
count__52935_53488 = G__53503;
i__52936_53489 = G__53504;
continue;
} else {
var node_53505 = cljs.core.first(seq__52933_53499__$1);
fragment.appendChild(shadow.dom._to_dom(node_53505));


var G__53506 = cljs.core.next(seq__52933_53499__$1);
var G__53507 = null;
var G__53508 = (0);
var G__53509 = (0);
seq__52933_53486 = G__53506;
chunk__52934_53487 = G__53507;
count__52935_53488 = G__53508;
i__52936_53489 = G__53509;
continue;
}
} else {
}
}
break;
}

return (new shadow.dom.NativeColl(fragment));
});

shadow.dom.fragment.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
shadow.dom.fragment.cljs$lang$applyTo = (function (seq52931){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq52931));
});

/**
 * given a html string, eval all <script> tags and return the html without the scripts
 * don't do this for everything, only content you trust.
 */
shadow.dom.eval_scripts = (function shadow$dom$eval_scripts(s){
var scripts = cljs.core.re_seq(/<script[^>]*?>(.+?)<\/script>/,s);
var seq__52947_53516 = cljs.core.seq(scripts);
var chunk__52948_53517 = null;
var count__52949_53518 = (0);
var i__52950_53519 = (0);
while(true){
if((i__52950_53519 < count__52949_53518)){
var vec__52961_53520 = chunk__52948_53517.cljs$core$IIndexed$_nth$arity$2(null,i__52950_53519);
var script_tag_53521 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52961_53520,(0),null);
var script_body_53522 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52961_53520,(1),null);
eval(script_body_53522);


var G__53524 = seq__52947_53516;
var G__53525 = chunk__52948_53517;
var G__53526 = count__52949_53518;
var G__53527 = (i__52950_53519 + (1));
seq__52947_53516 = G__53524;
chunk__52948_53517 = G__53525;
count__52949_53518 = G__53526;
i__52950_53519 = G__53527;
continue;
} else {
var temp__5735__auto___53529 = cljs.core.seq(seq__52947_53516);
if(temp__5735__auto___53529){
var seq__52947_53530__$1 = temp__5735__auto___53529;
if(cljs.core.chunked_seq_QMARK_(seq__52947_53530__$1)){
var c__4550__auto___53531 = cljs.core.chunk_first(seq__52947_53530__$1);
var G__53532 = cljs.core.chunk_rest(seq__52947_53530__$1);
var G__53533 = c__4550__auto___53531;
var G__53534 = cljs.core.count(c__4550__auto___53531);
var G__53535 = (0);
seq__52947_53516 = G__53532;
chunk__52948_53517 = G__53533;
count__52949_53518 = G__53534;
i__52950_53519 = G__53535;
continue;
} else {
var vec__52965_53539 = cljs.core.first(seq__52947_53530__$1);
var script_tag_53540 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52965_53539,(0),null);
var script_body_53541 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52965_53539,(1),null);
eval(script_body_53541);


var G__53543 = cljs.core.next(seq__52947_53530__$1);
var G__53544 = null;
var G__53545 = (0);
var G__53546 = (0);
seq__52947_53516 = G__53543;
chunk__52948_53517 = G__53544;
count__52949_53518 = G__53545;
i__52950_53519 = G__53546;
continue;
}
} else {
}
}
break;
}

return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(((function (scripts){
return (function (s__$1,p__52970){
var vec__52971 = p__52970;
var script_tag = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52971,(0),null);
var script_body = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__52971,(1),null);
return clojure.string.replace(s__$1,script_tag,"");
});})(scripts))
,s,scripts);
});
shadow.dom.str__GT_fragment = (function shadow$dom$str__GT_fragment(s){
var el = document.createElement("div");
el.innerHTML = s;

return (new shadow.dom.NativeColl(goog.dom.childrenToNode_(document,el)));
});
shadow.dom.node_name = (function shadow$dom$node_name(el){
return shadow.dom.dom_node(el).nodeName;
});
shadow.dom.ancestor_by_class = (function shadow$dom$ancestor_by_class(el,cls){
var G__52977 = shadow.dom.dom_node(el);
var G__52978 = cls;
return goog.dom.getAncestorByClass(G__52977,G__52978);
});
shadow.dom.ancestor_by_tag = (function shadow$dom$ancestor_by_tag(var_args){
var G__52982 = arguments.length;
switch (G__52982) {
case 2:
return shadow.dom.ancestor_by_tag.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return shadow.dom.ancestor_by_tag.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.ancestor_by_tag.cljs$core$IFn$_invoke$arity$2 = (function (el,tag){
var G__52983 = shadow.dom.dom_node(el);
var G__52984 = cljs.core.name(tag);
return goog.dom.getAncestorByTagNameAndClass(G__52983,G__52984);
});

shadow.dom.ancestor_by_tag.cljs$core$IFn$_invoke$arity$3 = (function (el,tag,cls){
var G__52985 = shadow.dom.dom_node(el);
var G__52986 = cljs.core.name(tag);
var G__52987 = cljs.core.name(cls);
return goog.dom.getAncestorByTagNameAndClass(G__52985,G__52986,G__52987);
});

shadow.dom.ancestor_by_tag.cljs$lang$maxFixedArity = 3;

shadow.dom.get_value = (function shadow$dom$get_value(dom){
var G__52988 = shadow.dom.dom_node(dom);
return goog.dom.forms.getValue(G__52988);
});
shadow.dom.set_value = (function shadow$dom$set_value(dom,value){
var G__52989 = shadow.dom.dom_node(dom);
var G__52990 = value;
return goog.dom.forms.setValue(G__52989,G__52990);
});
shadow.dom.px = (function shadow$dom$px(value){
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1((value | (0))),"px"].join('');
});
shadow.dom.pct = (function shadow$dom$pct(value){
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(value),"%"].join('');
});
shadow.dom.remove_style_STAR_ = (function shadow$dom$remove_style_STAR_(el,style){
return el.style.removeProperty(cljs.core.name(style));
});
shadow.dom.remove_style = (function shadow$dom$remove_style(el,style){
var el__$1 = shadow.dom.dom_node(el);
return shadow.dom.remove_style_STAR_(el__$1,style);
});
shadow.dom.remove_styles = (function shadow$dom$remove_styles(el,style_keys){
var el__$1 = shadow.dom.dom_node(el);
var seq__52991 = cljs.core.seq(style_keys);
var chunk__52992 = null;
var count__52993 = (0);
var i__52994 = (0);
while(true){
if((i__52994 < count__52993)){
var it = chunk__52992.cljs$core$IIndexed$_nth$arity$2(null,i__52994);
shadow.dom.remove_style_STAR_(el__$1,it);


var G__53565 = seq__52991;
var G__53566 = chunk__52992;
var G__53567 = count__52993;
var G__53568 = (i__52994 + (1));
seq__52991 = G__53565;
chunk__52992 = G__53566;
count__52993 = G__53567;
i__52994 = G__53568;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__52991);
if(temp__5735__auto__){
var seq__52991__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__52991__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__52991__$1);
var G__53571 = cljs.core.chunk_rest(seq__52991__$1);
var G__53572 = c__4550__auto__;
var G__53573 = cljs.core.count(c__4550__auto__);
var G__53574 = (0);
seq__52991 = G__53571;
chunk__52992 = G__53572;
count__52993 = G__53573;
i__52994 = G__53574;
continue;
} else {
var it = cljs.core.first(seq__52991__$1);
shadow.dom.remove_style_STAR_(el__$1,it);


var G__53575 = cljs.core.next(seq__52991__$1);
var G__53576 = null;
var G__53577 = (0);
var G__53578 = (0);
seq__52991 = G__53575;
chunk__52992 = G__53576;
count__52993 = G__53577;
i__52994 = G__53578;
continue;
}
} else {
return null;
}
}
break;
}
});

/**
* @constructor
 * @implements {cljs.core.IRecord}
 * @implements {cljs.core.IKVReduce}
 * @implements {cljs.core.IEquiv}
 * @implements {cljs.core.IHash}
 * @implements {cljs.core.ICollection}
 * @implements {cljs.core.ICounted}
 * @implements {cljs.core.ISeqable}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.ICloneable}
 * @implements {cljs.core.IPrintWithWriter}
 * @implements {cljs.core.IIterable}
 * @implements {cljs.core.IWithMeta}
 * @implements {cljs.core.IAssociative}
 * @implements {cljs.core.IMap}
 * @implements {cljs.core.ILookup}
*/
shadow.dom.Coordinate = (function (x,y,__meta,__extmap,__hash){
this.x = x;
this.y = y;
this.__meta = __meta;
this.__extmap = __extmap;
this.__hash = __hash;
this.cljs$lang$protocol_mask$partition0$ = 2230716170;
this.cljs$lang$protocol_mask$partition1$ = 139264;
});
shadow.dom.Coordinate.prototype.cljs$core$ILookup$_lookup$arity$2 = (function (this__4385__auto__,k__4386__auto__){
var self__ = this;
var this__4385__auto____$1 = this;
return this__4385__auto____$1.cljs$core$ILookup$_lookup$arity$3(null,k__4386__auto__,null);
});

shadow.dom.Coordinate.prototype.cljs$core$ILookup$_lookup$arity$3 = (function (this__4387__auto__,k53002,else__4388__auto__){
var self__ = this;
var this__4387__auto____$1 = this;
var G__53006 = k53002;
var G__53006__$1 = (((G__53006 instanceof cljs.core.Keyword))?G__53006.fqn:null);
switch (G__53006__$1) {
case "x":
return self__.x;

break;
case "y":
return self__.y;

break;
default:
return cljs.core.get.cljs$core$IFn$_invoke$arity$3(self__.__extmap,k53002,else__4388__auto__);

}
});

shadow.dom.Coordinate.prototype.cljs$core$IKVReduce$_kv_reduce$arity$3 = (function (this__4404__auto__,f__4405__auto__,init__4406__auto__){
var self__ = this;
var this__4404__auto____$1 = this;
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(((function (this__4404__auto____$1){
return (function (ret__4407__auto__,p__53007){
var vec__53008 = p__53007;
var k__4408__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53008,(0),null);
var v__4409__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53008,(1),null);
return (f__4405__auto__.cljs$core$IFn$_invoke$arity$3 ? f__4405__auto__.cljs$core$IFn$_invoke$arity$3(ret__4407__auto__,k__4408__auto__,v__4409__auto__) : f__4405__auto__.call(null,ret__4407__auto__,k__4408__auto__,v__4409__auto__));
});})(this__4404__auto____$1))
,init__4406__auto__,this__4404__auto____$1);
});

shadow.dom.Coordinate.prototype.cljs$core$IPrintWithWriter$_pr_writer$arity$3 = (function (this__4399__auto__,writer__4400__auto__,opts__4401__auto__){
var self__ = this;
var this__4399__auto____$1 = this;
var pr_pair__4402__auto__ = ((function (this__4399__auto____$1){
return (function (keyval__4403__auto__){
return cljs.core.pr_sequential_writer(writer__4400__auto__,cljs.core.pr_writer,""," ","",opts__4401__auto__,keyval__4403__auto__);
});})(this__4399__auto____$1))
;
return cljs.core.pr_sequential_writer(writer__4400__auto__,pr_pair__4402__auto__,"#shadow.dom.Coordinate{",", ","}",opts__4401__auto__,cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"x","x",2099068185),self__.x],null)),(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"y","y",-1757859776),self__.y],null))], null),self__.__extmap));
});

shadow.dom.Coordinate.prototype.cljs$core$IIterable$_iterator$arity$1 = (function (G__53001){
var self__ = this;
var G__53001__$1 = this;
return (new cljs.core.RecordIter((0),G__53001__$1,2,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"x","x",2099068185),new cljs.core.Keyword(null,"y","y",-1757859776)], null),(cljs.core.truth_(self__.__extmap)?cljs.core._iterator(self__.__extmap):cljs.core.nil_iter())));
});

shadow.dom.Coordinate.prototype.cljs$core$IMeta$_meta$arity$1 = (function (this__4383__auto__){
var self__ = this;
var this__4383__auto____$1 = this;
return self__.__meta;
});

shadow.dom.Coordinate.prototype.cljs$core$ICloneable$_clone$arity$1 = (function (this__4380__auto__){
var self__ = this;
var this__4380__auto____$1 = this;
return (new shadow.dom.Coordinate(self__.x,self__.y,self__.__meta,self__.__extmap,self__.__hash));
});

shadow.dom.Coordinate.prototype.cljs$core$ICounted$_count$arity$1 = (function (this__4389__auto__){
var self__ = this;
var this__4389__auto____$1 = this;
return (2 + cljs.core.count(self__.__extmap));
});

shadow.dom.Coordinate.prototype.cljs$core$IHash$_hash$arity$1 = (function (this__4381__auto__){
var self__ = this;
var this__4381__auto____$1 = this;
var h__4243__auto__ = self__.__hash;
if((!((h__4243__auto__ == null)))){
return h__4243__auto__;
} else {
var h__4243__auto____$1 = (function (){var fexpr__53011 = ((function (h__4243__auto__,this__4381__auto____$1){
return (function (coll__4382__auto__){
return (145542109 ^ cljs.core.hash_unordered_coll(coll__4382__auto__));
});})(h__4243__auto__,this__4381__auto____$1))
;
return fexpr__53011(this__4381__auto____$1);
})();
self__.__hash = h__4243__auto____$1;

return h__4243__auto____$1;
}
});

shadow.dom.Coordinate.prototype.cljs$core$IEquiv$_equiv$arity$2 = (function (this53003,other53004){
var self__ = this;
var this53003__$1 = this;
return (((!((other53004 == null)))) && ((this53003__$1.constructor === other53004.constructor)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this53003__$1.x,other53004.x)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this53003__$1.y,other53004.y)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this53003__$1.__extmap,other53004.__extmap)));
});

shadow.dom.Coordinate.prototype.cljs$core$IMap$_dissoc$arity$2 = (function (this__4394__auto__,k__4395__auto__){
var self__ = this;
var this__4394__auto____$1 = this;
if(cljs.core.contains_QMARK_(new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"y","y",-1757859776),null,new cljs.core.Keyword(null,"x","x",2099068185),null], null), null),k__4395__auto__)){
return cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(cljs.core._with_meta(cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,this__4394__auto____$1),self__.__meta),k__4395__auto__);
} else {
return (new shadow.dom.Coordinate(self__.x,self__.y,self__.__meta,cljs.core.not_empty(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(self__.__extmap,k__4395__auto__)),null));
}
});

shadow.dom.Coordinate.prototype.cljs$core$IAssociative$_assoc$arity$3 = (function (this__4392__auto__,k__4393__auto__,G__53001){
var self__ = this;
var this__4392__auto____$1 = this;
var pred__53012 = cljs.core.keyword_identical_QMARK_;
var expr__53013 = k__4393__auto__;
if(cljs.core.truth_((function (){var G__53015 = new cljs.core.Keyword(null,"x","x",2099068185);
var G__53016 = expr__53013;
return (pred__53012.cljs$core$IFn$_invoke$arity$2 ? pred__53012.cljs$core$IFn$_invoke$arity$2(G__53015,G__53016) : pred__53012.call(null,G__53015,G__53016));
})())){
return (new shadow.dom.Coordinate(G__53001,self__.y,self__.__meta,self__.__extmap,null));
} else {
if(cljs.core.truth_((function (){var G__53017 = new cljs.core.Keyword(null,"y","y",-1757859776);
var G__53018 = expr__53013;
return (pred__53012.cljs$core$IFn$_invoke$arity$2 ? pred__53012.cljs$core$IFn$_invoke$arity$2(G__53017,G__53018) : pred__53012.call(null,G__53017,G__53018));
})())){
return (new shadow.dom.Coordinate(self__.x,G__53001,self__.__meta,self__.__extmap,null));
} else {
return (new shadow.dom.Coordinate(self__.x,self__.y,self__.__meta,cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(self__.__extmap,k__4393__auto__,G__53001),null));
}
}
});

shadow.dom.Coordinate.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (this__4397__auto__){
var self__ = this;
var this__4397__auto____$1 = this;
return cljs.core.seq(cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.MapEntry(new cljs.core.Keyword(null,"x","x",2099068185),self__.x,null)),(new cljs.core.MapEntry(new cljs.core.Keyword(null,"y","y",-1757859776),self__.y,null))], null),self__.__extmap));
});

shadow.dom.Coordinate.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (this__4384__auto__,G__53001){
var self__ = this;
var this__4384__auto____$1 = this;
return (new shadow.dom.Coordinate(self__.x,self__.y,G__53001,self__.__extmap,self__.__hash));
});

shadow.dom.Coordinate.prototype.cljs$core$ICollection$_conj$arity$2 = (function (this__4390__auto__,entry__4391__auto__){
var self__ = this;
var this__4390__auto____$1 = this;
if(cljs.core.vector_QMARK_(entry__4391__auto__)){
return this__4390__auto____$1.cljs$core$IAssociative$_assoc$arity$3(null,cljs.core._nth.cljs$core$IFn$_invoke$arity$2(entry__4391__auto__,(0)),cljs.core._nth.cljs$core$IFn$_invoke$arity$2(entry__4391__auto__,(1)));
} else {
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(cljs.core._conj,this__4390__auto____$1,entry__4391__auto__);
}
});

shadow.dom.Coordinate.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"x","x",-555367584,null),new cljs.core.Symbol(null,"y","y",-117328249,null)], null);
});

shadow.dom.Coordinate.cljs$lang$type = true;

shadow.dom.Coordinate.cljs$lang$ctorPrSeq = (function (this__4428__auto__){
return (new cljs.core.List(null,"shadow.dom/Coordinate",null,(1),null));
});

shadow.dom.Coordinate.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__){
return cljs.core._write(writer__4429__auto__,"shadow.dom/Coordinate");
});

/**
 * Positional factory function for shadow.dom/Coordinate.
 */
shadow.dom.__GT_Coordinate = (function shadow$dom$__GT_Coordinate(x,y){
return (new shadow.dom.Coordinate(x,y,null,null,null));
});

/**
 * Factory function for shadow.dom/Coordinate, taking a map of keywords to field values.
 */
shadow.dom.map__GT_Coordinate = (function shadow$dom$map__GT_Coordinate(G__53005){
var extmap__4424__auto__ = (function (){var G__53025 = cljs.core.dissoc.cljs$core$IFn$_invoke$arity$variadic(G__53005,new cljs.core.Keyword(null,"x","x",2099068185),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"y","y",-1757859776)], 0));
if(cljs.core.record_QMARK_(G__53005)){
return cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,G__53025);
} else {
return G__53025;
}
})();
return (new shadow.dom.Coordinate(new cljs.core.Keyword(null,"x","x",2099068185).cljs$core$IFn$_invoke$arity$1(G__53005),new cljs.core.Keyword(null,"y","y",-1757859776).cljs$core$IFn$_invoke$arity$1(G__53005),null,cljs.core.not_empty(extmap__4424__auto__),null));
});

shadow.dom.get_position = (function shadow$dom$get_position(el){
var pos = (function (){var G__53031 = shadow.dom.dom_node(el);
return goog.style.getPosition(G__53031);
})();
return shadow.dom.__GT_Coordinate(pos.x,pos.y);
});
shadow.dom.get_client_position = (function shadow$dom$get_client_position(el){
var pos = (function (){var G__53033 = shadow.dom.dom_node(el);
return goog.style.getClientPosition(G__53033);
})();
return shadow.dom.__GT_Coordinate(pos.x,pos.y);
});
shadow.dom.get_page_offset = (function shadow$dom$get_page_offset(el){
var pos = (function (){var G__53036 = shadow.dom.dom_node(el);
return goog.style.getPageOffset(G__53036);
})();
return shadow.dom.__GT_Coordinate(pos.x,pos.y);
});

/**
* @constructor
 * @implements {cljs.core.IRecord}
 * @implements {cljs.core.IKVReduce}
 * @implements {cljs.core.IEquiv}
 * @implements {cljs.core.IHash}
 * @implements {cljs.core.ICollection}
 * @implements {cljs.core.ICounted}
 * @implements {cljs.core.ISeqable}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.ICloneable}
 * @implements {cljs.core.IPrintWithWriter}
 * @implements {cljs.core.IIterable}
 * @implements {cljs.core.IWithMeta}
 * @implements {cljs.core.IAssociative}
 * @implements {cljs.core.IMap}
 * @implements {cljs.core.ILookup}
*/
shadow.dom.Size = (function (w,h,__meta,__extmap,__hash){
this.w = w;
this.h = h;
this.__meta = __meta;
this.__extmap = __extmap;
this.__hash = __hash;
this.cljs$lang$protocol_mask$partition0$ = 2230716170;
this.cljs$lang$protocol_mask$partition1$ = 139264;
});
shadow.dom.Size.prototype.cljs$core$ILookup$_lookup$arity$2 = (function (this__4385__auto__,k__4386__auto__){
var self__ = this;
var this__4385__auto____$1 = this;
return this__4385__auto____$1.cljs$core$ILookup$_lookup$arity$3(null,k__4386__auto__,null);
});

shadow.dom.Size.prototype.cljs$core$ILookup$_lookup$arity$3 = (function (this__4387__auto__,k53038,else__4388__auto__){
var self__ = this;
var this__4387__auto____$1 = this;
var G__53047 = k53038;
var G__53047__$1 = (((G__53047 instanceof cljs.core.Keyword))?G__53047.fqn:null);
switch (G__53047__$1) {
case "w":
return self__.w;

break;
case "h":
return self__.h;

break;
default:
return cljs.core.get.cljs$core$IFn$_invoke$arity$3(self__.__extmap,k53038,else__4388__auto__);

}
});

shadow.dom.Size.prototype.cljs$core$IKVReduce$_kv_reduce$arity$3 = (function (this__4404__auto__,f__4405__auto__,init__4406__auto__){
var self__ = this;
var this__4404__auto____$1 = this;
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(((function (this__4404__auto____$1){
return (function (ret__4407__auto__,p__53050){
var vec__53052 = p__53050;
var k__4408__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53052,(0),null);
var v__4409__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53052,(1),null);
return (f__4405__auto__.cljs$core$IFn$_invoke$arity$3 ? f__4405__auto__.cljs$core$IFn$_invoke$arity$3(ret__4407__auto__,k__4408__auto__,v__4409__auto__) : f__4405__auto__.call(null,ret__4407__auto__,k__4408__auto__,v__4409__auto__));
});})(this__4404__auto____$1))
,init__4406__auto__,this__4404__auto____$1);
});

shadow.dom.Size.prototype.cljs$core$IPrintWithWriter$_pr_writer$arity$3 = (function (this__4399__auto__,writer__4400__auto__,opts__4401__auto__){
var self__ = this;
var this__4399__auto____$1 = this;
var pr_pair__4402__auto__ = ((function (this__4399__auto____$1){
return (function (keyval__4403__auto__){
return cljs.core.pr_sequential_writer(writer__4400__auto__,cljs.core.pr_writer,""," ","",opts__4401__auto__,keyval__4403__auto__);
});})(this__4399__auto____$1))
;
return cljs.core.pr_sequential_writer(writer__4400__auto__,pr_pair__4402__auto__,"#shadow.dom.Size{",", ","}",opts__4401__auto__,cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"w","w",354169001),self__.w],null)),(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"h","h",1109658740),self__.h],null))], null),self__.__extmap));
});

shadow.dom.Size.prototype.cljs$core$IIterable$_iterator$arity$1 = (function (G__53037){
var self__ = this;
var G__53037__$1 = this;
return (new cljs.core.RecordIter((0),G__53037__$1,2,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"w","w",354169001),new cljs.core.Keyword(null,"h","h",1109658740)], null),(cljs.core.truth_(self__.__extmap)?cljs.core._iterator(self__.__extmap):cljs.core.nil_iter())));
});

shadow.dom.Size.prototype.cljs$core$IMeta$_meta$arity$1 = (function (this__4383__auto__){
var self__ = this;
var this__4383__auto____$1 = this;
return self__.__meta;
});

shadow.dom.Size.prototype.cljs$core$ICloneable$_clone$arity$1 = (function (this__4380__auto__){
var self__ = this;
var this__4380__auto____$1 = this;
return (new shadow.dom.Size(self__.w,self__.h,self__.__meta,self__.__extmap,self__.__hash));
});

shadow.dom.Size.prototype.cljs$core$ICounted$_count$arity$1 = (function (this__4389__auto__){
var self__ = this;
var this__4389__auto____$1 = this;
return (2 + cljs.core.count(self__.__extmap));
});

shadow.dom.Size.prototype.cljs$core$IHash$_hash$arity$1 = (function (this__4381__auto__){
var self__ = this;
var this__4381__auto____$1 = this;
var h__4243__auto__ = self__.__hash;
if((!((h__4243__auto__ == null)))){
return h__4243__auto__;
} else {
var h__4243__auto____$1 = (function (){var fexpr__53064 = ((function (h__4243__auto__,this__4381__auto____$1){
return (function (coll__4382__auto__){
return (-1228019642 ^ cljs.core.hash_unordered_coll(coll__4382__auto__));
});})(h__4243__auto__,this__4381__auto____$1))
;
return fexpr__53064(this__4381__auto____$1);
})();
self__.__hash = h__4243__auto____$1;

return h__4243__auto____$1;
}
});

shadow.dom.Size.prototype.cljs$core$IEquiv$_equiv$arity$2 = (function (this53039,other53040){
var self__ = this;
var this53039__$1 = this;
return (((!((other53040 == null)))) && ((this53039__$1.constructor === other53040.constructor)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this53039__$1.w,other53040.w)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this53039__$1.h,other53040.h)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this53039__$1.__extmap,other53040.__extmap)));
});

shadow.dom.Size.prototype.cljs$core$IMap$_dissoc$arity$2 = (function (this__4394__auto__,k__4395__auto__){
var self__ = this;
var this__4394__auto____$1 = this;
if(cljs.core.contains_QMARK_(new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"w","w",354169001),null,new cljs.core.Keyword(null,"h","h",1109658740),null], null), null),k__4395__auto__)){
return cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(cljs.core._with_meta(cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,this__4394__auto____$1),self__.__meta),k__4395__auto__);
} else {
return (new shadow.dom.Size(self__.w,self__.h,self__.__meta,cljs.core.not_empty(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(self__.__extmap,k__4395__auto__)),null));
}
});

shadow.dom.Size.prototype.cljs$core$IAssociative$_assoc$arity$3 = (function (this__4392__auto__,k__4393__auto__,G__53037){
var self__ = this;
var this__4392__auto____$1 = this;
var pred__53073 = cljs.core.keyword_identical_QMARK_;
var expr__53074 = k__4393__auto__;
if(cljs.core.truth_((function (){var G__53076 = new cljs.core.Keyword(null,"w","w",354169001);
var G__53077 = expr__53074;
return (pred__53073.cljs$core$IFn$_invoke$arity$2 ? pred__53073.cljs$core$IFn$_invoke$arity$2(G__53076,G__53077) : pred__53073.call(null,G__53076,G__53077));
})())){
return (new shadow.dom.Size(G__53037,self__.h,self__.__meta,self__.__extmap,null));
} else {
if(cljs.core.truth_((function (){var G__53079 = new cljs.core.Keyword(null,"h","h",1109658740);
var G__53080 = expr__53074;
return (pred__53073.cljs$core$IFn$_invoke$arity$2 ? pred__53073.cljs$core$IFn$_invoke$arity$2(G__53079,G__53080) : pred__53073.call(null,G__53079,G__53080));
})())){
return (new shadow.dom.Size(self__.w,G__53037,self__.__meta,self__.__extmap,null));
} else {
return (new shadow.dom.Size(self__.w,self__.h,self__.__meta,cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(self__.__extmap,k__4393__auto__,G__53037),null));
}
}
});

shadow.dom.Size.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (this__4397__auto__){
var self__ = this;
var this__4397__auto____$1 = this;
return cljs.core.seq(cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.MapEntry(new cljs.core.Keyword(null,"w","w",354169001),self__.w,null)),(new cljs.core.MapEntry(new cljs.core.Keyword(null,"h","h",1109658740),self__.h,null))], null),self__.__extmap));
});

shadow.dom.Size.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (this__4384__auto__,G__53037){
var self__ = this;
var this__4384__auto____$1 = this;
return (new shadow.dom.Size(self__.w,self__.h,G__53037,self__.__extmap,self__.__hash));
});

shadow.dom.Size.prototype.cljs$core$ICollection$_conj$arity$2 = (function (this__4390__auto__,entry__4391__auto__){
var self__ = this;
var this__4390__auto____$1 = this;
if(cljs.core.vector_QMARK_(entry__4391__auto__)){
return this__4390__auto____$1.cljs$core$IAssociative$_assoc$arity$3(null,cljs.core._nth.cljs$core$IFn$_invoke$arity$2(entry__4391__auto__,(0)),cljs.core._nth.cljs$core$IFn$_invoke$arity$2(entry__4391__auto__,(1)));
} else {
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(cljs.core._conj,this__4390__auto____$1,entry__4391__auto__);
}
});

shadow.dom.Size.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"w","w",1994700528,null),new cljs.core.Symbol(null,"h","h",-1544777029,null)], null);
});

shadow.dom.Size.cljs$lang$type = true;

shadow.dom.Size.cljs$lang$ctorPrSeq = (function (this__4428__auto__){
return (new cljs.core.List(null,"shadow.dom/Size",null,(1),null));
});

shadow.dom.Size.cljs$lang$ctorPrWriter = (function (this__4428__auto__,writer__4429__auto__){
return cljs.core._write(writer__4429__auto__,"shadow.dom/Size");
});

/**
 * Positional factory function for shadow.dom/Size.
 */
shadow.dom.__GT_Size = (function shadow$dom$__GT_Size(w,h){
return (new shadow.dom.Size(w,h,null,null,null));
});

/**
 * Factory function for shadow.dom/Size, taking a map of keywords to field values.
 */
shadow.dom.map__GT_Size = (function shadow$dom$map__GT_Size(G__53042){
var extmap__4424__auto__ = (function (){var G__53087 = cljs.core.dissoc.cljs$core$IFn$_invoke$arity$variadic(G__53042,new cljs.core.Keyword(null,"w","w",354169001),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"h","h",1109658740)], 0));
if(cljs.core.record_QMARK_(G__53042)){
return cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,G__53087);
} else {
return G__53087;
}
})();
return (new shadow.dom.Size(new cljs.core.Keyword(null,"w","w",354169001).cljs$core$IFn$_invoke$arity$1(G__53042),new cljs.core.Keyword(null,"h","h",1109658740).cljs$core$IFn$_invoke$arity$1(G__53042),null,cljs.core.not_empty(extmap__4424__auto__),null));
});

shadow.dom.size__GT_clj = (function shadow$dom$size__GT_clj(size){
return (new shadow.dom.Size(size.width,size.height,null,null,null));
});
shadow.dom.get_size = (function shadow$dom$get_size(el){
return shadow.dom.size__GT_clj((function (){var G__53090 = shadow.dom.dom_node(el);
return goog.style.getSize(G__53090);
})());
});
shadow.dom.get_height = (function shadow$dom$get_height(el){
return new cljs.core.Keyword(null,"h","h",1109658740).cljs$core$IFn$_invoke$arity$1(shadow.dom.get_size(el));
});
shadow.dom.get_viewport_size = (function shadow$dom$get_viewport_size(){
return shadow.dom.size__GT_clj(goog.dom.getViewportSize());
});
shadow.dom.first_child = (function shadow$dom$first_child(el){
return (shadow.dom.dom_node(el).children[(0)]);
});
shadow.dom.select_option_values = (function shadow$dom$select_option_values(el){
var native$ = shadow.dom.dom_node(el);
var opts = (native$["options"]);
var a__4604__auto__ = opts;
var l__4605__auto__ = a__4604__auto__.length;
var i = (0);
var ret = cljs.core.PersistentVector.EMPTY;
while(true){
if((i < l__4605__auto__)){
var G__53643 = (i + (1));
var G__53644 = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,(opts[i]["value"]));
i = G__53643;
ret = G__53644;
continue;
} else {
return ret;
}
break;
}
});
shadow.dom.build_url = (function shadow$dom$build_url(path,query_params){
if(cljs.core.empty_QMARK_(query_params)){
return path;
} else {
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(path),"?",cljs.core.str.cljs$core$IFn$_invoke$arity$1(clojure.string.join.cljs$core$IFn$_invoke$arity$2("&",cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__53097){
var vec__53098 = p__53097;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53098,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53098,(1),null);
return [cljs.core.name(k),"=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(encodeURIComponent(cljs.core.str.cljs$core$IFn$_invoke$arity$1(v)))].join('');
}),query_params)))].join('');
}
});
shadow.dom.redirect = (function shadow$dom$redirect(var_args){
var G__53102 = arguments.length;
switch (G__53102) {
case 1:
return shadow.dom.redirect.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.redirect.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.redirect.cljs$core$IFn$_invoke$arity$1 = (function (path){
return shadow.dom.redirect.cljs$core$IFn$_invoke$arity$2(path,cljs.core.PersistentArrayMap.EMPTY);
});

shadow.dom.redirect.cljs$core$IFn$_invoke$arity$2 = (function (path,query_params){
return (document["location"]["href"] = shadow.dom.build_url(path,query_params));
});

shadow.dom.redirect.cljs$lang$maxFixedArity = 2;

shadow.dom.reload_BANG_ = (function shadow$dom$reload_BANG_(){
return document.location.href = document.location.href;
});
shadow.dom.tag_name = (function shadow$dom$tag_name(el){
var dom = shadow.dom.dom_node(el);
return dom.tagName;
});
shadow.dom.insert_after = (function shadow$dom$insert_after(ref,new$){
var new_node = shadow.dom.dom_node(new$);
var G__53104_53652 = new_node;
var G__53105_53653 = shadow.dom.dom_node(ref);
goog.dom.insertSiblingAfter(G__53104_53652,G__53105_53653);

return new_node;
});
shadow.dom.insert_before = (function shadow$dom$insert_before(ref,new$){
var new_node = shadow.dom.dom_node(new$);
var G__53106_53658 = new_node;
var G__53107_53659 = shadow.dom.dom_node(ref);
goog.dom.insertSiblingBefore(G__53106_53658,G__53107_53659);

return new_node;
});
shadow.dom.insert_first = (function shadow$dom$insert_first(ref,new$){
var temp__5733__auto__ = shadow.dom.dom_node(ref).firstChild;
if(cljs.core.truth_(temp__5733__auto__)){
var child = temp__5733__auto__;
return shadow.dom.insert_before(child,new$);
} else {
return shadow.dom.append.cljs$core$IFn$_invoke$arity$2(ref,new$);
}
});
shadow.dom.index_of = (function shadow$dom$index_of(el){
var el__$1 = shadow.dom.dom_node(el);
var i = (0);
while(true){
var ps = el__$1.previousSibling;
if((ps == null)){
return i;
} else {
var G__53661 = ps;
var G__53662 = (i + (1));
el__$1 = G__53661;
i = G__53662;
continue;
}
break;
}
});
shadow.dom.get_parent = (function shadow$dom$get_parent(el){
var G__53112 = shadow.dom.dom_node(el);
return goog.dom.getParentElement(G__53112);
});
shadow.dom.parents = (function shadow$dom$parents(el){
var parent = shadow.dom.get_parent(el);
if(cljs.core.truth_(parent)){
return cljs.core.cons(parent,(new cljs.core.LazySeq(null,((function (parent){
return (function (){
return (shadow.dom.parents.cljs$core$IFn$_invoke$arity$1 ? shadow.dom.parents.cljs$core$IFn$_invoke$arity$1(parent) : shadow.dom.parents.call(null,parent));
});})(parent))
,null,null)));
} else {
return null;
}
});
shadow.dom.matches = (function shadow$dom$matches(el,sel){
return shadow.dom.dom_node(el).matches(sel);
});
shadow.dom.get_next_sibling = (function shadow$dom$get_next_sibling(el){
var G__53118 = shadow.dom.dom_node(el);
return goog.dom.getNextElementSibling(G__53118);
});
shadow.dom.get_previous_sibling = (function shadow$dom$get_previous_sibling(el){
var G__53122 = shadow.dom.dom_node(el);
return goog.dom.getPreviousElementSibling(G__53122);
});
shadow.dom.xmlns = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentArrayMap(null, 2, ["svg","http://www.w3.org/2000/svg","xlink","http://www.w3.org/1999/xlink"], null));
shadow.dom.create_svg_node = (function shadow$dom$create_svg_node(tag_def,props){
var vec__53126 = shadow.dom.parse_tag(tag_def);
var tag_name = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53126,(0),null);
var tag_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53126,(1),null);
var tag_classes = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53126,(2),null);
var el = document.createElementNS("http://www.w3.org/2000/svg",tag_name);
if(cljs.core.truth_(tag_id)){
el.setAttribute("id",tag_id);
} else {
}

if(cljs.core.truth_(tag_classes)){
el.setAttribute("class",shadow.dom.merge_class_string(new cljs.core.Keyword(null,"class","class",-2030961996).cljs$core$IFn$_invoke$arity$1(props),tag_classes));
} else {
}

var seq__53130_53668 = cljs.core.seq(props);
var chunk__53131_53669 = null;
var count__53132_53670 = (0);
var i__53133_53671 = (0);
while(true){
if((i__53133_53671 < count__53132_53670)){
var vec__53144_53672 = chunk__53131_53669.cljs$core$IIndexed$_nth$arity$2(null,i__53133_53671);
var k_53673 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53144_53672,(0),null);
var v_53674 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53144_53672,(1),null);
el.setAttributeNS((function (){var temp__5735__auto__ = cljs.core.namespace(k_53673);
if(cljs.core.truth_(temp__5735__auto__)){
var ns = temp__5735__auto__;
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(shadow.dom.xmlns),ns);
} else {
return null;
}
})(),cljs.core.name(k_53673),v_53674);


var G__53676 = seq__53130_53668;
var G__53677 = chunk__53131_53669;
var G__53678 = count__53132_53670;
var G__53679 = (i__53133_53671 + (1));
seq__53130_53668 = G__53676;
chunk__53131_53669 = G__53677;
count__53132_53670 = G__53678;
i__53133_53671 = G__53679;
continue;
} else {
var temp__5735__auto___53680 = cljs.core.seq(seq__53130_53668);
if(temp__5735__auto___53680){
var seq__53130_53681__$1 = temp__5735__auto___53680;
if(cljs.core.chunked_seq_QMARK_(seq__53130_53681__$1)){
var c__4550__auto___53682 = cljs.core.chunk_first(seq__53130_53681__$1);
var G__53683 = cljs.core.chunk_rest(seq__53130_53681__$1);
var G__53684 = c__4550__auto___53682;
var G__53685 = cljs.core.count(c__4550__auto___53682);
var G__53686 = (0);
seq__53130_53668 = G__53683;
chunk__53131_53669 = G__53684;
count__53132_53670 = G__53685;
i__53133_53671 = G__53686;
continue;
} else {
var vec__53150_53687 = cljs.core.first(seq__53130_53681__$1);
var k_53688 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53150_53687,(0),null);
var v_53689 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53150_53687,(1),null);
el.setAttributeNS((function (){var temp__5735__auto____$1 = cljs.core.namespace(k_53688);
if(cljs.core.truth_(temp__5735__auto____$1)){
var ns = temp__5735__auto____$1;
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(shadow.dom.xmlns),ns);
} else {
return null;
}
})(),cljs.core.name(k_53688),v_53689);


var G__53690 = cljs.core.next(seq__53130_53681__$1);
var G__53691 = null;
var G__53692 = (0);
var G__53693 = (0);
seq__53130_53668 = G__53690;
chunk__53131_53669 = G__53691;
count__53132_53670 = G__53692;
i__53133_53671 = G__53693;
continue;
}
} else {
}
}
break;
}

return el;
});
shadow.dom.svg_node = (function shadow$dom$svg_node(el){
if((el == null)){
return null;
} else {
if((((!((el == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === el.shadow$dom$SVGElement$))))?true:false):false)){
return el.shadow$dom$SVGElement$_to_svg$arity$1(null);
} else {
return el;

}
}
});
shadow.dom.make_svg_node = (function shadow$dom$make_svg_node(structure){
var vec__53156 = shadow.dom.destructure_node(shadow.dom.create_svg_node,structure);
var node = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53156,(0),null);
var node_children = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__53156,(1),null);
var seq__53159_53697 = cljs.core.seq(node_children);
var chunk__53161_53698 = null;
var count__53162_53699 = (0);
var i__53163_53700 = (0);
while(true){
if((i__53163_53700 < count__53162_53699)){
var child_struct_53705 = chunk__53161_53698.cljs$core$IIndexed$_nth$arity$2(null,i__53163_53700);
if((!((child_struct_53705 == null)))){
if(typeof child_struct_53705 === 'string'){
var text_53706 = (node["textContent"]);
(node["textContent"] = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(text_53706),child_struct_53705].join(''));
} else {
var children_53707 = shadow.dom.svg_node(child_struct_53705);
if(cljs.core.seq_QMARK_(children_53707)){
var seq__53186_53708 = cljs.core.seq(children_53707);
var chunk__53188_53709 = null;
var count__53189_53710 = (0);
var i__53190_53711 = (0);
while(true){
if((i__53190_53711 < count__53189_53710)){
var child_53712 = chunk__53188_53709.cljs$core$IIndexed$_nth$arity$2(null,i__53190_53711);
if(cljs.core.truth_(child_53712)){
node.appendChild(child_53712);


var G__53713 = seq__53186_53708;
var G__53714 = chunk__53188_53709;
var G__53715 = count__53189_53710;
var G__53716 = (i__53190_53711 + (1));
seq__53186_53708 = G__53713;
chunk__53188_53709 = G__53714;
count__53189_53710 = G__53715;
i__53190_53711 = G__53716;
continue;
} else {
var G__53717 = seq__53186_53708;
var G__53718 = chunk__53188_53709;
var G__53719 = count__53189_53710;
var G__53720 = (i__53190_53711 + (1));
seq__53186_53708 = G__53717;
chunk__53188_53709 = G__53718;
count__53189_53710 = G__53719;
i__53190_53711 = G__53720;
continue;
}
} else {
var temp__5735__auto___53721 = cljs.core.seq(seq__53186_53708);
if(temp__5735__auto___53721){
var seq__53186_53722__$1 = temp__5735__auto___53721;
if(cljs.core.chunked_seq_QMARK_(seq__53186_53722__$1)){
var c__4550__auto___53723 = cljs.core.chunk_first(seq__53186_53722__$1);
var G__53724 = cljs.core.chunk_rest(seq__53186_53722__$1);
var G__53725 = c__4550__auto___53723;
var G__53726 = cljs.core.count(c__4550__auto___53723);
var G__53727 = (0);
seq__53186_53708 = G__53724;
chunk__53188_53709 = G__53725;
count__53189_53710 = G__53726;
i__53190_53711 = G__53727;
continue;
} else {
var child_53728 = cljs.core.first(seq__53186_53722__$1);
if(cljs.core.truth_(child_53728)){
node.appendChild(child_53728);


var G__53729 = cljs.core.next(seq__53186_53722__$1);
var G__53730 = null;
var G__53731 = (0);
var G__53732 = (0);
seq__53186_53708 = G__53729;
chunk__53188_53709 = G__53730;
count__53189_53710 = G__53731;
i__53190_53711 = G__53732;
continue;
} else {
var G__53733 = cljs.core.next(seq__53186_53722__$1);
var G__53734 = null;
var G__53735 = (0);
var G__53736 = (0);
seq__53186_53708 = G__53733;
chunk__53188_53709 = G__53734;
count__53189_53710 = G__53735;
i__53190_53711 = G__53736;
continue;
}
}
} else {
}
}
break;
}
} else {
node.appendChild(children_53707);
}
}


var G__53737 = seq__53159_53697;
var G__53738 = chunk__53161_53698;
var G__53739 = count__53162_53699;
var G__53740 = (i__53163_53700 + (1));
seq__53159_53697 = G__53737;
chunk__53161_53698 = G__53738;
count__53162_53699 = G__53739;
i__53163_53700 = G__53740;
continue;
} else {
var G__53741 = seq__53159_53697;
var G__53742 = chunk__53161_53698;
var G__53743 = count__53162_53699;
var G__53744 = (i__53163_53700 + (1));
seq__53159_53697 = G__53741;
chunk__53161_53698 = G__53742;
count__53162_53699 = G__53743;
i__53163_53700 = G__53744;
continue;
}
} else {
var temp__5735__auto___53745 = cljs.core.seq(seq__53159_53697);
if(temp__5735__auto___53745){
var seq__53159_53746__$1 = temp__5735__auto___53745;
if(cljs.core.chunked_seq_QMARK_(seq__53159_53746__$1)){
var c__4550__auto___53747 = cljs.core.chunk_first(seq__53159_53746__$1);
var G__53748 = cljs.core.chunk_rest(seq__53159_53746__$1);
var G__53749 = c__4550__auto___53747;
var G__53750 = cljs.core.count(c__4550__auto___53747);
var G__53751 = (0);
seq__53159_53697 = G__53748;
chunk__53161_53698 = G__53749;
count__53162_53699 = G__53750;
i__53163_53700 = G__53751;
continue;
} else {
var child_struct_53752 = cljs.core.first(seq__53159_53746__$1);
if((!((child_struct_53752 == null)))){
if(typeof child_struct_53752 === 'string'){
var text_53753 = (node["textContent"]);
(node["textContent"] = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(text_53753),child_struct_53752].join(''));
} else {
var children_53754 = shadow.dom.svg_node(child_struct_53752);
if(cljs.core.seq_QMARK_(children_53754)){
var seq__53202_53755 = cljs.core.seq(children_53754);
var chunk__53204_53756 = null;
var count__53205_53757 = (0);
var i__53206_53758 = (0);
while(true){
if((i__53206_53758 < count__53205_53757)){
var child_53759 = chunk__53204_53756.cljs$core$IIndexed$_nth$arity$2(null,i__53206_53758);
if(cljs.core.truth_(child_53759)){
node.appendChild(child_53759);


var G__53760 = seq__53202_53755;
var G__53761 = chunk__53204_53756;
var G__53762 = count__53205_53757;
var G__53763 = (i__53206_53758 + (1));
seq__53202_53755 = G__53760;
chunk__53204_53756 = G__53761;
count__53205_53757 = G__53762;
i__53206_53758 = G__53763;
continue;
} else {
var G__53765 = seq__53202_53755;
var G__53766 = chunk__53204_53756;
var G__53767 = count__53205_53757;
var G__53768 = (i__53206_53758 + (1));
seq__53202_53755 = G__53765;
chunk__53204_53756 = G__53766;
count__53205_53757 = G__53767;
i__53206_53758 = G__53768;
continue;
}
} else {
var temp__5735__auto___53769__$1 = cljs.core.seq(seq__53202_53755);
if(temp__5735__auto___53769__$1){
var seq__53202_53770__$1 = temp__5735__auto___53769__$1;
if(cljs.core.chunked_seq_QMARK_(seq__53202_53770__$1)){
var c__4550__auto___53771 = cljs.core.chunk_first(seq__53202_53770__$1);
var G__53772 = cljs.core.chunk_rest(seq__53202_53770__$1);
var G__53773 = c__4550__auto___53771;
var G__53774 = cljs.core.count(c__4550__auto___53771);
var G__53775 = (0);
seq__53202_53755 = G__53772;
chunk__53204_53756 = G__53773;
count__53205_53757 = G__53774;
i__53206_53758 = G__53775;
continue;
} else {
var child_53776 = cljs.core.first(seq__53202_53770__$1);
if(cljs.core.truth_(child_53776)){
node.appendChild(child_53776);


var G__53777 = cljs.core.next(seq__53202_53770__$1);
var G__53778 = null;
var G__53779 = (0);
var G__53780 = (0);
seq__53202_53755 = G__53777;
chunk__53204_53756 = G__53778;
count__53205_53757 = G__53779;
i__53206_53758 = G__53780;
continue;
} else {
var G__53781 = cljs.core.next(seq__53202_53770__$1);
var G__53782 = null;
var G__53783 = (0);
var G__53784 = (0);
seq__53202_53755 = G__53781;
chunk__53204_53756 = G__53782;
count__53205_53757 = G__53783;
i__53206_53758 = G__53784;
continue;
}
}
} else {
}
}
break;
}
} else {
node.appendChild(children_53754);
}
}


var G__53785 = cljs.core.next(seq__53159_53746__$1);
var G__53786 = null;
var G__53787 = (0);
var G__53788 = (0);
seq__53159_53697 = G__53785;
chunk__53161_53698 = G__53786;
count__53162_53699 = G__53787;
i__53163_53700 = G__53788;
continue;
} else {
var G__53789 = cljs.core.next(seq__53159_53746__$1);
var G__53790 = null;
var G__53791 = (0);
var G__53792 = (0);
seq__53159_53697 = G__53789;
chunk__53161_53698 = G__53790;
count__53162_53699 = G__53791;
i__53163_53700 = G__53792;
continue;
}
}
} else {
}
}
break;
}

return node;
});
goog.object.set(shadow.dom.SVGElement,"string",true);

var G__53212_53794 = shadow.dom._to_svg;
var G__53213_53795 = "string";
var G__53214_53796 = ((function (G__53212_53794,G__53213_53795){
return (function (this$){
if((this$ instanceof cljs.core.Keyword)){
return shadow.dom.make_svg_node(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [this$], null));
} else {
throw cljs.core.ex_info.cljs$core$IFn$_invoke$arity$2("strings cannot be in svgs",new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"this","this",-611633625),this$], null));
}
});})(G__53212_53794,G__53213_53795))
;
goog.object.set(G__53212_53794,G__53213_53795,G__53214_53796);

cljs.core.PersistentVector.prototype.shadow$dom$SVGElement$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.PersistentVector.prototype.shadow$dom$SVGElement$_to_svg$arity$1 = (function (this$){
var this$__$1 = this;
return shadow.dom.make_svg_node(this$__$1);
});

cljs.core.LazySeq.prototype.shadow$dom$SVGElement$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.LazySeq.prototype.shadow$dom$SVGElement$_to_svg$arity$1 = (function (this$){
var this$__$1 = this;
return cljs.core.map.cljs$core$IFn$_invoke$arity$2(shadow.dom._to_svg,this$__$1);
});

goog.object.set(shadow.dom.SVGElement,"null",true);

var G__53217_53797 = shadow.dom._to_svg;
var G__53218_53798 = "null";
var G__53219_53799 = ((function (G__53217_53797,G__53218_53798){
return (function (_){
return null;
});})(G__53217_53797,G__53218_53798))
;
goog.object.set(G__53217_53797,G__53218_53798,G__53219_53799);
shadow.dom.svg = (function shadow$dom$svg(var_args){
var args__4736__auto__ = [];
var len__4730__auto___53800 = arguments.length;
var i__4731__auto___53801 = (0);
while(true){
if((i__4731__auto___53801 < len__4730__auto___53800)){
args__4736__auto__.push((arguments[i__4731__auto___53801]));

var G__53802 = (i__4731__auto___53801 + (1));
i__4731__auto___53801 = G__53802;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return shadow.dom.svg.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

shadow.dom.svg.cljs$core$IFn$_invoke$arity$variadic = (function (attrs,children){
return shadow.dom._to_svg(cljs.core.vec(cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"svg","svg",856789142),attrs], null),children)));
});

shadow.dom.svg.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
shadow.dom.svg.cljs$lang$applyTo = (function (seq53222){
var G__53223 = cljs.core.first(seq53222);
var seq53222__$1 = cljs.core.next(seq53222);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__53223,seq53222__$1);
});

/**
 * returns a channel for events on el
 * transform-fn should be a (fn [e el] some-val) where some-val will be put on the chan
 * once-or-cleanup handles the removal of the event handler
 * - true: remove after one event
 * - false: never removed
 * - chan: remove on msg/close
 */
shadow.dom.event_chan = (function shadow$dom$event_chan(var_args){
var G__53229 = arguments.length;
switch (G__53229) {
case 2:
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$2 = (function (el,event){
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$4(el,event,null,false);
});

shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$3 = (function (el,event,xf){
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$4(el,event,xf,false);
});

shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$4 = (function (el,event,xf,once_or_cleanup){
var buf = cljs.core.async.sliding_buffer((1));
var chan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2(buf,xf);
var event_fn = ((function (buf,chan){
return (function shadow$dom$event_fn(e){
cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,e);

if(once_or_cleanup === true){
shadow.dom.remove_event_handler(el,event,shadow$dom$event_fn);

return cljs.core.async.close_BANG_(chan);
} else {
return null;
}
});})(buf,chan))
;
var G__53235_53804 = shadow.dom.dom_node(el);
var G__53236_53805 = cljs.core.name(event);
var G__53237_53806 = event_fn;
(shadow.dom.dom_listen.cljs$core$IFn$_invoke$arity$3 ? shadow.dom.dom_listen.cljs$core$IFn$_invoke$arity$3(G__53235_53804,G__53236_53805,G__53237_53806) : shadow.dom.dom_listen.call(null,G__53235_53804,G__53236_53805,G__53237_53806));

if(cljs.core.truth_((function (){var and__4120__auto__ = once_or_cleanup;
if(cljs.core.truth_(and__4120__auto__)){
return (!(once_or_cleanup === true));
} else {
return and__4120__auto__;
}
})())){
var c__51002__auto___53807 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53807,buf,chan,event_fn){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53807,buf,chan,event_fn){
return (function (state_53242){
var state_val_53244 = (state_53242[(1)]);
if((state_val_53244 === (1))){
var state_53242__$1 = state_53242;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_53242__$1,(2),once_or_cleanup);
} else {
if((state_val_53244 === (2))){
var inst_53239 = (state_53242[(2)]);
var inst_53240 = shadow.dom.remove_event_handler(el,event,event_fn);
var state_53242__$1 = (function (){var statearr_53246 = state_53242;
(statearr_53246[(7)] = inst_53239);

return statearr_53246;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_53242__$1,inst_53240);
} else {
return null;
}
}
});})(c__51002__auto___53807,buf,chan,event_fn))
;
return ((function (switch__50901__auto__,c__51002__auto___53807,buf,chan,event_fn){
return (function() {
var shadow$dom$state_machine__50902__auto__ = null;
var shadow$dom$state_machine__50902__auto____0 = (function (){
var statearr_53247 = [null,null,null,null,null,null,null,null];
(statearr_53247[(0)] = shadow$dom$state_machine__50902__auto__);

(statearr_53247[(1)] = (1));

return statearr_53247;
});
var shadow$dom$state_machine__50902__auto____1 = (function (state_53242){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_53242);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e53249){if((e53249 instanceof Object)){
var ex__50905__auto__ = e53249;
var statearr_53250_53816 = state_53242;
(statearr_53250_53816[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_53242);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e53249;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53817 = state_53242;
state_53242 = G__53817;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
shadow$dom$state_machine__50902__auto__ = function(state_53242){
switch(arguments.length){
case 0:
return shadow$dom$state_machine__50902__auto____0.call(this);
case 1:
return shadow$dom$state_machine__50902__auto____1.call(this,state_53242);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
shadow$dom$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = shadow$dom$state_machine__50902__auto____0;
shadow$dom$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = shadow$dom$state_machine__50902__auto____1;
return shadow$dom$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53807,buf,chan,event_fn))
})();
var state__51004__auto__ = (function (){var statearr_53251 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_53251[(6)] = c__51002__auto___53807);

return statearr_53251;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53807,buf,chan,event_fn))
);

} else {
}

return chan;
});

shadow.dom.event_chan.cljs$lang$maxFixedArity = 4;


//# sourceMappingURL=shadow.dom.js.map
