goog.provide('test_reframe.events');
goog.require('cljs.core');
goog.require('re_frame.core');
goog.require('test_reframe.db');
re_frame.core.reg_event_db.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword("test-reframe.events","initialize-db","test-reframe.events/initialize-db",415079592),(function (_,___$1){
return test_reframe.db.default_db;
}));
re_frame.core.reg_event_db.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword("test-reframe.events","click","test-reframe.events/click",-1023537095),(function (db,_){
return cljs.core.update_in.cljs$core$IFn$_invoke$arity$3(db,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"click","click",1912301393)], null),cljs.core.inc);
}));
re_frame.core.reg_event_db.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword("test-reframe.events","shuffle","test-reframe.events/shuffle",1379187784),(function (db,_){
return cljs.core.update_in.cljs$core$IFn$_invoke$arity$3(db,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"data","data",-232669377)], null),cljs.core.shuffle);
}));

//# sourceMappingURL=test_reframe.events.js.map
