goog.provide('test_reframe.core');
goog.require('cljs.core');
goog.require('reagent.core');
goog.require('re_frame.core');
goog.require('test_reframe.events');
goog.require('test_reframe.views');
goog.require('test_reframe.config');
test_reframe.core.dev_setup = (function test_reframe$core$dev_setup(){
if(test_reframe.config.debug_QMARK_){
return cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["dev mode"], 0));
} else {
return null;
}
});
test_reframe.core.mount_root = (function test_reframe$core$mount_root(){
(re_frame.core.clear_subscription_cache_BANG_.cljs$core$IFn$_invoke$arity$0 ? re_frame.core.clear_subscription_cache_BANG_.cljs$core$IFn$_invoke$arity$0() : re_frame.core.clear_subscription_cache_BANG_.call(null));

return reagent.core.render.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [test_reframe.views.main_panel], null),document.getElementById("app"));
});
test_reframe.core.init = (function test_reframe$core$init(){
var G__44061_44062 = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("test-reframe.events","initialize-db","test-reframe.events/initialize-db",415079592)], null);
(re_frame.core.dispatch_sync.cljs$core$IFn$_invoke$arity$1 ? re_frame.core.dispatch_sync.cljs$core$IFn$_invoke$arity$1(G__44061_44062) : re_frame.core.dispatch_sync.call(null,G__44061_44062));

test_reframe.core.dev_setup();

return test_reframe.core.mount_root();
});

//# sourceMappingURL=test_reframe.core.js.map
