goog.provide("goog.math.IRect");
/** @record */ goog.math.IRect = function() {
};
/** @type {number} */ goog.math.IRect.prototype.left;
/** @type {number} */ goog.math.IRect.prototype.top;
/** @type {number} */ goog.math.IRect.prototype.width;
/** @type {number} */ goog.math.IRect.prototype.height;

//# sourceMappingURL=goog.math.irect.js.map
