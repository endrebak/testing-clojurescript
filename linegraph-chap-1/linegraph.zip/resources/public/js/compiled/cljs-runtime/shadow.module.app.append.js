
test_reframe.core.init();
shadow.cljs.devtools.client.browser.module_loaded('app');
