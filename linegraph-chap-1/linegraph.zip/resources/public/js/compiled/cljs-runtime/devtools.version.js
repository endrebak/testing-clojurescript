goog.provide('devtools.version');
goog.require('cljs.core');
devtools.version.current_version = "0.9.10";
devtools.version.get_current_version = (function devtools$version$get_current_version(){
return devtools.version.current_version;
});

//# sourceMappingURL=devtools.version.js.map
