goog.provide("goog.dom.HtmlElement");
/**
 * @constructor
 * @extends {HTMLElement}
 */
goog.dom.HtmlElement = function() {
};

//# sourceMappingURL=goog.dom.htmlelement.js.map
