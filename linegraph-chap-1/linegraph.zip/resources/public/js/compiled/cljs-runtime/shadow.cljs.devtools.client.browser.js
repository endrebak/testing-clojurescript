goog.provide('shadow.cljs.devtools.client.browser');
goog.require('cljs.core');
goog.require('cljs.reader');
goog.require('clojure.string');
goog.require('goog.dom');
goog.require('goog.userAgent.product');
goog.require('goog.Uri');
goog.require('goog.net.XhrIo');
goog.require('shadow.cljs.devtools.client.env');
goog.require('shadow.cljs.devtools.client.console');
goog.require('shadow.cljs.devtools.client.hud');
if((typeof shadow !== 'undefined') && (typeof shadow.cljs !== 'undefined') && (typeof shadow.cljs.devtools !== 'undefined') && (typeof shadow.cljs.devtools.client !== 'undefined') && (typeof shadow.cljs.devtools.client.browser !== 'undefined') && (typeof shadow.cljs.devtools.client.browser.active_modules_ref !== 'undefined')){
} else {
shadow.cljs.devtools.client.browser.active_modules_ref = cljs.core.volatile_BANG_(cljs.core.PersistentHashSet.EMPTY);
}
if((typeof shadow !== 'undefined') && (typeof shadow.cljs !== 'undefined') && (typeof shadow.cljs.devtools !== 'undefined') && (typeof shadow.cljs.devtools.client !== 'undefined') && (typeof shadow.cljs.devtools.client.browser !== 'undefined') && (typeof shadow.cljs.devtools.client.browser.repl_ns_ref !== 'undefined')){
} else {
shadow.cljs.devtools.client.browser.repl_ns_ref = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
}
shadow.cljs.devtools.client.browser.module_loaded = (function shadow$cljs$devtools$client$browser$module_loaded(name){
return shadow.cljs.devtools.client.browser.active_modules_ref.cljs$core$IVolatile$_vreset_BANG_$arity$2(null,cljs.core.conj.cljs$core$IFn$_invoke$arity$2(shadow.cljs.devtools.client.browser.active_modules_ref.cljs$core$IDeref$_deref$arity$1(null),cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(name)));
});
if((typeof shadow !== 'undefined') && (typeof shadow.cljs !== 'undefined') && (typeof shadow.cljs.devtools !== 'undefined') && (typeof shadow.cljs.devtools.client !== 'undefined') && (typeof shadow.cljs.devtools.client.browser !== 'undefined') && (typeof shadow.cljs.devtools.client.browser.socket_ref !== 'undefined')){
} else {
shadow.cljs.devtools.client.browser.socket_ref = cljs.core.volatile_BANG_(null);
}
shadow.cljs.devtools.client.browser.devtools_msg = (function shadow$cljs$devtools$client$browser$devtools_msg(var_args){
var args__4736__auto__ = [];
var len__4730__auto___55695 = arguments.length;
var i__4731__auto___55696 = (0);
while(true){
if((i__4731__auto___55696 < len__4730__auto___55695)){
args__4736__auto__.push((arguments[i__4731__auto___55696]));

var G__55699 = (i__4731__auto___55696 + (1));
i__4731__auto___55696 = G__55699;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic = (function (msg,args){
return console.log.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(cljs.core.into.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [["%cshadow-cljs: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(msg)].join(''),"color: blue;"], null),args)));
});

shadow.cljs.devtools.client.browser.devtools_msg.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
shadow.cljs.devtools.client.browser.devtools_msg.cljs$lang$applyTo = (function (seq55159){
var G__55160 = cljs.core.first(seq55159);
var seq55159__$1 = cljs.core.next(seq55159);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__55160,seq55159__$1);
});

shadow.cljs.devtools.client.browser.ws_msg = (function shadow$cljs$devtools$client$browser$ws_msg(msg){
var temp__5733__auto__ = cljs.core.deref(shadow.cljs.devtools.client.browser.socket_ref);
if(cljs.core.truth_(temp__5733__auto__)){
var s = temp__5733__auto__;
return s.send(cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([msg], 0)));
} else {
return console.warn("WEBSOCKET NOT CONNECTED",cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([msg], 0)));
}
});
if((typeof shadow !== 'undefined') && (typeof shadow.cljs !== 'undefined') && (typeof shadow.cljs.devtools !== 'undefined') && (typeof shadow.cljs.devtools.client !== 'undefined') && (typeof shadow.cljs.devtools.client.browser !== 'undefined') && (typeof shadow.cljs.devtools.client.browser.scripts_to_load !== 'undefined')){
} else {
shadow.cljs.devtools.client.browser.scripts_to_load = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY);
}
shadow.cljs.devtools.client.browser.loaded_QMARK_ = goog.isProvided_;
shadow.cljs.devtools.client.browser.goog_is_loaded_QMARK_ = (function shadow$cljs$devtools$client$browser$goog_is_loaded_QMARK_(name){
return $CLJS.SHADOW_ENV.isLoaded(name);
});
shadow.cljs.devtools.client.browser.goog_base_rc = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("shadow.build.classpath","resource","shadow.build.classpath/resource",-879517823),"goog/base.js"], null);
shadow.cljs.devtools.client.browser.src_is_loaded_QMARK_ = (function shadow$cljs$devtools$client$browser$src_is_loaded_QMARK_(p__55202){
var map__55204 = p__55202;
var map__55204__$1 = (((((!((map__55204 == null))))?(((((map__55204.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55204.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55204):map__55204);
var src = map__55204__$1;
var resource_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55204__$1,new cljs.core.Keyword(null,"resource-id","resource-id",-1308422582));
var output_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55204__$1,new cljs.core.Keyword(null,"output-name","output-name",-1769107767));
var or__4131__auto__ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(shadow.cljs.devtools.client.browser.goog_base_rc,resource_id);
if(or__4131__auto__){
return or__4131__auto__;
} else {
return shadow.cljs.devtools.client.browser.goog_is_loaded_QMARK_(output_name);
}
});
shadow.cljs.devtools.client.browser.module_is_active_QMARK_ = (function shadow$cljs$devtools$client$browser$module_is_active_QMARK_(module){
return cljs.core.contains_QMARK_(cljs.core.deref(shadow.cljs.devtools.client.browser.active_modules_ref),module);
});
shadow.cljs.devtools.client.browser.script_eval = (function shadow$cljs$devtools$client$browser$script_eval(code){
return goog.globalEval(code);
});
shadow.cljs.devtools.client.browser.do_js_load = (function shadow$cljs$devtools$client$browser$do_js_load(sources){
var seq__55219 = cljs.core.seq(sources);
var chunk__55220 = null;
var count__55221 = (0);
var i__55222 = (0);
while(true){
if((i__55222 < count__55221)){
var map__55232 = chunk__55220.cljs$core$IIndexed$_nth$arity$2(null,i__55222);
var map__55232__$1 = (((((!((map__55232 == null))))?(((((map__55232.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55232.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55232):map__55232);
var src = map__55232__$1;
var resource_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55232__$1,new cljs.core.Keyword(null,"resource-id","resource-id",-1308422582));
var output_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55232__$1,new cljs.core.Keyword(null,"output-name","output-name",-1769107767));
var resource_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55232__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
var js = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55232__$1,new cljs.core.Keyword(null,"js","js",1768080579));
$CLJS.SHADOW_ENV.setLoaded(output_name);

shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load JS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([resource_name], 0));

shadow.cljs.devtools.client.env.before_load_src(src);

try{shadow.cljs.devtools.client.browser.script_eval([cljs.core.str.cljs$core$IFn$_invoke$arity$1(js),"\n//# sourceURL=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name)].join(''));
}catch (e55235){var e_55725 = e55235;
console.error(["Failed to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name)].join(''),e_55725);

throw (new Error(["Failed to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name),": ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(e_55725.message)].join('')));
}

var G__55728 = seq__55219;
var G__55729 = chunk__55220;
var G__55730 = count__55221;
var G__55731 = (i__55222 + (1));
seq__55219 = G__55728;
chunk__55220 = G__55729;
count__55221 = G__55730;
i__55222 = G__55731;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__55219);
if(temp__5735__auto__){
var seq__55219__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__55219__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__55219__$1);
var G__55732 = cljs.core.chunk_rest(seq__55219__$1);
var G__55733 = c__4550__auto__;
var G__55734 = cljs.core.count(c__4550__auto__);
var G__55735 = (0);
seq__55219 = G__55732;
chunk__55220 = G__55733;
count__55221 = G__55734;
i__55222 = G__55735;
continue;
} else {
var map__55241 = cljs.core.first(seq__55219__$1);
var map__55241__$1 = (((((!((map__55241 == null))))?(((((map__55241.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55241.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55241):map__55241);
var src = map__55241__$1;
var resource_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55241__$1,new cljs.core.Keyword(null,"resource-id","resource-id",-1308422582));
var output_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55241__$1,new cljs.core.Keyword(null,"output-name","output-name",-1769107767));
var resource_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55241__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
var js = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55241__$1,new cljs.core.Keyword(null,"js","js",1768080579));
$CLJS.SHADOW_ENV.setLoaded(output_name);

shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load JS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([resource_name], 0));

shadow.cljs.devtools.client.env.before_load_src(src);

try{shadow.cljs.devtools.client.browser.script_eval([cljs.core.str.cljs$core$IFn$_invoke$arity$1(js),"\n//# sourceURL=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name)].join(''));
}catch (e55243){var e_55761 = e55243;
console.error(["Failed to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name)].join(''),e_55761);

throw (new Error(["Failed to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name),": ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(e_55761.message)].join('')));
}

var G__55762 = cljs.core.next(seq__55219__$1);
var G__55763 = null;
var G__55764 = (0);
var G__55765 = (0);
seq__55219 = G__55762;
chunk__55220 = G__55763;
count__55221 = G__55764;
i__55222 = G__55765;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.cljs.devtools.client.browser.do_js_reload = (function shadow$cljs$devtools$client$browser$do_js_reload(msg,sources,complete_fn,failure_fn){
return shadow.cljs.devtools.client.env.do_js_reload.cljs$core$IFn$_invoke$arity$4(cljs.core.assoc.cljs$core$IFn$_invoke$arity$variadic(msg,new cljs.core.Keyword(null,"log-missing-fn","log-missing-fn",732676765),(function (fn_sym){
return shadow.cljs.devtools.client.browser.devtools_msg(["can't find fn ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(fn_sym)].join(''));
}),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"log-call-async","log-call-async",183826192),(function (fn_sym){
return shadow.cljs.devtools.client.browser.devtools_msg(["call async ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(fn_sym)].join(''));
}),new cljs.core.Keyword(null,"log-call","log-call",412404391),(function (fn_sym){
return shadow.cljs.devtools.client.browser.devtools_msg(["call ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(fn_sym)].join(''));
})], 0)),(function (){
return shadow.cljs.devtools.client.browser.do_js_load(sources);
}),complete_fn,failure_fn);
});
/**
 * when (require '["some-str" :as x]) is done at the REPL we need to manually call the shadow.js.require for it
 * since the file only adds the shadow$provide. only need to do this for shadow-js.
 */
shadow.cljs.devtools.client.browser.do_js_requires = (function shadow$cljs$devtools$client$browser$do_js_requires(js_requires){
var seq__55247 = cljs.core.seq(js_requires);
var chunk__55248 = null;
var count__55249 = (0);
var i__55250 = (0);
while(true){
if((i__55250 < count__55249)){
var js_ns = chunk__55248.cljs$core$IIndexed$_nth$arity$2(null,i__55250);
var require_str_55780 = ["var ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(js_ns)," = shadow.js.require(\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(js_ns),"\");"].join('');
shadow.cljs.devtools.client.browser.script_eval(require_str_55780);


var G__55783 = seq__55247;
var G__55784 = chunk__55248;
var G__55785 = count__55249;
var G__55786 = (i__55250 + (1));
seq__55247 = G__55783;
chunk__55248 = G__55784;
count__55249 = G__55785;
i__55250 = G__55786;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__55247);
if(temp__5735__auto__){
var seq__55247__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__55247__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__55247__$1);
var G__55793 = cljs.core.chunk_rest(seq__55247__$1);
var G__55794 = c__4550__auto__;
var G__55795 = cljs.core.count(c__4550__auto__);
var G__55796 = (0);
seq__55247 = G__55793;
chunk__55248 = G__55794;
count__55249 = G__55795;
i__55250 = G__55796;
continue;
} else {
var js_ns = cljs.core.first(seq__55247__$1);
var require_str_55799 = ["var ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(js_ns)," = shadow.js.require(\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(js_ns),"\");"].join('');
shadow.cljs.devtools.client.browser.script_eval(require_str_55799);


var G__55800 = cljs.core.next(seq__55247__$1);
var G__55801 = null;
var G__55802 = (0);
var G__55803 = (0);
seq__55247 = G__55800;
chunk__55248 = G__55801;
count__55249 = G__55802;
i__55250 = G__55803;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.cljs.devtools.client.browser.load_sources = (function shadow$cljs$devtools$client$browser$load_sources(sources,callback){
if(cljs.core.empty_QMARK_(sources)){
var G__55269 = cljs.core.PersistentVector.EMPTY;
return (callback.cljs$core$IFn$_invoke$arity$1 ? callback.cljs$core$IFn$_invoke$arity$1(G__55269) : callback.call(null,G__55269));
} else {
var G__55272 = shadow.cljs.devtools.client.env.files_url();
var G__55273 = ((function (G__55272){
return (function (res){
var req = this;
var content = cljs.reader.read_string.cljs$core$IFn$_invoke$arity$1(req.getResponseText());
return (callback.cljs$core$IFn$_invoke$arity$1 ? callback.cljs$core$IFn$_invoke$arity$1(content) : callback.call(null,content));
});})(G__55272))
;
var G__55274 = "POST";
var G__55275 = cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"client","client",-1323448117),new cljs.core.Keyword(null,"browser","browser",828191719),new cljs.core.Keyword(null,"sources","sources",-321166424),cljs.core.into.cljs$core$IFn$_invoke$arity$3(cljs.core.PersistentVector.EMPTY,cljs.core.map.cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"resource-id","resource-id",-1308422582)),sources)], null)], 0));
var G__55276 = ({"content-type": "application/edn; charset=utf-8"});
return goog.net.XhrIo.send(G__55272,G__55273,G__55274,G__55275,G__55276);
}
});
shadow.cljs.devtools.client.browser.handle_build_complete = (function shadow$cljs$devtools$client$browser$handle_build_complete(p__55290){
var map__55291 = p__55290;
var map__55291__$1 = (((((!((map__55291 == null))))?(((((map__55291.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55291.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55291):map__55291);
var msg = map__55291__$1;
var info = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55291__$1,new cljs.core.Keyword(null,"info","info",-317069002));
var reload_info = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55291__$1,new cljs.core.Keyword(null,"reload-info","reload-info",1648088086));
var map__55300 = info;
var map__55300__$1 = (((((!((map__55300 == null))))?(((((map__55300.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55300.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55300):map__55300);
var sources = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55300__$1,new cljs.core.Keyword(null,"sources","sources",-321166424));
var compiled = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55300__$1,new cljs.core.Keyword(null,"compiled","compiled",850043082));
var warnings = cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.distinct.cljs$core$IFn$_invoke$arity$1((function (){var iter__4523__auto__ = ((function (map__55300,map__55300__$1,sources,compiled,map__55291,map__55291__$1,msg,info,reload_info){
return (function shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__55303(s__55304){
return (new cljs.core.LazySeq(null,((function (map__55300,map__55300__$1,sources,compiled,map__55291,map__55291__$1,msg,info,reload_info){
return (function (){
var s__55304__$1 = s__55304;
while(true){
var temp__5735__auto__ = cljs.core.seq(s__55304__$1);
if(temp__5735__auto__){
var xs__6292__auto__ = temp__5735__auto__;
var map__55317 = cljs.core.first(xs__6292__auto__);
var map__55317__$1 = (((((!((map__55317 == null))))?(((((map__55317.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55317.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55317):map__55317);
var src = map__55317__$1;
var resource_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55317__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
var warnings = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55317__$1,new cljs.core.Keyword(null,"warnings","warnings",-735437651));
if(cljs.core.not(new cljs.core.Keyword(null,"from-jar","from-jar",1050932827).cljs$core$IFn$_invoke$arity$1(src))){
var iterys__4519__auto__ = ((function (s__55304__$1,map__55317,map__55317__$1,src,resource_name,warnings,xs__6292__auto__,temp__5735__auto__,map__55300,map__55300__$1,sources,compiled,map__55291,map__55291__$1,msg,info,reload_info){
return (function shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__55303_$_iter__55305(s__55306){
return (new cljs.core.LazySeq(null,((function (s__55304__$1,map__55317,map__55317__$1,src,resource_name,warnings,xs__6292__auto__,temp__5735__auto__,map__55300,map__55300__$1,sources,compiled,map__55291,map__55291__$1,msg,info,reload_info){
return (function (){
var s__55306__$1 = s__55306;
while(true){
var temp__5735__auto____$1 = cljs.core.seq(s__55306__$1);
if(temp__5735__auto____$1){
var s__55306__$2 = temp__5735__auto____$1;
if(cljs.core.chunked_seq_QMARK_(s__55306__$2)){
var c__4521__auto__ = cljs.core.chunk_first(s__55306__$2);
var size__4522__auto__ = cljs.core.count(c__4521__auto__);
var b__55308 = cljs.core.chunk_buffer(size__4522__auto__);
if((function (){var i__55307 = (0);
while(true){
if((i__55307 < size__4522__auto__)){
var warning = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__4521__auto__,i__55307);
cljs.core.chunk_append(b__55308,cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(warning,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100),resource_name));

var G__55845 = (i__55307 + (1));
i__55307 = G__55845;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__55308),shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__55303_$_iter__55305(cljs.core.chunk_rest(s__55306__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__55308),null);
}
} else {
var warning = cljs.core.first(s__55306__$2);
return cljs.core.cons(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(warning,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100),resource_name),shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__55303_$_iter__55305(cljs.core.rest(s__55306__$2)));
}
} else {
return null;
}
break;
}
});})(s__55304__$1,map__55317,map__55317__$1,src,resource_name,warnings,xs__6292__auto__,temp__5735__auto__,map__55300,map__55300__$1,sources,compiled,map__55291,map__55291__$1,msg,info,reload_info))
,null,null));
});})(s__55304__$1,map__55317,map__55317__$1,src,resource_name,warnings,xs__6292__auto__,temp__5735__auto__,map__55300,map__55300__$1,sources,compiled,map__55291,map__55291__$1,msg,info,reload_info))
;
var fs__4520__auto__ = cljs.core.seq(iterys__4519__auto__(warnings));
if(fs__4520__auto__){
return cljs.core.concat.cljs$core$IFn$_invoke$arity$2(fs__4520__auto__,shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__55303(cljs.core.rest(s__55304__$1)));
} else {
var G__55856 = cljs.core.rest(s__55304__$1);
s__55304__$1 = G__55856;
continue;
}
} else {
var G__55857 = cljs.core.rest(s__55304__$1);
s__55304__$1 = G__55857;
continue;
}
} else {
return null;
}
break;
}
});})(map__55300,map__55300__$1,sources,compiled,map__55291,map__55291__$1,msg,info,reload_info))
,null,null));
});})(map__55300,map__55300__$1,sources,compiled,map__55291,map__55291__$1,msg,info,reload_info))
;
return iter__4523__auto__(sources);
})()));
var seq__55328_55859 = cljs.core.seq(warnings);
var chunk__55329_55860 = null;
var count__55330_55861 = (0);
var i__55331_55862 = (0);
while(true){
if((i__55331_55862 < count__55330_55861)){
var map__55346_55863 = chunk__55329_55860.cljs$core$IIndexed$_nth$arity$2(null,i__55331_55862);
var map__55346_55864__$1 = (((((!((map__55346_55863 == null))))?(((((map__55346_55863.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55346_55863.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55346_55863):map__55346_55863);
var w_55865 = map__55346_55864__$1;
var msg_55866__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55346_55864__$1,new cljs.core.Keyword(null,"msg","msg",-1386103444));
var line_55867 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55346_55864__$1,new cljs.core.Keyword(null,"line","line",212345235));
var column_55868 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55346_55864__$1,new cljs.core.Keyword(null,"column","column",2078222095));
var resource_name_55869 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55346_55864__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
console.warn(["BUILD-WARNING in ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name_55869)," at [",cljs.core.str.cljs$core$IFn$_invoke$arity$1(line_55867),":",cljs.core.str.cljs$core$IFn$_invoke$arity$1(column_55868),"]\n\t",cljs.core.str.cljs$core$IFn$_invoke$arity$1(msg_55866__$1)].join(''));


var G__55875 = seq__55328_55859;
var G__55876 = chunk__55329_55860;
var G__55877 = count__55330_55861;
var G__55878 = (i__55331_55862 + (1));
seq__55328_55859 = G__55875;
chunk__55329_55860 = G__55876;
count__55330_55861 = G__55877;
i__55331_55862 = G__55878;
continue;
} else {
var temp__5735__auto___55879 = cljs.core.seq(seq__55328_55859);
if(temp__5735__auto___55879){
var seq__55328_55880__$1 = temp__5735__auto___55879;
if(cljs.core.chunked_seq_QMARK_(seq__55328_55880__$1)){
var c__4550__auto___55881 = cljs.core.chunk_first(seq__55328_55880__$1);
var G__55882 = cljs.core.chunk_rest(seq__55328_55880__$1);
var G__55883 = c__4550__auto___55881;
var G__55884 = cljs.core.count(c__4550__auto___55881);
var G__55885 = (0);
seq__55328_55859 = G__55882;
chunk__55329_55860 = G__55883;
count__55330_55861 = G__55884;
i__55331_55862 = G__55885;
continue;
} else {
var map__55351_55887 = cljs.core.first(seq__55328_55880__$1);
var map__55351_55888__$1 = (((((!((map__55351_55887 == null))))?(((((map__55351_55887.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55351_55887.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55351_55887):map__55351_55887);
var w_55889 = map__55351_55888__$1;
var msg_55890__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55351_55888__$1,new cljs.core.Keyword(null,"msg","msg",-1386103444));
var line_55891 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55351_55888__$1,new cljs.core.Keyword(null,"line","line",212345235));
var column_55892 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55351_55888__$1,new cljs.core.Keyword(null,"column","column",2078222095));
var resource_name_55893 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55351_55888__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
console.warn(["BUILD-WARNING in ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name_55893)," at [",cljs.core.str.cljs$core$IFn$_invoke$arity$1(line_55891),":",cljs.core.str.cljs$core$IFn$_invoke$arity$1(column_55892),"]\n\t",cljs.core.str.cljs$core$IFn$_invoke$arity$1(msg_55890__$1)].join(''));


var G__55899 = cljs.core.next(seq__55328_55880__$1);
var G__55900 = null;
var G__55901 = (0);
var G__55902 = (0);
seq__55328_55859 = G__55899;
chunk__55329_55860 = G__55900;
count__55330_55861 = G__55901;
i__55331_55862 = G__55902;
continue;
}
} else {
}
}
break;
}

if((!(shadow.cljs.devtools.client.env.autoload))){
return shadow.cljs.devtools.client.hud.load_end_success();
} else {
if(((cljs.core.empty_QMARK_(warnings)) || (shadow.cljs.devtools.client.env.ignore_warnings))){
var sources_to_get = cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.filter.cljs$core$IFn$_invoke$arity$2(((function (map__55300,map__55300__$1,sources,compiled,warnings,map__55291,map__55291__$1,msg,info,reload_info){
return (function (p__55359){
var map__55361 = p__55359;
var map__55361__$1 = (((((!((map__55361 == null))))?(((((map__55361.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55361.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55361):map__55361);
var src = map__55361__$1;
var ns = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55361__$1,new cljs.core.Keyword(null,"ns","ns",441598760));
var resource_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55361__$1,new cljs.core.Keyword(null,"resource-id","resource-id",-1308422582));
return ((cljs.core.contains_QMARK_(new cljs.core.Keyword(null,"always-load","always-load",66405637).cljs$core$IFn$_invoke$arity$1(reload_info),ns)) || (cljs.core.not(shadow.cljs.devtools.client.browser.src_is_loaded_QMARK_(src))) || (((cljs.core.contains_QMARK_(compiled,resource_id)) && (cljs.core.not(new cljs.core.Keyword(null,"from-jar","from-jar",1050932827).cljs$core$IFn$_invoke$arity$1(src))))));
});})(map__55300,map__55300__$1,sources,compiled,warnings,map__55291,map__55291__$1,msg,info,reload_info))
,cljs.core.remove.cljs$core$IFn$_invoke$arity$2(((function (map__55300,map__55300__$1,sources,compiled,warnings,map__55291,map__55291__$1,msg,info,reload_info){
return (function (p__55369){
var map__55370 = p__55369;
var map__55370__$1 = (((((!((map__55370 == null))))?(((((map__55370.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55370.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55370):map__55370);
var ns = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55370__$1,new cljs.core.Keyword(null,"ns","ns",441598760));
return cljs.core.contains_QMARK_(new cljs.core.Keyword(null,"never-load","never-load",1300896819).cljs$core$IFn$_invoke$arity$1(reload_info),ns);
});})(map__55300,map__55300__$1,sources,compiled,warnings,map__55291,map__55291__$1,msg,info,reload_info))
,cljs.core.filter.cljs$core$IFn$_invoke$arity$2(((function (map__55300,map__55300__$1,sources,compiled,warnings,map__55291,map__55291__$1,msg,info,reload_info){
return (function (p__55380){
var map__55381 = p__55380;
var map__55381__$1 = (((((!((map__55381 == null))))?(((((map__55381.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55381.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55381):map__55381);
var rc = map__55381__$1;
var module = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55381__$1,new cljs.core.Keyword(null,"module","module",1424618191));
return ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("js",shadow.cljs.devtools.client.env.module_format)) || (shadow.cljs.devtools.client.browser.module_is_active_QMARK_(module)));
});})(map__55300,map__55300__$1,sources,compiled,warnings,map__55291,map__55291__$1,msg,info,reload_info))
,sources))));
if(cljs.core.not(cljs.core.seq(sources_to_get))){
return shadow.cljs.devtools.client.hud.load_end_success();
} else {
if(cljs.core.seq(cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(msg,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"reload-info","reload-info",1648088086),new cljs.core.Keyword(null,"after-load","after-load",-1278503285)], null)))){
} else {
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("reloading code but no :after-load hooks are configured!",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["https://shadow-cljs.github.io/docs/UsersGuide.html#_lifecycle_hooks"], 0));
}

return shadow.cljs.devtools.client.browser.load_sources(sources_to_get,((function (sources_to_get,map__55300,map__55300__$1,sources,compiled,warnings,map__55291,map__55291__$1,msg,info,reload_info){
return (function (p1__55285_SHARP_){
return shadow.cljs.devtools.client.browser.do_js_reload(msg,p1__55285_SHARP_,shadow.cljs.devtools.client.hud.load_end_success,shadow.cljs.devtools.client.hud.load_failure);
});})(sources_to_get,map__55300,map__55300__$1,sources,compiled,warnings,map__55291,map__55291__$1,msg,info,reload_info))
);
}
} else {
return null;
}
}
});
shadow.cljs.devtools.client.browser.page_load_uri = (cljs.core.truth_(goog.global.document)?goog.Uri.parse(document.location.href):null);
shadow.cljs.devtools.client.browser.match_paths = (function shadow$cljs$devtools$client$browser$match_paths(old,new$){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("file",shadow.cljs.devtools.client.browser.page_load_uri.getScheme())){
var rel_new = cljs.core.subs.cljs$core$IFn$_invoke$arity$2(new$,(1));
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(old,rel_new)) || (clojure.string.starts_with_QMARK_(old,[cljs.core.str.cljs$core$IFn$_invoke$arity$1(rel_new),"?"].join(''))))){
return rel_new;
} else {
return null;
}
} else {
var node_uri = goog.Uri.parse(old);
var node_uri_resolved = shadow.cljs.devtools.client.browser.page_load_uri.resolve(node_uri);
var node_abs = node_uri_resolved.getPath();
var and__4120__auto__ = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$1(shadow.cljs.devtools.client.browser.page_load_uri.hasSameDomainAs(node_uri))) || (cljs.core.not(node_uri.hasDomain())));
if(and__4120__auto__){
var and__4120__auto____$1 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(node_abs,new$);
if(and__4120__auto____$1){
return new$;
} else {
return and__4120__auto____$1;
}
} else {
return and__4120__auto__;
}
}
});
shadow.cljs.devtools.client.browser.handle_asset_watch = (function shadow$cljs$devtools$client$browser$handle_asset_watch(p__55398){
var map__55399 = p__55398;
var map__55399__$1 = (((((!((map__55399 == null))))?(((((map__55399.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55399.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55399):map__55399);
var msg = map__55399__$1;
var updates = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55399__$1,new cljs.core.Keyword(null,"updates","updates",2013983452));
var seq__55401 = cljs.core.seq(updates);
var chunk__55403 = null;
var count__55404 = (0);
var i__55405 = (0);
while(true){
if((i__55405 < count__55404)){
var path = chunk__55403.cljs$core$IIndexed$_nth$arity$2(null,i__55405);
if(clojure.string.ends_with_QMARK_(path,"css")){
var seq__55478_55941 = cljs.core.seq(cljs.core.array_seq.cljs$core$IFn$_invoke$arity$1(document.querySelectorAll("link[rel=\"stylesheet\"]")));
var chunk__55481_55942 = null;
var count__55482_55943 = (0);
var i__55483_55944 = (0);
while(true){
if((i__55483_55944 < count__55482_55943)){
var node_55946 = chunk__55481_55942.cljs$core$IIndexed$_nth$arity$2(null,i__55483_55944);
var path_match_55948 = shadow.cljs.devtools.client.browser.match_paths(node_55946.getAttribute("href"),path);
if(cljs.core.truth_(path_match_55948)){
var new_link_55949 = (function (){var G__55497 = node_55946.cloneNode(true);
G__55497.setAttribute("href",[cljs.core.str.cljs$core$IFn$_invoke$arity$1(path_match_55948),"?r=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.rand.cljs$core$IFn$_invoke$arity$0())].join(''));

return G__55497;
})();
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load CSS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([path_match_55948], 0));

goog.dom.insertSiblingAfter(new_link_55949,node_55946);

goog.dom.removeNode(node_55946);


var G__55950 = seq__55478_55941;
var G__55951 = chunk__55481_55942;
var G__55952 = count__55482_55943;
var G__55953 = (i__55483_55944 + (1));
seq__55478_55941 = G__55950;
chunk__55481_55942 = G__55951;
count__55482_55943 = G__55952;
i__55483_55944 = G__55953;
continue;
} else {
var G__55954 = seq__55478_55941;
var G__55955 = chunk__55481_55942;
var G__55956 = count__55482_55943;
var G__55957 = (i__55483_55944 + (1));
seq__55478_55941 = G__55954;
chunk__55481_55942 = G__55955;
count__55482_55943 = G__55956;
i__55483_55944 = G__55957;
continue;
}
} else {
var temp__5735__auto___55959 = cljs.core.seq(seq__55478_55941);
if(temp__5735__auto___55959){
var seq__55478_55962__$1 = temp__5735__auto___55959;
if(cljs.core.chunked_seq_QMARK_(seq__55478_55962__$1)){
var c__4550__auto___55963 = cljs.core.chunk_first(seq__55478_55962__$1);
var G__55964 = cljs.core.chunk_rest(seq__55478_55962__$1);
var G__55965 = c__4550__auto___55963;
var G__55966 = cljs.core.count(c__4550__auto___55963);
var G__55967 = (0);
seq__55478_55941 = G__55964;
chunk__55481_55942 = G__55965;
count__55482_55943 = G__55966;
i__55483_55944 = G__55967;
continue;
} else {
var node_55970 = cljs.core.first(seq__55478_55962__$1);
var path_match_55972 = shadow.cljs.devtools.client.browser.match_paths(node_55970.getAttribute("href"),path);
if(cljs.core.truth_(path_match_55972)){
var new_link_55973 = (function (){var G__55509 = node_55970.cloneNode(true);
G__55509.setAttribute("href",[cljs.core.str.cljs$core$IFn$_invoke$arity$1(path_match_55972),"?r=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.rand.cljs$core$IFn$_invoke$arity$0())].join(''));

return G__55509;
})();
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load CSS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([path_match_55972], 0));

goog.dom.insertSiblingAfter(new_link_55973,node_55970);

goog.dom.removeNode(node_55970);


var G__55974 = cljs.core.next(seq__55478_55962__$1);
var G__55975 = null;
var G__55976 = (0);
var G__55977 = (0);
seq__55478_55941 = G__55974;
chunk__55481_55942 = G__55975;
count__55482_55943 = G__55976;
i__55483_55944 = G__55977;
continue;
} else {
var G__55978 = cljs.core.next(seq__55478_55962__$1);
var G__55979 = null;
var G__55980 = (0);
var G__55981 = (0);
seq__55478_55941 = G__55978;
chunk__55481_55942 = G__55979;
count__55482_55943 = G__55980;
i__55483_55944 = G__55981;
continue;
}
}
} else {
}
}
break;
}


var G__55982 = seq__55401;
var G__55983 = chunk__55403;
var G__55984 = count__55404;
var G__55985 = (i__55405 + (1));
seq__55401 = G__55982;
chunk__55403 = G__55983;
count__55404 = G__55984;
i__55405 = G__55985;
continue;
} else {
var G__55986 = seq__55401;
var G__55987 = chunk__55403;
var G__55988 = count__55404;
var G__55989 = (i__55405 + (1));
seq__55401 = G__55986;
chunk__55403 = G__55987;
count__55404 = G__55988;
i__55405 = G__55989;
continue;
}
} else {
var temp__5735__auto__ = cljs.core.seq(seq__55401);
if(temp__5735__auto__){
var seq__55401__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__55401__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__55401__$1);
var G__55994 = cljs.core.chunk_rest(seq__55401__$1);
var G__55995 = c__4550__auto__;
var G__55996 = cljs.core.count(c__4550__auto__);
var G__55997 = (0);
seq__55401 = G__55994;
chunk__55403 = G__55995;
count__55404 = G__55996;
i__55405 = G__55997;
continue;
} else {
var path = cljs.core.first(seq__55401__$1);
if(clojure.string.ends_with_QMARK_(path,"css")){
var seq__55510_56000 = cljs.core.seq(cljs.core.array_seq.cljs$core$IFn$_invoke$arity$1(document.querySelectorAll("link[rel=\"stylesheet\"]")));
var chunk__55513_56001 = null;
var count__55514_56002 = (0);
var i__55515_56003 = (0);
while(true){
if((i__55515_56003 < count__55514_56002)){
var node_56004 = chunk__55513_56001.cljs$core$IIndexed$_nth$arity$2(null,i__55515_56003);
var path_match_56005 = shadow.cljs.devtools.client.browser.match_paths(node_56004.getAttribute("href"),path);
if(cljs.core.truth_(path_match_56005)){
var new_link_56007 = (function (){var G__55546 = node_56004.cloneNode(true);
G__55546.setAttribute("href",[cljs.core.str.cljs$core$IFn$_invoke$arity$1(path_match_56005),"?r=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.rand.cljs$core$IFn$_invoke$arity$0())].join(''));

return G__55546;
})();
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load CSS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([path_match_56005], 0));

goog.dom.insertSiblingAfter(new_link_56007,node_56004);

goog.dom.removeNode(node_56004);


var G__56009 = seq__55510_56000;
var G__56010 = chunk__55513_56001;
var G__56011 = count__55514_56002;
var G__56012 = (i__55515_56003 + (1));
seq__55510_56000 = G__56009;
chunk__55513_56001 = G__56010;
count__55514_56002 = G__56011;
i__55515_56003 = G__56012;
continue;
} else {
var G__56013 = seq__55510_56000;
var G__56014 = chunk__55513_56001;
var G__56015 = count__55514_56002;
var G__56016 = (i__55515_56003 + (1));
seq__55510_56000 = G__56013;
chunk__55513_56001 = G__56014;
count__55514_56002 = G__56015;
i__55515_56003 = G__56016;
continue;
}
} else {
var temp__5735__auto___56017__$1 = cljs.core.seq(seq__55510_56000);
if(temp__5735__auto___56017__$1){
var seq__55510_56019__$1 = temp__5735__auto___56017__$1;
if(cljs.core.chunked_seq_QMARK_(seq__55510_56019__$1)){
var c__4550__auto___56023 = cljs.core.chunk_first(seq__55510_56019__$1);
var G__56025 = cljs.core.chunk_rest(seq__55510_56019__$1);
var G__56026 = c__4550__auto___56023;
var G__56027 = cljs.core.count(c__4550__auto___56023);
var G__56028 = (0);
seq__55510_56000 = G__56025;
chunk__55513_56001 = G__56026;
count__55514_56002 = G__56027;
i__55515_56003 = G__56028;
continue;
} else {
var node_56034 = cljs.core.first(seq__55510_56019__$1);
var path_match_56036 = shadow.cljs.devtools.client.browser.match_paths(node_56034.getAttribute("href"),path);
if(cljs.core.truth_(path_match_56036)){
var new_link_56038 = (function (){var G__55552 = node_56034.cloneNode(true);
G__55552.setAttribute("href",[cljs.core.str.cljs$core$IFn$_invoke$arity$1(path_match_56036),"?r=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.rand.cljs$core$IFn$_invoke$arity$0())].join(''));

return G__55552;
})();
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load CSS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([path_match_56036], 0));

goog.dom.insertSiblingAfter(new_link_56038,node_56034);

goog.dom.removeNode(node_56034);


var G__56041 = cljs.core.next(seq__55510_56019__$1);
var G__56042 = null;
var G__56043 = (0);
var G__56044 = (0);
seq__55510_56000 = G__56041;
chunk__55513_56001 = G__56042;
count__55514_56002 = G__56043;
i__55515_56003 = G__56044;
continue;
} else {
var G__56049 = cljs.core.next(seq__55510_56019__$1);
var G__56050 = null;
var G__56051 = (0);
var G__56052 = (0);
seq__55510_56000 = G__56049;
chunk__55513_56001 = G__56050;
count__55514_56002 = G__56051;
i__55515_56003 = G__56052;
continue;
}
}
} else {
}
}
break;
}


var G__56059 = cljs.core.next(seq__55401__$1);
var G__56060 = null;
var G__56061 = (0);
var G__56062 = (0);
seq__55401 = G__56059;
chunk__55403 = G__56060;
count__55404 = G__56061;
i__55405 = G__56062;
continue;
} else {
var G__56065 = cljs.core.next(seq__55401__$1);
var G__56066 = null;
var G__56067 = (0);
var G__56068 = (0);
seq__55401 = G__56065;
chunk__55403 = G__56066;
count__55404 = G__56067;
i__55405 = G__56068;
continue;
}
}
} else {
return null;
}
}
break;
}
});
shadow.cljs.devtools.client.browser.get_ua_product = (function shadow$cljs$devtools$client$browser$get_ua_product(){
if(cljs.core.truth_(goog.userAgent.product.SAFARI)){
return new cljs.core.Keyword(null,"safari","safari",497115653);
} else {
if(cljs.core.truth_(goog.userAgent.product.CHROME)){
return new cljs.core.Keyword(null,"chrome","chrome",1718738387);
} else {
if(cljs.core.truth_(goog.userAgent.product.FIREFOX)){
return new cljs.core.Keyword(null,"firefox","firefox",1283768880);
} else {
if(cljs.core.truth_(goog.userAgent.product.IE)){
return new cljs.core.Keyword(null,"ie","ie",2038473780);
} else {
return null;
}
}
}
}
});
shadow.cljs.devtools.client.browser.get_asset_root = (function shadow$cljs$devtools$client$browser$get_asset_root(){
var loc = (new goog.Uri(document.location.href));
var cbp = (new goog.Uri(CLOSURE_BASE_PATH));
var s = loc.resolve(cbp).toString();
return clojure.string.replace(s,/^file:\//,"file:///");
});
shadow.cljs.devtools.client.browser.repl_error = (function shadow$cljs$devtools$client$browser$repl_error(e){
console.error("repl/invoke error",e);

return cljs.core.assoc.cljs$core$IFn$_invoke$arity$variadic(shadow.cljs.devtools.client.env.repl_error(e),new cljs.core.Keyword(null,"ua-product","ua-product",938384227),shadow.cljs.devtools.client.browser.get_ua_product(),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"asset-root","asset-root",1771735072),shadow.cljs.devtools.client.browser.get_asset_root()], 0));
});
shadow.cljs.devtools.client.browser.global_eval = (function shadow$cljs$devtools$client$browser$global_eval(js){
return (0,eval)(js);;
});
shadow.cljs.devtools.client.browser.repl_invoke = (function shadow$cljs$devtools$client$browser$repl_invoke(p__55570){
var map__55572 = p__55570;
var map__55572__$1 = (((((!((map__55572 == null))))?(((((map__55572.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55572.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55572):map__55572);
var id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55572__$1,new cljs.core.Keyword(null,"id","id",-1388402092));
var js = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55572__$1,new cljs.core.Keyword(null,"js","js",1768080579));
var result = shadow.cljs.devtools.client.env.repl_call(((function (map__55572,map__55572__$1,id,js){
return (function (){
return shadow.cljs.devtools.client.browser.global_eval(js);
});})(map__55572,map__55572__$1,id,js))
,shadow.cljs.devtools.client.browser.repl_error);
return shadow.cljs.devtools.client.browser.ws_msg(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(result,new cljs.core.Keyword(null,"id","id",-1388402092),id));
});
shadow.cljs.devtools.client.browser.repl_require = (function shadow$cljs$devtools$client$browser$repl_require(p__55580,done){
var map__55581 = p__55580;
var map__55581__$1 = (((((!((map__55581 == null))))?(((((map__55581.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55581.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55581):map__55581);
var msg = map__55581__$1;
var id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55581__$1,new cljs.core.Keyword(null,"id","id",-1388402092));
var sources = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55581__$1,new cljs.core.Keyword(null,"sources","sources",-321166424));
var reload_namespaces = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55581__$1,new cljs.core.Keyword(null,"reload-namespaces","reload-namespaces",250210134));
var js_requires = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55581__$1,new cljs.core.Keyword(null,"js-requires","js-requires",-1311472051));
var sources_to_load = cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.remove.cljs$core$IFn$_invoke$arity$2(((function (map__55581,map__55581__$1,msg,id,sources,reload_namespaces,js_requires){
return (function (p__55584){
var map__55585 = p__55584;
var map__55585__$1 = (((((!((map__55585 == null))))?(((((map__55585.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55585.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55585):map__55585);
var src = map__55585__$1;
var provides = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55585__$1,new cljs.core.Keyword(null,"provides","provides",-1634397992));
var and__4120__auto__ = shadow.cljs.devtools.client.browser.src_is_loaded_QMARK_(src);
if(cljs.core.truth_(and__4120__auto__)){
return cljs.core.not(cljs.core.some(reload_namespaces,provides));
} else {
return and__4120__auto__;
}
});})(map__55581,map__55581__$1,msg,id,sources,reload_namespaces,js_requires))
,sources));
return shadow.cljs.devtools.client.browser.load_sources(sources_to_load,((function (sources_to_load,map__55581,map__55581__$1,msg,id,sources,reload_namespaces,js_requires){
return (function (sources__$1){
try{shadow.cljs.devtools.client.browser.do_js_load(sources__$1);

if(cljs.core.seq(js_requires)){
shadow.cljs.devtools.client.browser.do_js_requires(js_requires);
} else {
}

return shadow.cljs.devtools.client.browser.ws_msg(new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword("repl","require-complete","repl/require-complete",-2140254719),new cljs.core.Keyword(null,"id","id",-1388402092),id], null));
}catch (e55597){var e = e55597;
return shadow.cljs.devtools.client.browser.ws_msg(new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword("repl","require-error","repl/require-error",1689310021),new cljs.core.Keyword(null,"id","id",-1388402092),id,new cljs.core.Keyword(null,"error","error",-978969032),e.message], null));
}finally {(done.cljs$core$IFn$_invoke$arity$0 ? done.cljs$core$IFn$_invoke$arity$0() : done.call(null));
}});})(sources_to_load,map__55581,map__55581__$1,msg,id,sources,reload_namespaces,js_requires))
);
});
shadow.cljs.devtools.client.browser.repl_init = (function shadow$cljs$devtools$client$browser$repl_init(p__55600,done){
var map__55601 = p__55600;
var map__55601__$1 = (((((!((map__55601 == null))))?(((((map__55601.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55601.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55601):map__55601);
var repl_state = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55601__$1,new cljs.core.Keyword(null,"repl-state","repl-state",-1733780387));
var id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55601__$1,new cljs.core.Keyword(null,"id","id",-1388402092));
return shadow.cljs.devtools.client.browser.load_sources(cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.remove.cljs$core$IFn$_invoke$arity$2(shadow.cljs.devtools.client.browser.src_is_loaded_QMARK_,new cljs.core.Keyword(null,"repl-sources","repl-sources",723867535).cljs$core$IFn$_invoke$arity$1(repl_state))),((function (map__55601,map__55601__$1,repl_state,id){
return (function (sources){
shadow.cljs.devtools.client.browser.do_js_load(sources);

shadow.cljs.devtools.client.browser.ws_msg(new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword("repl","init-complete","repl/init-complete",-162252879),new cljs.core.Keyword(null,"id","id",-1388402092),id], null));

shadow.cljs.devtools.client.browser.devtools_msg("REPL session start successful");

return (done.cljs$core$IFn$_invoke$arity$0 ? done.cljs$core$IFn$_invoke$arity$0() : done.call(null));
});})(map__55601,map__55601__$1,repl_state,id))
);
});
shadow.cljs.devtools.client.browser.repl_set_ns = (function shadow$cljs$devtools$client$browser$repl_set_ns(p__55616){
var map__55617 = p__55616;
var map__55617__$1 = (((((!((map__55617 == null))))?(((((map__55617.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55617.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55617):map__55617);
var id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55617__$1,new cljs.core.Keyword(null,"id","id",-1388402092));
var ns = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55617__$1,new cljs.core.Keyword(null,"ns","ns",441598760));
return shadow.cljs.devtools.client.browser.ws_msg(new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword("repl","set-ns-complete","repl/set-ns-complete",680944662),new cljs.core.Keyword(null,"id","id",-1388402092),id,new cljs.core.Keyword(null,"ns","ns",441598760),ns], null));
});
shadow.cljs.devtools.client.browser.close_reason_ref = cljs.core.volatile_BANG_(null);
shadow.cljs.devtools.client.browser.handle_message = (function shadow$cljs$devtools$client$browser$handle_message(p__55621,done){
var map__55622 = p__55621;
var map__55622__$1 = (((((!((map__55622 == null))))?(((((map__55622.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__55622.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__55622):map__55622);
var msg = map__55622__$1;
var type = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__55622__$1,new cljs.core.Keyword(null,"type","type",1174270348));
shadow.cljs.devtools.client.hud.connection_error_clear_BANG_();

var G__55624_56148 = type;
var G__55624_56149__$1 = (((G__55624_56148 instanceof cljs.core.Keyword))?G__55624_56148.fqn:null);
switch (G__55624_56149__$1) {
case "asset-watch":
shadow.cljs.devtools.client.browser.handle_asset_watch(msg);

break;
case "repl/invoke":
shadow.cljs.devtools.client.browser.repl_invoke(msg);

break;
case "repl/require":
shadow.cljs.devtools.client.browser.repl_require(msg,done);

break;
case "repl/set-ns":
shadow.cljs.devtools.client.browser.repl_set_ns(msg);

break;
case "repl/init":
shadow.cljs.devtools.client.browser.repl_init(msg,done);

break;
case "repl/session-start":
shadow.cljs.devtools.client.browser.repl_init(msg,done);

break;
case "build-complete":
shadow.cljs.devtools.client.hud.hud_warnings(msg);

shadow.cljs.devtools.client.browser.handle_build_complete(msg);

break;
case "build-failure":
shadow.cljs.devtools.client.hud.load_end();

shadow.cljs.devtools.client.hud.hud_error(msg);

break;
case "build-init":
shadow.cljs.devtools.client.hud.hud_warnings(msg);

break;
case "build-start":
shadow.cljs.devtools.client.hud.hud_hide();

shadow.cljs.devtools.client.hud.load_start();

break;
case "pong":

break;
case "client/stale":
cljs.core.vreset_BANG_(shadow.cljs.devtools.client.browser.close_reason_ref,"Stale Client! You are not using the latest compilation output!");

break;
case "client/no-worker":
cljs.core.vreset_BANG_(shadow.cljs.devtools.client.browser.close_reason_ref,["watch for build \"",shadow.cljs.devtools.client.env.build_id,"\" not running"].join(''));

break;
case "custom-msg":
shadow.cljs.devtools.client.env.publish_BANG_(new cljs.core.Keyword(null,"payload","payload",-383036092).cljs$core$IFn$_invoke$arity$1(msg));

break;
default:

}

if(cljs.core.contains_QMARK_(shadow.cljs.devtools.client.env.async_ops,type)){
return null;
} else {
return (done.cljs$core$IFn$_invoke$arity$0 ? done.cljs$core$IFn$_invoke$arity$0() : done.call(null));
}
});
shadow.cljs.devtools.client.browser.compile = (function shadow$cljs$devtools$client$browser$compile(text,callback){
var G__55633 = ["http",((shadow.cljs.devtools.client.env.ssl)?"s":null),"://",shadow.cljs.devtools.client.env.server_host,":",cljs.core.str.cljs$core$IFn$_invoke$arity$1(shadow.cljs.devtools.client.env.server_port),"/worker/compile/",shadow.cljs.devtools.client.env.build_id,"/",shadow.cljs.devtools.client.env.proc_id,"/browser"].join('');
var G__55634 = ((function (G__55633){
return (function (res){
var req = this;
var actions = cljs.reader.read_string.cljs$core$IFn$_invoke$arity$1(req.getResponseText());
if(cljs.core.truth_(callback)){
return (callback.cljs$core$IFn$_invoke$arity$1 ? callback.cljs$core$IFn$_invoke$arity$1(actions) : callback.call(null,actions));
} else {
return null;
}
});})(G__55633))
;
var G__55635 = "POST";
var G__55636 = cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"input","input",556931961),text], null)], 0));
var G__55637 = ({"content-type": "application/edn; charset=utf-8"});
return goog.net.XhrIo.send(G__55633,G__55634,G__55635,G__55636,G__55637);
});
shadow.cljs.devtools.client.browser.heartbeat_BANG_ = (function shadow$cljs$devtools$client$browser$heartbeat_BANG_(){
var temp__5735__auto__ = cljs.core.deref(shadow.cljs.devtools.client.browser.socket_ref);
if(cljs.core.truth_(temp__5735__auto__)){
var s = temp__5735__auto__;
s.send(cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"ping","ping",-1670114784),new cljs.core.Keyword(null,"v","v",21465059),Date.now()], null)], 0)));

return setTimeout(shadow.cljs.devtools.client.browser.heartbeat_BANG_,(30000));
} else {
return null;
}
});
shadow.cljs.devtools.client.browser.ws_connect = (function shadow$cljs$devtools$client$browser$ws_connect(){
try{var print_fn = cljs.core._STAR_print_fn_STAR_;
var ws_url = shadow.cljs.devtools.client.env.ws_url(new cljs.core.Keyword(null,"browser","browser",828191719));
var socket = (new WebSocket(ws_url));
cljs.core.vreset_BANG_(shadow.cljs.devtools.client.browser.socket_ref,socket);

socket.onmessage = ((function (print_fn,ws_url,socket){
return (function (e){
return shadow.cljs.devtools.client.env.process_ws_msg(e.data,shadow.cljs.devtools.client.browser.handle_message);
});})(print_fn,ws_url,socket))
;

socket.onopen = ((function (print_fn,ws_url,socket){
return (function (e){
shadow.cljs.devtools.client.hud.connection_error_clear_BANG_();

cljs.core.vreset_BANG_(shadow.cljs.devtools.client.browser.close_reason_ref,null);

if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("goog",shadow.cljs.devtools.client.env.module_format)){
goog.provide = goog.constructNamespace_;
} else {
}

shadow.cljs.devtools.client.env.set_print_fns_BANG_(shadow.cljs.devtools.client.browser.ws_msg);

return shadow.cljs.devtools.client.browser.devtools_msg("WebSocket connected!");
});})(print_fn,ws_url,socket))
;

socket.onclose = ((function (print_fn,ws_url,socket){
return (function (e){
shadow.cljs.devtools.client.browser.devtools_msg("WebSocket disconnected!");

shadow.cljs.devtools.client.hud.connection_error((function (){var or__4131__auto__ = cljs.core.deref(shadow.cljs.devtools.client.browser.close_reason_ref);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return "Connection closed!";
}
})());

cljs.core.vreset_BANG_(shadow.cljs.devtools.client.browser.socket_ref,null);

return shadow.cljs.devtools.client.env.reset_print_fns_BANG_();
});})(print_fn,ws_url,socket))
;

socket.onerror = ((function (print_fn,ws_url,socket){
return (function (e){
shadow.cljs.devtools.client.hud.connection_error("Connection failed!");

return shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("websocket error",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([e], 0));
});})(print_fn,ws_url,socket))
;

return setTimeout(shadow.cljs.devtools.client.browser.heartbeat_BANG_,(30000));
}catch (e55648){var e = e55648;
return shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("WebSocket setup failed",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([e], 0));
}});
if(shadow.cljs.devtools.client.env.enabled){
var temp__5735__auto___56168 = cljs.core.deref(shadow.cljs.devtools.client.browser.socket_ref);
if(cljs.core.truth_(temp__5735__auto___56168)){
var s_56170 = temp__5735__auto___56168;
shadow.cljs.devtools.client.browser.devtools_msg("connection reset!");

s_56170.onclose = ((function (s_56170,temp__5735__auto___56168){
return (function (e){
return null;
});})(s_56170,temp__5735__auto___56168))
;

s_56170.close();

cljs.core.vreset_BANG_(shadow.cljs.devtools.client.browser.socket_ref,null);
} else {
}

window.addEventListener("beforeunload",(function (){
var temp__5735__auto__ = cljs.core.deref(shadow.cljs.devtools.client.browser.socket_ref);
if(cljs.core.truth_(temp__5735__auto__)){
var s = temp__5735__auto__;
return s.close();
} else {
return null;
}
}));

if(cljs.core.truth_((function (){var and__4120__auto__ = document;
if(cljs.core.truth_(and__4120__auto__)){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("loading",document.readyState);
} else {
return and__4120__auto__;
}
})())){
window.addEventListener("DOMContentLoaded",shadow.cljs.devtools.client.browser.ws_connect);
} else {
setTimeout(shadow.cljs.devtools.client.browser.ws_connect,(10));
}
} else {
}

//# sourceMappingURL=shadow.cljs.devtools.client.browser.js.map
