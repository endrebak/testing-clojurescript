goog.provide('test_reframe.config');
goog.require('cljs.core');
test_reframe.config.debug_QMARK_ = goog.DEBUG;

//# sourceMappingURL=test_reframe.config.js.map
