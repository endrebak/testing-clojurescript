goog.provide('test_reframe.views');
goog.require('cljs.core');
goog.require('re_frame.core');
goog.require('test_reframe.subs');
goog.require('test_reframe.events');
goog.require('test_reframe.d3');
goog.require('test_reframe.db');
goog.require('goog.object');
test_reframe.views.main_panel = (function test_reframe$views$main_panel(){
var name = (function (){var G__50926 = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("test-reframe.subs","name","test-reframe.subs/name",-1627046385)], null);
return (re_frame.core.subscribe.cljs$core$IFn$_invoke$arity$1 ? re_frame.core.subscribe.cljs$core$IFn$_invoke$arity$1(G__50926) : re_frame.core.subscribe.call(null,G__50926));
})();
var clicks = (function (){var G__50927 = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("test-reframe.subs","click","test-reframe.subs/click",924477855)], null);
return (re_frame.core.subscribe.cljs$core$IFn$_invoke$arity$1 ? re_frame.core.subscribe.cljs$core$IFn$_invoke$arity$1(G__50927) : re_frame.core.subscribe.call(null,G__50927));
})();
var data = (function (){var G__50928 = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("test-reframe.subs","data","test-reframe.subs/data",1191230813)], null);
return (re_frame.core.subscribe.cljs$core$IFn$_invoke$arity$1 ? re_frame.core.subscribe.cljs$core$IFn$_invoke$arity$1(G__50928) : re_frame.core.subscribe.call(null,G__50928));
})();
return new cljs.core.PersistentVector(null, 8, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"h1","h1",-1896887462),"Hello from ",cljs.core.deref(name)], null),new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"h2","h2",-372662728),"You have clicked me ",cljs.core.deref(clicks)," times"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"h3","h3",2067611163),cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1((function (){var G__50931 = test_reframe.db.app_state;
var G__50932 = cljs.core.deref(clicks);
return goog.object.getValueByKeys(G__50931,G__50932);
})()))], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"input","input",556931961),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"type","type",1174270348),"button",new cljs.core.Keyword(null,"value","value",305978217),"click me!!!!",new cljs.core.Keyword(null,"on-click","on-click",1632826543),((function (name,clicks,data){
return (function (){
var G__50933 = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("test-reframe.events","click","test-reframe.events/click",-1023537095)], null);
return (re_frame.core.dispatch.cljs$core$IFn$_invoke$arity$1 ? re_frame.core.dispatch.cljs$core$IFn$_invoke$arity$1(G__50933) : re_frame.core.dispatch.call(null,G__50933));
});})(name,clicks,data))
], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"input","input",556931961),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"type","type",1174270348),"button",new cljs.core.Keyword(null,"value","value",305978217),"click me!!!!",new cljs.core.Keyword(null,"on-click","on-click",1632826543),((function (name,clicks,data){
return (function (){
var G__50934 = new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("test-reframe.events","shuffle","test-reframe.events/shuffle",1379187784)], null);
return (re_frame.core.dispatch.cljs$core$IFn$_invoke$arity$1 ? re_frame.core.dispatch.cljs$core$IFn$_invoke$arity$1(G__50934) : re_frame.core.dispatch.call(null,G__50934));
});})(name,clicks,data))
], null)], null),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"br","br",934104792)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [test_reframe.d3.d3_inner,cljs.core.deref(data)], null)], null);
});

//# sourceMappingURL=test_reframe.views.js.map
