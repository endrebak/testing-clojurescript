goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('goog.array');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__51061 = arguments.length;
switch (G__51061) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async51063 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async51063 = (function (f,blockable,meta51064){
this.f = f;
this.blockable = blockable;
this.meta51064 = meta51064;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async51063.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_51065,meta51064__$1){
var self__ = this;
var _51065__$1 = this;
return (new cljs.core.async.t_cljs$core$async51063(self__.f,self__.blockable,meta51064__$1));
});

cljs.core.async.t_cljs$core$async51063.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_51065){
var self__ = this;
var _51065__$1 = this;
return self__.meta51064;
});

cljs.core.async.t_cljs$core$async51063.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51063.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async51063.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async51063.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async51063.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"blockable","blockable",-28395259,null),new cljs.core.Symbol(null,"meta51064","meta51064",1222351441,null)], null);
});

cljs.core.async.t_cljs$core$async51063.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async51063.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async51063";

cljs.core.async.t_cljs$core$async51063.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async51063");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async51063.
 */
cljs.core.async.__GT_t_cljs$core$async51063 = (function cljs$core$async$__GT_t_cljs$core$async51063(f__$1,blockable__$1,meta51064){
return (new cljs.core.async.t_cljs$core$async51063(f__$1,blockable__$1,meta51064));
});

}

return (new cljs.core.async.t_cljs$core$async51063(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if((!((buff == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__51068 = arguments.length;
switch (G__51068) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
if(cljs.core.truth_(buf_or_n__$1)){
} else {
throw (new Error(["Assert failed: ","buffer must be supplied when transducer is","\n","buf-or-n"].join('')));
}
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__51070 = arguments.length;
switch (G__51070) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__51072 = arguments.length;
switch (G__51072) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_52520 = cljs.core.deref(ret);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_52520) : fn1.call(null,val_52520));
} else {
cljs.core.async.impl.dispatch.run(((function (val_52520,ret){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_52520) : fn1.call(null,val_52520));
});})(val_52520,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn1 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn1 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__51074 = arguments.length;
switch (G__51074) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5733__auto__)){
var ret = temp__5733__auto__;
return cljs.core.deref(ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__5733__auto__)){
var retb = temp__5733__auto__;
var ret = cljs.core.deref(retb);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run(((function (ret,retb,temp__5733__auto__){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
});})(ret,retb,temp__5733__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4607__auto___52539 = n;
var x_52540 = (0);
while(true){
if((x_52540 < n__4607__auto___52539)){
(a[x_52540] = x_52540);

var G__52543 = (x_52540 + (1));
x_52540 = G__52543;
continue;
} else {
}
break;
}

goog.array.shuffle(a);

return a;
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true);
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async51075 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async51075 = (function (flag,meta51076){
this.flag = flag;
this.meta51076 = meta51076;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async51075.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_51077,meta51076__$1){
var self__ = this;
var _51077__$1 = this;
return (new cljs.core.async.t_cljs$core$async51075(self__.flag,meta51076__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async51075.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_51077){
var self__ = this;
var _51077__$1 = this;
return self__.meta51076;
});})(flag))
;

cljs.core.async.t_cljs$core$async51075.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51075.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref(self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async51075.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async51075.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async51075.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"meta51076","meta51076",-209930837,null)], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async51075.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async51075.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async51075";

cljs.core.async.t_cljs$core$async51075.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async51075");
});})(flag))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async51075.
 */
cljs.core.async.__GT_t_cljs$core$async51075 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async51075(flag__$1,meta51076){
return (new cljs.core.async.t_cljs$core$async51075(flag__$1,meta51076));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async51075(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async51078 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async51078 = (function (flag,cb,meta51079){
this.flag = flag;
this.cb = cb;
this.meta51079 = meta51079;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async51078.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_51080,meta51079__$1){
var self__ = this;
var _51080__$1 = this;
return (new cljs.core.async.t_cljs$core$async51078(self__.flag,self__.cb,meta51079__$1));
});

cljs.core.async.t_cljs$core$async51078.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_51080){
var self__ = this;
var _51080__$1 = this;
return self__.meta51079;
});

cljs.core.async.t_cljs$core$async51078.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51078.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
});

cljs.core.async.t_cljs$core$async51078.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async51078.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async51078.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"cb","cb",-2064487928,null),new cljs.core.Symbol(null,"meta51079","meta51079",1584984423,null)], null);
});

cljs.core.async.t_cljs$core$async51078.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async51078.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async51078";

cljs.core.async.t_cljs$core$async51078.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async51078");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async51078.
 */
cljs.core.async.__GT_t_cljs$core$async51078 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async51078(flag__$1,cb__$1,meta51079){
return (new cljs.core.async.t_cljs$core$async51078(flag__$1,cb__$1,meta51079));
});

}

return (new cljs.core.async.t_cljs$core$async51078(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
if((cljs.core.count(ports) > (0))){
} else {
throw (new Error(["Assert failed: ","alts must have at least one channel operation","\n","(pos? (count ports))"].join('')));
}

var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = new cljs.core.Keyword(null,"priority","priority",1431093715).cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__51081_SHARP_){
var G__51083 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__51081_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__51083) : fret.call(null,G__51083));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__51082_SHARP_){
var G__51084 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__51082_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__51084) : fret.call(null,G__51084));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref(vbox),(function (){var or__4131__auto__ = wport;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return port;
}
})()], null));
} else {
var G__52570 = (i + (1));
i = G__52570;
continue;
}
} else {
return null;
}
break;
}
})();
var or__4131__auto__ = ret;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,new cljs.core.Keyword(null,"default","default",-1987822328))){
var temp__5735__auto__ = (function (){var and__4120__auto__ = flag.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1(null);
if(cljs.core.truth_(and__4120__auto__)){
return flag.cljs$core$async$impl$protocols$Handler$commit$arity$1(null);
} else {
return and__4120__auto__;
}
})();
if(cljs.core.truth_(temp__5735__auto__)){
var got = temp__5735__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"default","default",-1987822328).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"default","default",-1987822328)], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___52575 = arguments.length;
var i__4731__auto___52576 = (0);
while(true){
if((i__4731__auto___52576 < len__4730__auto___52575)){
args__4736__auto__.push((arguments[i__4731__auto___52576]));

var G__52577 = (i__4731__auto___52576 + (1));
i__4731__auto___52576 = G__52577;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__51087){
var map__51088 = p__51087;
var map__51088__$1 = (((((!((map__51088 == null))))?(((((map__51088.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__51088.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__51088):map__51088);
var opts = map__51088__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq51085){
var G__51086 = cljs.core.first(seq51085);
var seq51085__$1 = cljs.core.next(seq51085);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__51086,seq51085__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__51091 = arguments.length;
switch (G__51091) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__51002__auto___52597 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___52597){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___52597){
return (function (state_51115){
var state_val_51116 = (state_51115[(1)]);
if((state_val_51116 === (7))){
var inst_51111 = (state_51115[(2)]);
var state_51115__$1 = state_51115;
var statearr_51117_52598 = state_51115__$1;
(statearr_51117_52598[(2)] = inst_51111);

(statearr_51117_52598[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (1))){
var state_51115__$1 = state_51115;
var statearr_51118_52599 = state_51115__$1;
(statearr_51118_52599[(2)] = null);

(statearr_51118_52599[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (4))){
var inst_51094 = (state_51115[(7)]);
var inst_51094__$1 = (state_51115[(2)]);
var inst_51095 = (inst_51094__$1 == null);
var state_51115__$1 = (function (){var statearr_51119 = state_51115;
(statearr_51119[(7)] = inst_51094__$1);

return statearr_51119;
})();
if(cljs.core.truth_(inst_51095)){
var statearr_51120_52600 = state_51115__$1;
(statearr_51120_52600[(1)] = (5));

} else {
var statearr_51121_52601 = state_51115__$1;
(statearr_51121_52601[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (13))){
var state_51115__$1 = state_51115;
var statearr_51122_52602 = state_51115__$1;
(statearr_51122_52602[(2)] = null);

(statearr_51122_52602[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (6))){
var inst_51094 = (state_51115[(7)]);
var state_51115__$1 = state_51115;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51115__$1,(11),to,inst_51094);
} else {
if((state_val_51116 === (3))){
var inst_51113 = (state_51115[(2)]);
var state_51115__$1 = state_51115;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51115__$1,inst_51113);
} else {
if((state_val_51116 === (12))){
var state_51115__$1 = state_51115;
var statearr_51123_52603 = state_51115__$1;
(statearr_51123_52603[(2)] = null);

(statearr_51123_52603[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (2))){
var state_51115__$1 = state_51115;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51115__$1,(4),from);
} else {
if((state_val_51116 === (11))){
var inst_51104 = (state_51115[(2)]);
var state_51115__$1 = state_51115;
if(cljs.core.truth_(inst_51104)){
var statearr_51124_52604 = state_51115__$1;
(statearr_51124_52604[(1)] = (12));

} else {
var statearr_51125_52605 = state_51115__$1;
(statearr_51125_52605[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (9))){
var state_51115__$1 = state_51115;
var statearr_51126_52606 = state_51115__$1;
(statearr_51126_52606[(2)] = null);

(statearr_51126_52606[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (5))){
var state_51115__$1 = state_51115;
if(cljs.core.truth_(close_QMARK_)){
var statearr_51127_52607 = state_51115__$1;
(statearr_51127_52607[(1)] = (8));

} else {
var statearr_51128_52610 = state_51115__$1;
(statearr_51128_52610[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (14))){
var inst_51109 = (state_51115[(2)]);
var state_51115__$1 = state_51115;
var statearr_51129_52611 = state_51115__$1;
(statearr_51129_52611[(2)] = inst_51109);

(statearr_51129_52611[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (10))){
var inst_51101 = (state_51115[(2)]);
var state_51115__$1 = state_51115;
var statearr_51130_52612 = state_51115__$1;
(statearr_51130_52612[(2)] = inst_51101);

(statearr_51130_52612[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51116 === (8))){
var inst_51098 = cljs.core.async.close_BANG_(to);
var state_51115__$1 = state_51115;
var statearr_51131_52613 = state_51115__$1;
(statearr_51131_52613[(2)] = inst_51098);

(statearr_51131_52613[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___52597))
;
return ((function (switch__50901__auto__,c__51002__auto___52597){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_51132 = [null,null,null,null,null,null,null,null];
(statearr_51132[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_51132[(1)] = (1));

return statearr_51132;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_51115){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51115);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51133){if((e51133 instanceof Object)){
var ex__50905__auto__ = e51133;
var statearr_51134_52614 = state_51115;
(statearr_51134_52614[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51115);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51133;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52615 = state_51115;
state_51115 = G__52615;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_51115){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_51115);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___52597))
})();
var state__51004__auto__ = (function (){var statearr_51135 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51135[(6)] = c__51002__auto___52597);

return statearr_51135;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___52597))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){
if((n > (0))){
} else {
throw (new Error("Assert failed: (pos? n)"));
}

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = ((function (jobs,results){
return (function (p__51136){
var vec__51137 = p__51136;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__51137,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__51137,(1),null);
var job = vec__51137;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__51002__auto___52621 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___52621,res,vec__51137,v,p,job,jobs,results){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___52621,res,vec__51137,v,p,job,jobs,results){
return (function (state_51144){
var state_val_51145 = (state_51144[(1)]);
if((state_val_51145 === (1))){
var state_51144__$1 = state_51144;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51144__$1,(2),res,v);
} else {
if((state_val_51145 === (2))){
var inst_51141 = (state_51144[(2)]);
var inst_51142 = cljs.core.async.close_BANG_(res);
var state_51144__$1 = (function (){var statearr_51146 = state_51144;
(statearr_51146[(7)] = inst_51141);

return statearr_51146;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_51144__$1,inst_51142);
} else {
return null;
}
}
});})(c__51002__auto___52621,res,vec__51137,v,p,job,jobs,results))
;
return ((function (switch__50901__auto__,c__51002__auto___52621,res,vec__51137,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0 = (function (){
var statearr_51147 = [null,null,null,null,null,null,null,null];
(statearr_51147[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__);

(statearr_51147[(1)] = (1));

return statearr_51147;
});
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1 = (function (state_51144){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51144);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51148){if((e51148 instanceof Object)){
var ex__50905__auto__ = e51148;
var statearr_51149_52627 = state_51144;
(statearr_51149_52627[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51144);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51148;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52630 = state_51144;
state_51144 = G__52630;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = function(state_51144){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1.call(this,state_51144);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___52621,res,vec__51137,v,p,job,jobs,results))
})();
var state__51004__auto__ = (function (){var statearr_51150 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51150[(6)] = c__51002__auto___52621);

return statearr_51150;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___52621,res,vec__51137,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__51151){
var vec__51152 = p__51151;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__51152,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__51152,(1),null);
var job = vec__51152;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results,process))
;
var n__4607__auto___52636 = n;
var __52637 = (0);
while(true){
if((__52637 < n__4607__auto___52636)){
var G__51155_52638 = type;
var G__51155_52639__$1 = (((G__51155_52638 instanceof cljs.core.Keyword))?G__51155_52638.fqn:null);
switch (G__51155_52639__$1) {
case "compute":
var c__51002__auto___52641 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__52637,c__51002__auto___52641,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (__52637,c__51002__auto___52641,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async){
return (function (state_51168){
var state_val_51169 = (state_51168[(1)]);
if((state_val_51169 === (1))){
var state_51168__$1 = state_51168;
var statearr_51170_52644 = state_51168__$1;
(statearr_51170_52644[(2)] = null);

(statearr_51170_52644[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51169 === (2))){
var state_51168__$1 = state_51168;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51168__$1,(4),jobs);
} else {
if((state_val_51169 === (3))){
var inst_51166 = (state_51168[(2)]);
var state_51168__$1 = state_51168;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51168__$1,inst_51166);
} else {
if((state_val_51169 === (4))){
var inst_51158 = (state_51168[(2)]);
var inst_51159 = process(inst_51158);
var state_51168__$1 = state_51168;
if(cljs.core.truth_(inst_51159)){
var statearr_51171_52645 = state_51168__$1;
(statearr_51171_52645[(1)] = (5));

} else {
var statearr_51172_52646 = state_51168__$1;
(statearr_51172_52646[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51169 === (5))){
var state_51168__$1 = state_51168;
var statearr_51173_52648 = state_51168__$1;
(statearr_51173_52648[(2)] = null);

(statearr_51173_52648[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51169 === (6))){
var state_51168__$1 = state_51168;
var statearr_51174_52650 = state_51168__$1;
(statearr_51174_52650[(2)] = null);

(statearr_51174_52650[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51169 === (7))){
var inst_51164 = (state_51168[(2)]);
var state_51168__$1 = state_51168;
var statearr_51175_52651 = state_51168__$1;
(statearr_51175_52651[(2)] = inst_51164);

(statearr_51175_52651[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__52637,c__51002__auto___52641,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async))
;
return ((function (__52637,switch__50901__auto__,c__51002__auto___52641,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0 = (function (){
var statearr_51176 = [null,null,null,null,null,null,null];
(statearr_51176[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__);

(statearr_51176[(1)] = (1));

return statearr_51176;
});
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1 = (function (state_51168){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51168);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51177){if((e51177 instanceof Object)){
var ex__50905__auto__ = e51177;
var statearr_51178_52652 = state_51168;
(statearr_51178_52652[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51168);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51177;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52655 = state_51168;
state_51168 = G__52655;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = function(state_51168){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1.call(this,state_51168);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__;
})()
;})(__52637,switch__50901__auto__,c__51002__auto___52641,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async))
})();
var state__51004__auto__ = (function (){var statearr_51179 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51179[(6)] = c__51002__auto___52641);

return statearr_51179;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(__52637,c__51002__auto___52641,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async))
);


break;
case "async":
var c__51002__auto___52656 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__52637,c__51002__auto___52656,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (__52637,c__51002__auto___52656,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async){
return (function (state_51192){
var state_val_51193 = (state_51192[(1)]);
if((state_val_51193 === (1))){
var state_51192__$1 = state_51192;
var statearr_51194_52657 = state_51192__$1;
(statearr_51194_52657[(2)] = null);

(statearr_51194_52657[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51193 === (2))){
var state_51192__$1 = state_51192;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51192__$1,(4),jobs);
} else {
if((state_val_51193 === (3))){
var inst_51190 = (state_51192[(2)]);
var state_51192__$1 = state_51192;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51192__$1,inst_51190);
} else {
if((state_val_51193 === (4))){
var inst_51182 = (state_51192[(2)]);
var inst_51183 = async(inst_51182);
var state_51192__$1 = state_51192;
if(cljs.core.truth_(inst_51183)){
var statearr_51195_52658 = state_51192__$1;
(statearr_51195_52658[(1)] = (5));

} else {
var statearr_51196_52659 = state_51192__$1;
(statearr_51196_52659[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51193 === (5))){
var state_51192__$1 = state_51192;
var statearr_51197_52660 = state_51192__$1;
(statearr_51197_52660[(2)] = null);

(statearr_51197_52660[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51193 === (6))){
var state_51192__$1 = state_51192;
var statearr_51198_52662 = state_51192__$1;
(statearr_51198_52662[(2)] = null);

(statearr_51198_52662[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51193 === (7))){
var inst_51188 = (state_51192[(2)]);
var state_51192__$1 = state_51192;
var statearr_51199_52664 = state_51192__$1;
(statearr_51199_52664[(2)] = inst_51188);

(statearr_51199_52664[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__52637,c__51002__auto___52656,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async))
;
return ((function (__52637,switch__50901__auto__,c__51002__auto___52656,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0 = (function (){
var statearr_51200 = [null,null,null,null,null,null,null];
(statearr_51200[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__);

(statearr_51200[(1)] = (1));

return statearr_51200;
});
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1 = (function (state_51192){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51192);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51201){if((e51201 instanceof Object)){
var ex__50905__auto__ = e51201;
var statearr_51202_52667 = state_51192;
(statearr_51202_52667[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51192);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51201;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52670 = state_51192;
state_51192 = G__52670;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = function(state_51192){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1.call(this,state_51192);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__;
})()
;})(__52637,switch__50901__auto__,c__51002__auto___52656,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async))
})();
var state__51004__auto__ = (function (){var statearr_51203 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51203[(6)] = c__51002__auto___52656);

return statearr_51203;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(__52637,c__51002__auto___52656,G__51155_52638,G__51155_52639__$1,n__4607__auto___52636,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__51155_52639__$1)].join('')));

}

var G__52671 = (__52637 + (1));
__52637 = G__52671;
continue;
} else {
}
break;
}

var c__51002__auto___52672 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___52672,jobs,results,process,async){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___52672,jobs,results,process,async){
return (function (state_51225){
var state_val_51226 = (state_51225[(1)]);
if((state_val_51226 === (7))){
var inst_51221 = (state_51225[(2)]);
var state_51225__$1 = state_51225;
var statearr_51227_52675 = state_51225__$1;
(statearr_51227_52675[(2)] = inst_51221);

(statearr_51227_52675[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51226 === (1))){
var state_51225__$1 = state_51225;
var statearr_51228_52676 = state_51225__$1;
(statearr_51228_52676[(2)] = null);

(statearr_51228_52676[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51226 === (4))){
var inst_51206 = (state_51225[(7)]);
var inst_51206__$1 = (state_51225[(2)]);
var inst_51207 = (inst_51206__$1 == null);
var state_51225__$1 = (function (){var statearr_51229 = state_51225;
(statearr_51229[(7)] = inst_51206__$1);

return statearr_51229;
})();
if(cljs.core.truth_(inst_51207)){
var statearr_51230_52679 = state_51225__$1;
(statearr_51230_52679[(1)] = (5));

} else {
var statearr_51231_52680 = state_51225__$1;
(statearr_51231_52680[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51226 === (6))){
var inst_51206 = (state_51225[(7)]);
var inst_51211 = (state_51225[(8)]);
var inst_51211__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_51212 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_51213 = [inst_51206,inst_51211__$1];
var inst_51214 = (new cljs.core.PersistentVector(null,2,(5),inst_51212,inst_51213,null));
var state_51225__$1 = (function (){var statearr_51232 = state_51225;
(statearr_51232[(8)] = inst_51211__$1);

return statearr_51232;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51225__$1,(8),jobs,inst_51214);
} else {
if((state_val_51226 === (3))){
var inst_51223 = (state_51225[(2)]);
var state_51225__$1 = state_51225;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51225__$1,inst_51223);
} else {
if((state_val_51226 === (2))){
var state_51225__$1 = state_51225;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51225__$1,(4),from);
} else {
if((state_val_51226 === (9))){
var inst_51218 = (state_51225[(2)]);
var state_51225__$1 = (function (){var statearr_51233 = state_51225;
(statearr_51233[(9)] = inst_51218);

return statearr_51233;
})();
var statearr_51234_52683 = state_51225__$1;
(statearr_51234_52683[(2)] = null);

(statearr_51234_52683[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51226 === (5))){
var inst_51209 = cljs.core.async.close_BANG_(jobs);
var state_51225__$1 = state_51225;
var statearr_51235_52686 = state_51225__$1;
(statearr_51235_52686[(2)] = inst_51209);

(statearr_51235_52686[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51226 === (8))){
var inst_51211 = (state_51225[(8)]);
var inst_51216 = (state_51225[(2)]);
var state_51225__$1 = (function (){var statearr_51236 = state_51225;
(statearr_51236[(10)] = inst_51216);

return statearr_51236;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51225__$1,(9),results,inst_51211);
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___52672,jobs,results,process,async))
;
return ((function (switch__50901__auto__,c__51002__auto___52672,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0 = (function (){
var statearr_51237 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_51237[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__);

(statearr_51237[(1)] = (1));

return statearr_51237;
});
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1 = (function (state_51225){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51225);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51238){if((e51238 instanceof Object)){
var ex__50905__auto__ = e51238;
var statearr_51239_52688 = state_51225;
(statearr_51239_52688[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51225);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51238;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52689 = state_51225;
state_51225 = G__52689;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = function(state_51225){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1.call(this,state_51225);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___52672,jobs,results,process,async))
})();
var state__51004__auto__ = (function (){var statearr_51240 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51240[(6)] = c__51002__auto___52672);

return statearr_51240;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___52672,jobs,results,process,async))
);


var c__51002__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto__,jobs,results,process,async){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto__,jobs,results,process,async){
return (function (state_51278){
var state_val_51279 = (state_51278[(1)]);
if((state_val_51279 === (7))){
var inst_51274 = (state_51278[(2)]);
var state_51278__$1 = state_51278;
var statearr_51280_52690 = state_51278__$1;
(statearr_51280_52690[(2)] = inst_51274);

(statearr_51280_52690[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (20))){
var state_51278__$1 = state_51278;
var statearr_51281_52691 = state_51278__$1;
(statearr_51281_52691[(2)] = null);

(statearr_51281_52691[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (1))){
var state_51278__$1 = state_51278;
var statearr_51282_52692 = state_51278__$1;
(statearr_51282_52692[(2)] = null);

(statearr_51282_52692[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (4))){
var inst_51243 = (state_51278[(7)]);
var inst_51243__$1 = (state_51278[(2)]);
var inst_51244 = (inst_51243__$1 == null);
var state_51278__$1 = (function (){var statearr_51283 = state_51278;
(statearr_51283[(7)] = inst_51243__$1);

return statearr_51283;
})();
if(cljs.core.truth_(inst_51244)){
var statearr_51284_52697 = state_51278__$1;
(statearr_51284_52697[(1)] = (5));

} else {
var statearr_51285_52698 = state_51278__$1;
(statearr_51285_52698[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (15))){
var inst_51256 = (state_51278[(8)]);
var state_51278__$1 = state_51278;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51278__$1,(18),to,inst_51256);
} else {
if((state_val_51279 === (21))){
var inst_51269 = (state_51278[(2)]);
var state_51278__$1 = state_51278;
var statearr_51286_52699 = state_51278__$1;
(statearr_51286_52699[(2)] = inst_51269);

(statearr_51286_52699[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (13))){
var inst_51271 = (state_51278[(2)]);
var state_51278__$1 = (function (){var statearr_51287 = state_51278;
(statearr_51287[(9)] = inst_51271);

return statearr_51287;
})();
var statearr_51288_52703 = state_51278__$1;
(statearr_51288_52703[(2)] = null);

(statearr_51288_52703[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (6))){
var inst_51243 = (state_51278[(7)]);
var state_51278__$1 = state_51278;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51278__$1,(11),inst_51243);
} else {
if((state_val_51279 === (17))){
var inst_51264 = (state_51278[(2)]);
var state_51278__$1 = state_51278;
if(cljs.core.truth_(inst_51264)){
var statearr_51289_52704 = state_51278__$1;
(statearr_51289_52704[(1)] = (19));

} else {
var statearr_51290_52705 = state_51278__$1;
(statearr_51290_52705[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (3))){
var inst_51276 = (state_51278[(2)]);
var state_51278__$1 = state_51278;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51278__$1,inst_51276);
} else {
if((state_val_51279 === (12))){
var inst_51253 = (state_51278[(10)]);
var state_51278__$1 = state_51278;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51278__$1,(14),inst_51253);
} else {
if((state_val_51279 === (2))){
var state_51278__$1 = state_51278;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51278__$1,(4),results);
} else {
if((state_val_51279 === (19))){
var state_51278__$1 = state_51278;
var statearr_51291_52709 = state_51278__$1;
(statearr_51291_52709[(2)] = null);

(statearr_51291_52709[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (11))){
var inst_51253 = (state_51278[(2)]);
var state_51278__$1 = (function (){var statearr_51292 = state_51278;
(statearr_51292[(10)] = inst_51253);

return statearr_51292;
})();
var statearr_51293_52710 = state_51278__$1;
(statearr_51293_52710[(2)] = null);

(statearr_51293_52710[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (9))){
var state_51278__$1 = state_51278;
var statearr_51294_52711 = state_51278__$1;
(statearr_51294_52711[(2)] = null);

(statearr_51294_52711[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (5))){
var state_51278__$1 = state_51278;
if(cljs.core.truth_(close_QMARK_)){
var statearr_51295_52712 = state_51278__$1;
(statearr_51295_52712[(1)] = (8));

} else {
var statearr_51296_52713 = state_51278__$1;
(statearr_51296_52713[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (14))){
var inst_51256 = (state_51278[(8)]);
var inst_51258 = (state_51278[(11)]);
var inst_51256__$1 = (state_51278[(2)]);
var inst_51257 = (inst_51256__$1 == null);
var inst_51258__$1 = cljs.core.not(inst_51257);
var state_51278__$1 = (function (){var statearr_51297 = state_51278;
(statearr_51297[(8)] = inst_51256__$1);

(statearr_51297[(11)] = inst_51258__$1);

return statearr_51297;
})();
if(inst_51258__$1){
var statearr_51298_52717 = state_51278__$1;
(statearr_51298_52717[(1)] = (15));

} else {
var statearr_51299_52718 = state_51278__$1;
(statearr_51299_52718[(1)] = (16));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (16))){
var inst_51258 = (state_51278[(11)]);
var state_51278__$1 = state_51278;
var statearr_51300_52719 = state_51278__$1;
(statearr_51300_52719[(2)] = inst_51258);

(statearr_51300_52719[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (10))){
var inst_51250 = (state_51278[(2)]);
var state_51278__$1 = state_51278;
var statearr_51301_52720 = state_51278__$1;
(statearr_51301_52720[(2)] = inst_51250);

(statearr_51301_52720[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (18))){
var inst_51261 = (state_51278[(2)]);
var state_51278__$1 = state_51278;
var statearr_51302_52721 = state_51278__$1;
(statearr_51302_52721[(2)] = inst_51261);

(statearr_51302_52721[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51279 === (8))){
var inst_51247 = cljs.core.async.close_BANG_(to);
var state_51278__$1 = state_51278;
var statearr_51303_52722 = state_51278__$1;
(statearr_51303_52722[(2)] = inst_51247);

(statearr_51303_52722[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto__,jobs,results,process,async))
;
return ((function (switch__50901__auto__,c__51002__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0 = (function (){
var statearr_51304 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_51304[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__);

(statearr_51304[(1)] = (1));

return statearr_51304;
});
var cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1 = (function (state_51278){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51278);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51305){if((e51305 instanceof Object)){
var ex__50905__auto__ = e51305;
var statearr_51306_52727 = state_51278;
(statearr_51306_52727[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51278);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51305;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52729 = state_51278;
state_51278 = G__52729;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__ = function(state_51278){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1.call(this,state_51278);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__50902__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto__,jobs,results,process,async))
})();
var state__51004__auto__ = (function (){var statearr_51307 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51307[(6)] = c__51002__auto__);

return statearr_51307;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto__,jobs,results,process,async))
);

return c__51002__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__51309 = arguments.length;
switch (G__51309) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,new cljs.core.Keyword(null,"async","async",1050769601));
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__51311 = arguments.length;
switch (G__51311) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,new cljs.core.Keyword(null,"compute","compute",1555393130));
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__51313 = arguments.length;
switch (G__51313) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__51002__auto___52749 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___52749,tc,fc){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___52749,tc,fc){
return (function (state_51339){
var state_val_51340 = (state_51339[(1)]);
if((state_val_51340 === (7))){
var inst_51335 = (state_51339[(2)]);
var state_51339__$1 = state_51339;
var statearr_51341_52753 = state_51339__$1;
(statearr_51341_52753[(2)] = inst_51335);

(statearr_51341_52753[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (1))){
var state_51339__$1 = state_51339;
var statearr_51342_52754 = state_51339__$1;
(statearr_51342_52754[(2)] = null);

(statearr_51342_52754[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (4))){
var inst_51316 = (state_51339[(7)]);
var inst_51316__$1 = (state_51339[(2)]);
var inst_51317 = (inst_51316__$1 == null);
var state_51339__$1 = (function (){var statearr_51343 = state_51339;
(statearr_51343[(7)] = inst_51316__$1);

return statearr_51343;
})();
if(cljs.core.truth_(inst_51317)){
var statearr_51344_52758 = state_51339__$1;
(statearr_51344_52758[(1)] = (5));

} else {
var statearr_51345_52759 = state_51339__$1;
(statearr_51345_52759[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (13))){
var state_51339__$1 = state_51339;
var statearr_51346_52760 = state_51339__$1;
(statearr_51346_52760[(2)] = null);

(statearr_51346_52760[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (6))){
var inst_51316 = (state_51339[(7)]);
var inst_51322 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_51316) : p.call(null,inst_51316));
var state_51339__$1 = state_51339;
if(cljs.core.truth_(inst_51322)){
var statearr_51347_52768 = state_51339__$1;
(statearr_51347_52768[(1)] = (9));

} else {
var statearr_51348_52769 = state_51339__$1;
(statearr_51348_52769[(1)] = (10));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (3))){
var inst_51337 = (state_51339[(2)]);
var state_51339__$1 = state_51339;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51339__$1,inst_51337);
} else {
if((state_val_51340 === (12))){
var state_51339__$1 = state_51339;
var statearr_51349_52773 = state_51339__$1;
(statearr_51349_52773[(2)] = null);

(statearr_51349_52773[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (2))){
var state_51339__$1 = state_51339;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51339__$1,(4),ch);
} else {
if((state_val_51340 === (11))){
var inst_51316 = (state_51339[(7)]);
var inst_51326 = (state_51339[(2)]);
var state_51339__$1 = state_51339;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51339__$1,(8),inst_51326,inst_51316);
} else {
if((state_val_51340 === (9))){
var state_51339__$1 = state_51339;
var statearr_51350_52780 = state_51339__$1;
(statearr_51350_52780[(2)] = tc);

(statearr_51350_52780[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (5))){
var inst_51319 = cljs.core.async.close_BANG_(tc);
var inst_51320 = cljs.core.async.close_BANG_(fc);
var state_51339__$1 = (function (){var statearr_51351 = state_51339;
(statearr_51351[(8)] = inst_51319);

return statearr_51351;
})();
var statearr_51352_52781 = state_51339__$1;
(statearr_51352_52781[(2)] = inst_51320);

(statearr_51352_52781[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (14))){
var inst_51333 = (state_51339[(2)]);
var state_51339__$1 = state_51339;
var statearr_51353_52788 = state_51339__$1;
(statearr_51353_52788[(2)] = inst_51333);

(statearr_51353_52788[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (10))){
var state_51339__$1 = state_51339;
var statearr_51354_52789 = state_51339__$1;
(statearr_51354_52789[(2)] = fc);

(statearr_51354_52789[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51340 === (8))){
var inst_51328 = (state_51339[(2)]);
var state_51339__$1 = state_51339;
if(cljs.core.truth_(inst_51328)){
var statearr_51355_52790 = state_51339__$1;
(statearr_51355_52790[(1)] = (12));

} else {
var statearr_51356_52791 = state_51339__$1;
(statearr_51356_52791[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___52749,tc,fc))
;
return ((function (switch__50901__auto__,c__51002__auto___52749,tc,fc){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_51357 = [null,null,null,null,null,null,null,null,null];
(statearr_51357[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_51357[(1)] = (1));

return statearr_51357;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_51339){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51339);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51358){if((e51358 instanceof Object)){
var ex__50905__auto__ = e51358;
var statearr_51359_52798 = state_51339;
(statearr_51359_52798[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51339);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51358;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52799 = state_51339;
state_51339 = G__52799;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_51339){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_51339);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___52749,tc,fc))
})();
var state__51004__auto__ = (function (){var statearr_51360 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51360[(6)] = c__51002__auto___52749);

return statearr_51360;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___52749,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__51002__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto__){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto__){
return (function (state_51381){
var state_val_51382 = (state_51381[(1)]);
if((state_val_51382 === (7))){
var inst_51377 = (state_51381[(2)]);
var state_51381__$1 = state_51381;
var statearr_51383_52801 = state_51381__$1;
(statearr_51383_52801[(2)] = inst_51377);

(statearr_51383_52801[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51382 === (1))){
var inst_51361 = init;
var state_51381__$1 = (function (){var statearr_51384 = state_51381;
(statearr_51384[(7)] = inst_51361);

return statearr_51384;
})();
var statearr_51385_52802 = state_51381__$1;
(statearr_51385_52802[(2)] = null);

(statearr_51385_52802[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51382 === (4))){
var inst_51364 = (state_51381[(8)]);
var inst_51364__$1 = (state_51381[(2)]);
var inst_51365 = (inst_51364__$1 == null);
var state_51381__$1 = (function (){var statearr_51386 = state_51381;
(statearr_51386[(8)] = inst_51364__$1);

return statearr_51386;
})();
if(cljs.core.truth_(inst_51365)){
var statearr_51387_52803 = state_51381__$1;
(statearr_51387_52803[(1)] = (5));

} else {
var statearr_51388_52804 = state_51381__$1;
(statearr_51388_52804[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51382 === (6))){
var inst_51361 = (state_51381[(7)]);
var inst_51368 = (state_51381[(9)]);
var inst_51364 = (state_51381[(8)]);
var inst_51368__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_51361,inst_51364) : f.call(null,inst_51361,inst_51364));
var inst_51369 = cljs.core.reduced_QMARK_(inst_51368__$1);
var state_51381__$1 = (function (){var statearr_51389 = state_51381;
(statearr_51389[(9)] = inst_51368__$1);

return statearr_51389;
})();
if(inst_51369){
var statearr_51390_52805 = state_51381__$1;
(statearr_51390_52805[(1)] = (8));

} else {
var statearr_51391_52806 = state_51381__$1;
(statearr_51391_52806[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51382 === (3))){
var inst_51379 = (state_51381[(2)]);
var state_51381__$1 = state_51381;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51381__$1,inst_51379);
} else {
if((state_val_51382 === (2))){
var state_51381__$1 = state_51381;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51381__$1,(4),ch);
} else {
if((state_val_51382 === (9))){
var inst_51368 = (state_51381[(9)]);
var inst_51361 = inst_51368;
var state_51381__$1 = (function (){var statearr_51392 = state_51381;
(statearr_51392[(7)] = inst_51361);

return statearr_51392;
})();
var statearr_51393_52807 = state_51381__$1;
(statearr_51393_52807[(2)] = null);

(statearr_51393_52807[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51382 === (5))){
var inst_51361 = (state_51381[(7)]);
var state_51381__$1 = state_51381;
var statearr_51394_52810 = state_51381__$1;
(statearr_51394_52810[(2)] = inst_51361);

(statearr_51394_52810[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51382 === (10))){
var inst_51375 = (state_51381[(2)]);
var state_51381__$1 = state_51381;
var statearr_51395_52811 = state_51381__$1;
(statearr_51395_52811[(2)] = inst_51375);

(statearr_51395_52811[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51382 === (8))){
var inst_51368 = (state_51381[(9)]);
var inst_51371 = cljs.core.deref(inst_51368);
var state_51381__$1 = state_51381;
var statearr_51396_52812 = state_51381__$1;
(statearr_51396_52812[(2)] = inst_51371);

(statearr_51396_52812[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto__))
;
return ((function (switch__50901__auto__,c__51002__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__50902__auto__ = null;
var cljs$core$async$reduce_$_state_machine__50902__auto____0 = (function (){
var statearr_51397 = [null,null,null,null,null,null,null,null,null,null];
(statearr_51397[(0)] = cljs$core$async$reduce_$_state_machine__50902__auto__);

(statearr_51397[(1)] = (1));

return statearr_51397;
});
var cljs$core$async$reduce_$_state_machine__50902__auto____1 = (function (state_51381){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51381);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51398){if((e51398 instanceof Object)){
var ex__50905__auto__ = e51398;
var statearr_51399_52813 = state_51381;
(statearr_51399_52813[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51381);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51398;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52814 = state_51381;
state_51381 = G__52814;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__50902__auto__ = function(state_51381){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__50902__auto____1.call(this,state_51381);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__50902__auto____0;
cljs$core$async$reduce_$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__50902__auto____1;
return cljs$core$async$reduce_$_state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto__))
})();
var state__51004__auto__ = (function (){var statearr_51400 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51400[(6)] = c__51002__auto__);

return statearr_51400;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto__))
);

return c__51002__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = (xform.cljs$core$IFn$_invoke$arity$1 ? xform.cljs$core$IFn$_invoke$arity$1(f) : xform.call(null,f));
var c__51002__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto__,f__$1){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto__,f__$1){
return (function (state_51406){
var state_val_51407 = (state_51406[(1)]);
if((state_val_51407 === (1))){
var inst_51401 = cljs.core.async.reduce(f__$1,init,ch);
var state_51406__$1 = state_51406;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51406__$1,(2),inst_51401);
} else {
if((state_val_51407 === (2))){
var inst_51403 = (state_51406[(2)]);
var inst_51404 = (f__$1.cljs$core$IFn$_invoke$arity$1 ? f__$1.cljs$core$IFn$_invoke$arity$1(inst_51403) : f__$1.call(null,inst_51403));
var state_51406__$1 = state_51406;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51406__$1,inst_51404);
} else {
return null;
}
}
});})(c__51002__auto__,f__$1))
;
return ((function (switch__50901__auto__,c__51002__auto__,f__$1){
return (function() {
var cljs$core$async$transduce_$_state_machine__50902__auto__ = null;
var cljs$core$async$transduce_$_state_machine__50902__auto____0 = (function (){
var statearr_51408 = [null,null,null,null,null,null,null];
(statearr_51408[(0)] = cljs$core$async$transduce_$_state_machine__50902__auto__);

(statearr_51408[(1)] = (1));

return statearr_51408;
});
var cljs$core$async$transduce_$_state_machine__50902__auto____1 = (function (state_51406){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51406);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51409){if((e51409 instanceof Object)){
var ex__50905__auto__ = e51409;
var statearr_51410_52822 = state_51406;
(statearr_51410_52822[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51406);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51409;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52823 = state_51406;
state_51406 = G__52823;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__50902__auto__ = function(state_51406){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__50902__auto____1.call(this,state_51406);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$transduce_$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__50902__auto____0;
cljs$core$async$transduce_$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__50902__auto____1;
return cljs$core$async$transduce_$_state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto__,f__$1))
})();
var state__51004__auto__ = (function (){var statearr_51411 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51411[(6)] = c__51002__auto__);

return statearr_51411;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto__,f__$1))
);

return c__51002__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__51413 = arguments.length;
switch (G__51413) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__51002__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto__){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto__){
return (function (state_51438){
var state_val_51439 = (state_51438[(1)]);
if((state_val_51439 === (7))){
var inst_51420 = (state_51438[(2)]);
var state_51438__$1 = state_51438;
var statearr_51440_52827 = state_51438__$1;
(statearr_51440_52827[(2)] = inst_51420);

(statearr_51440_52827[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (1))){
var inst_51414 = cljs.core.seq(coll);
var inst_51415 = inst_51414;
var state_51438__$1 = (function (){var statearr_51441 = state_51438;
(statearr_51441[(7)] = inst_51415);

return statearr_51441;
})();
var statearr_51442_52828 = state_51438__$1;
(statearr_51442_52828[(2)] = null);

(statearr_51442_52828[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (4))){
var inst_51415 = (state_51438[(7)]);
var inst_51418 = cljs.core.first(inst_51415);
var state_51438__$1 = state_51438;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51438__$1,(7),ch,inst_51418);
} else {
if((state_val_51439 === (13))){
var inst_51432 = (state_51438[(2)]);
var state_51438__$1 = state_51438;
var statearr_51443_52830 = state_51438__$1;
(statearr_51443_52830[(2)] = inst_51432);

(statearr_51443_52830[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (6))){
var inst_51423 = (state_51438[(2)]);
var state_51438__$1 = state_51438;
if(cljs.core.truth_(inst_51423)){
var statearr_51444_52834 = state_51438__$1;
(statearr_51444_52834[(1)] = (8));

} else {
var statearr_51445_52835 = state_51438__$1;
(statearr_51445_52835[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (3))){
var inst_51436 = (state_51438[(2)]);
var state_51438__$1 = state_51438;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51438__$1,inst_51436);
} else {
if((state_val_51439 === (12))){
var state_51438__$1 = state_51438;
var statearr_51446_52838 = state_51438__$1;
(statearr_51446_52838[(2)] = null);

(statearr_51446_52838[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (2))){
var inst_51415 = (state_51438[(7)]);
var state_51438__$1 = state_51438;
if(cljs.core.truth_(inst_51415)){
var statearr_51447_52841 = state_51438__$1;
(statearr_51447_52841[(1)] = (4));

} else {
var statearr_51448_52842 = state_51438__$1;
(statearr_51448_52842[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (11))){
var inst_51429 = cljs.core.async.close_BANG_(ch);
var state_51438__$1 = state_51438;
var statearr_51449_52843 = state_51438__$1;
(statearr_51449_52843[(2)] = inst_51429);

(statearr_51449_52843[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (9))){
var state_51438__$1 = state_51438;
if(cljs.core.truth_(close_QMARK_)){
var statearr_51450_52847 = state_51438__$1;
(statearr_51450_52847[(1)] = (11));

} else {
var statearr_51451_52852 = state_51438__$1;
(statearr_51451_52852[(1)] = (12));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (5))){
var inst_51415 = (state_51438[(7)]);
var state_51438__$1 = state_51438;
var statearr_51452_52853 = state_51438__$1;
(statearr_51452_52853[(2)] = inst_51415);

(statearr_51452_52853[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (10))){
var inst_51434 = (state_51438[(2)]);
var state_51438__$1 = state_51438;
var statearr_51453_52860 = state_51438__$1;
(statearr_51453_52860[(2)] = inst_51434);

(statearr_51453_52860[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51439 === (8))){
var inst_51415 = (state_51438[(7)]);
var inst_51425 = cljs.core.next(inst_51415);
var inst_51415__$1 = inst_51425;
var state_51438__$1 = (function (){var statearr_51454 = state_51438;
(statearr_51454[(7)] = inst_51415__$1);

return statearr_51454;
})();
var statearr_51455_52861 = state_51438__$1;
(statearr_51455_52861[(2)] = null);

(statearr_51455_52861[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto__))
;
return ((function (switch__50901__auto__,c__51002__auto__){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_51456 = [null,null,null,null,null,null,null,null];
(statearr_51456[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_51456[(1)] = (1));

return statearr_51456;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_51438){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51438);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51457){if((e51457 instanceof Object)){
var ex__50905__auto__ = e51457;
var statearr_51458_52862 = state_51438;
(statearr_51458_52862[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51438);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51457;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52863 = state_51438;
state_51438 = G__52863;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_51438){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_51438);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto__))
})();
var state__51004__auto__ = (function (){var statearr_51459 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51459[(6)] = c__51002__auto__);

return statearr_51459;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto__))
);

return c__51002__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((((!((_ == null)))) && ((!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4433__auto__ = (((_ == null))?null:_);
var m__4434__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4434__auto__.call(null,_));
} else {
var m__4431__auto__ = (cljs.core.async.muxch_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4431__auto__.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4434__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__4431__auto__ = (cljs.core.async.tap_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4431__auto__.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.untap_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4434__auto__.call(null,m));
} else {
var m__4431__auto__ = (cljs.core.async.untap_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4431__auto__.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async51460 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async51460 = (function (ch,cs,meta51461){
this.ch = ch;
this.cs = cs;
this.meta51461 = meta51461;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async51460.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_51462,meta51461__$1){
var self__ = this;
var _51462__$1 = this;
return (new cljs.core.async.t_cljs$core$async51460(self__.ch,self__.cs,meta51461__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async51460.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_51462){
var self__ = this;
var _51462__$1 = this;
return self__.meta51461;
});})(cs))
;

cljs.core.async.t_cljs$core$async51460.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51460.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async51460.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51460.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async51460.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async51460.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async51460.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"meta51461","meta51461",-1021103168,null)], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async51460.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async51460.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async51460";

cljs.core.async.t_cljs$core$async51460.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async51460");
});})(cs))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async51460.
 */
cljs.core.async.__GT_t_cljs$core$async51460 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async51460(ch__$1,cs__$1,meta51461){
return (new cljs.core.async.t_cljs$core$async51460(ch__$1,cs__$1,meta51461));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async51460(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__51002__auto___52882 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___52882,cs,m,dchan,dctr,done){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___52882,cs,m,dchan,dctr,done){
return (function (state_51597){
var state_val_51598 = (state_51597[(1)]);
if((state_val_51598 === (7))){
var inst_51593 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51599_52883 = state_51597__$1;
(statearr_51599_52883[(2)] = inst_51593);

(statearr_51599_52883[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (20))){
var inst_51496 = (state_51597[(7)]);
var inst_51508 = cljs.core.first(inst_51496);
var inst_51509 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_51508,(0),null);
var inst_51510 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_51508,(1),null);
var state_51597__$1 = (function (){var statearr_51600 = state_51597;
(statearr_51600[(8)] = inst_51509);

return statearr_51600;
})();
if(cljs.core.truth_(inst_51510)){
var statearr_51601_52884 = state_51597__$1;
(statearr_51601_52884[(1)] = (22));

} else {
var statearr_51602_52885 = state_51597__$1;
(statearr_51602_52885[(1)] = (23));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (27))){
var inst_51538 = (state_51597[(9)]);
var inst_51540 = (state_51597[(10)]);
var inst_51465 = (state_51597[(11)]);
var inst_51545 = (state_51597[(12)]);
var inst_51545__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_51538,inst_51540);
var inst_51546 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_51545__$1,inst_51465,done);
var state_51597__$1 = (function (){var statearr_51603 = state_51597;
(statearr_51603[(12)] = inst_51545__$1);

return statearr_51603;
})();
if(cljs.core.truth_(inst_51546)){
var statearr_51604_52886 = state_51597__$1;
(statearr_51604_52886[(1)] = (30));

} else {
var statearr_51605_52887 = state_51597__$1;
(statearr_51605_52887[(1)] = (31));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (1))){
var state_51597__$1 = state_51597;
var statearr_51606_52888 = state_51597__$1;
(statearr_51606_52888[(2)] = null);

(statearr_51606_52888[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (24))){
var inst_51496 = (state_51597[(7)]);
var inst_51515 = (state_51597[(2)]);
var inst_51516 = cljs.core.next(inst_51496);
var inst_51474 = inst_51516;
var inst_51475 = null;
var inst_51476 = (0);
var inst_51477 = (0);
var state_51597__$1 = (function (){var statearr_51607 = state_51597;
(statearr_51607[(13)] = inst_51515);

(statearr_51607[(14)] = inst_51474);

(statearr_51607[(15)] = inst_51475);

(statearr_51607[(16)] = inst_51476);

(statearr_51607[(17)] = inst_51477);

return statearr_51607;
})();
var statearr_51608_52889 = state_51597__$1;
(statearr_51608_52889[(2)] = null);

(statearr_51608_52889[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (39))){
var state_51597__$1 = state_51597;
var statearr_51612_52890 = state_51597__$1;
(statearr_51612_52890[(2)] = null);

(statearr_51612_52890[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (4))){
var inst_51465 = (state_51597[(11)]);
var inst_51465__$1 = (state_51597[(2)]);
var inst_51466 = (inst_51465__$1 == null);
var state_51597__$1 = (function (){var statearr_51613 = state_51597;
(statearr_51613[(11)] = inst_51465__$1);

return statearr_51613;
})();
if(cljs.core.truth_(inst_51466)){
var statearr_51614_52891 = state_51597__$1;
(statearr_51614_52891[(1)] = (5));

} else {
var statearr_51615_52892 = state_51597__$1;
(statearr_51615_52892[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (15))){
var inst_51474 = (state_51597[(14)]);
var inst_51475 = (state_51597[(15)]);
var inst_51476 = (state_51597[(16)]);
var inst_51477 = (state_51597[(17)]);
var inst_51492 = (state_51597[(2)]);
var inst_51493 = (inst_51477 + (1));
var tmp51609 = inst_51474;
var tmp51610 = inst_51475;
var tmp51611 = inst_51476;
var inst_51474__$1 = tmp51609;
var inst_51475__$1 = tmp51610;
var inst_51476__$1 = tmp51611;
var inst_51477__$1 = inst_51493;
var state_51597__$1 = (function (){var statearr_51616 = state_51597;
(statearr_51616[(14)] = inst_51474__$1);

(statearr_51616[(15)] = inst_51475__$1);

(statearr_51616[(16)] = inst_51476__$1);

(statearr_51616[(18)] = inst_51492);

(statearr_51616[(17)] = inst_51477__$1);

return statearr_51616;
})();
var statearr_51617_52894 = state_51597__$1;
(statearr_51617_52894[(2)] = null);

(statearr_51617_52894[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (21))){
var inst_51519 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51621_52896 = state_51597__$1;
(statearr_51621_52896[(2)] = inst_51519);

(statearr_51621_52896[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (31))){
var inst_51545 = (state_51597[(12)]);
var inst_51549 = done(null);
var inst_51550 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_51545);
var state_51597__$1 = (function (){var statearr_51622 = state_51597;
(statearr_51622[(19)] = inst_51549);

return statearr_51622;
})();
var statearr_51623_52901 = state_51597__$1;
(statearr_51623_52901[(2)] = inst_51550);

(statearr_51623_52901[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (32))){
var inst_51538 = (state_51597[(9)]);
var inst_51540 = (state_51597[(10)]);
var inst_51539 = (state_51597[(20)]);
var inst_51537 = (state_51597[(21)]);
var inst_51552 = (state_51597[(2)]);
var inst_51553 = (inst_51540 + (1));
var tmp51618 = inst_51538;
var tmp51619 = inst_51539;
var tmp51620 = inst_51537;
var inst_51537__$1 = tmp51620;
var inst_51538__$1 = tmp51618;
var inst_51539__$1 = tmp51619;
var inst_51540__$1 = inst_51553;
var state_51597__$1 = (function (){var statearr_51624 = state_51597;
(statearr_51624[(9)] = inst_51538__$1);

(statearr_51624[(10)] = inst_51540__$1);

(statearr_51624[(22)] = inst_51552);

(statearr_51624[(20)] = inst_51539__$1);

(statearr_51624[(21)] = inst_51537__$1);

return statearr_51624;
})();
var statearr_51625_52902 = state_51597__$1;
(statearr_51625_52902[(2)] = null);

(statearr_51625_52902[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (40))){
var inst_51565 = (state_51597[(23)]);
var inst_51569 = done(null);
var inst_51570 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_51565);
var state_51597__$1 = (function (){var statearr_51626 = state_51597;
(statearr_51626[(24)] = inst_51569);

return statearr_51626;
})();
var statearr_51627_52905 = state_51597__$1;
(statearr_51627_52905[(2)] = inst_51570);

(statearr_51627_52905[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (33))){
var inst_51556 = (state_51597[(25)]);
var inst_51558 = cljs.core.chunked_seq_QMARK_(inst_51556);
var state_51597__$1 = state_51597;
if(inst_51558){
var statearr_51628_52907 = state_51597__$1;
(statearr_51628_52907[(1)] = (36));

} else {
var statearr_51629_52909 = state_51597__$1;
(statearr_51629_52909[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (13))){
var inst_51486 = (state_51597[(26)]);
var inst_51489 = cljs.core.async.close_BANG_(inst_51486);
var state_51597__$1 = state_51597;
var statearr_51630_52910 = state_51597__$1;
(statearr_51630_52910[(2)] = inst_51489);

(statearr_51630_52910[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (22))){
var inst_51509 = (state_51597[(8)]);
var inst_51512 = cljs.core.async.close_BANG_(inst_51509);
var state_51597__$1 = state_51597;
var statearr_51631_52912 = state_51597__$1;
(statearr_51631_52912[(2)] = inst_51512);

(statearr_51631_52912[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (36))){
var inst_51556 = (state_51597[(25)]);
var inst_51560 = cljs.core.chunk_first(inst_51556);
var inst_51561 = cljs.core.chunk_rest(inst_51556);
var inst_51562 = cljs.core.count(inst_51560);
var inst_51537 = inst_51561;
var inst_51538 = inst_51560;
var inst_51539 = inst_51562;
var inst_51540 = (0);
var state_51597__$1 = (function (){var statearr_51632 = state_51597;
(statearr_51632[(9)] = inst_51538);

(statearr_51632[(10)] = inst_51540);

(statearr_51632[(20)] = inst_51539);

(statearr_51632[(21)] = inst_51537);

return statearr_51632;
})();
var statearr_51633_52914 = state_51597__$1;
(statearr_51633_52914[(2)] = null);

(statearr_51633_52914[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (41))){
var inst_51556 = (state_51597[(25)]);
var inst_51572 = (state_51597[(2)]);
var inst_51573 = cljs.core.next(inst_51556);
var inst_51537 = inst_51573;
var inst_51538 = null;
var inst_51539 = (0);
var inst_51540 = (0);
var state_51597__$1 = (function (){var statearr_51634 = state_51597;
(statearr_51634[(9)] = inst_51538);

(statearr_51634[(27)] = inst_51572);

(statearr_51634[(10)] = inst_51540);

(statearr_51634[(20)] = inst_51539);

(statearr_51634[(21)] = inst_51537);

return statearr_51634;
})();
var statearr_51635_52915 = state_51597__$1;
(statearr_51635_52915[(2)] = null);

(statearr_51635_52915[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (43))){
var state_51597__$1 = state_51597;
var statearr_51636_52916 = state_51597__$1;
(statearr_51636_52916[(2)] = null);

(statearr_51636_52916[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (29))){
var inst_51581 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51637_52917 = state_51597__$1;
(statearr_51637_52917[(2)] = inst_51581);

(statearr_51637_52917[(1)] = (26));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (44))){
var inst_51590 = (state_51597[(2)]);
var state_51597__$1 = (function (){var statearr_51638 = state_51597;
(statearr_51638[(28)] = inst_51590);

return statearr_51638;
})();
var statearr_51639_52920 = state_51597__$1;
(statearr_51639_52920[(2)] = null);

(statearr_51639_52920[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (6))){
var inst_51529 = (state_51597[(29)]);
var inst_51528 = cljs.core.deref(cs);
var inst_51529__$1 = cljs.core.keys(inst_51528);
var inst_51530 = cljs.core.count(inst_51529__$1);
var inst_51531 = cljs.core.reset_BANG_(dctr,inst_51530);
var inst_51536 = cljs.core.seq(inst_51529__$1);
var inst_51537 = inst_51536;
var inst_51538 = null;
var inst_51539 = (0);
var inst_51540 = (0);
var state_51597__$1 = (function (){var statearr_51640 = state_51597;
(statearr_51640[(9)] = inst_51538);

(statearr_51640[(30)] = inst_51531);

(statearr_51640[(29)] = inst_51529__$1);

(statearr_51640[(10)] = inst_51540);

(statearr_51640[(20)] = inst_51539);

(statearr_51640[(21)] = inst_51537);

return statearr_51640;
})();
var statearr_51641_52921 = state_51597__$1;
(statearr_51641_52921[(2)] = null);

(statearr_51641_52921[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (28))){
var inst_51556 = (state_51597[(25)]);
var inst_51537 = (state_51597[(21)]);
var inst_51556__$1 = cljs.core.seq(inst_51537);
var state_51597__$1 = (function (){var statearr_51642 = state_51597;
(statearr_51642[(25)] = inst_51556__$1);

return statearr_51642;
})();
if(inst_51556__$1){
var statearr_51643_52922 = state_51597__$1;
(statearr_51643_52922[(1)] = (33));

} else {
var statearr_51644_52923 = state_51597__$1;
(statearr_51644_52923[(1)] = (34));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (25))){
var inst_51540 = (state_51597[(10)]);
var inst_51539 = (state_51597[(20)]);
var inst_51542 = (inst_51540 < inst_51539);
var inst_51543 = inst_51542;
var state_51597__$1 = state_51597;
if(cljs.core.truth_(inst_51543)){
var statearr_51645_52924 = state_51597__$1;
(statearr_51645_52924[(1)] = (27));

} else {
var statearr_51646_52925 = state_51597__$1;
(statearr_51646_52925[(1)] = (28));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (34))){
var state_51597__$1 = state_51597;
var statearr_51647_52926 = state_51597__$1;
(statearr_51647_52926[(2)] = null);

(statearr_51647_52926[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (17))){
var state_51597__$1 = state_51597;
var statearr_51648_52927 = state_51597__$1;
(statearr_51648_52927[(2)] = null);

(statearr_51648_52927[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (3))){
var inst_51595 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51597__$1,inst_51595);
} else {
if((state_val_51598 === (12))){
var inst_51524 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51649_52928 = state_51597__$1;
(statearr_51649_52928[(2)] = inst_51524);

(statearr_51649_52928[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (2))){
var state_51597__$1 = state_51597;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51597__$1,(4),ch);
} else {
if((state_val_51598 === (23))){
var state_51597__$1 = state_51597;
var statearr_51650_52929 = state_51597__$1;
(statearr_51650_52929[(2)] = null);

(statearr_51650_52929[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (35))){
var inst_51579 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51651_52930 = state_51597__$1;
(statearr_51651_52930[(2)] = inst_51579);

(statearr_51651_52930[(1)] = (29));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (19))){
var inst_51496 = (state_51597[(7)]);
var inst_51500 = cljs.core.chunk_first(inst_51496);
var inst_51501 = cljs.core.chunk_rest(inst_51496);
var inst_51502 = cljs.core.count(inst_51500);
var inst_51474 = inst_51501;
var inst_51475 = inst_51500;
var inst_51476 = inst_51502;
var inst_51477 = (0);
var state_51597__$1 = (function (){var statearr_51652 = state_51597;
(statearr_51652[(14)] = inst_51474);

(statearr_51652[(15)] = inst_51475);

(statearr_51652[(16)] = inst_51476);

(statearr_51652[(17)] = inst_51477);

return statearr_51652;
})();
var statearr_51653_52932 = state_51597__$1;
(statearr_51653_52932[(2)] = null);

(statearr_51653_52932[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (11))){
var inst_51496 = (state_51597[(7)]);
var inst_51474 = (state_51597[(14)]);
var inst_51496__$1 = cljs.core.seq(inst_51474);
var state_51597__$1 = (function (){var statearr_51654 = state_51597;
(statearr_51654[(7)] = inst_51496__$1);

return statearr_51654;
})();
if(inst_51496__$1){
var statearr_51655_52937 = state_51597__$1;
(statearr_51655_52937[(1)] = (16));

} else {
var statearr_51656_52938 = state_51597__$1;
(statearr_51656_52938[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (9))){
var inst_51526 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51657_52939 = state_51597__$1;
(statearr_51657_52939[(2)] = inst_51526);

(statearr_51657_52939[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (5))){
var inst_51472 = cljs.core.deref(cs);
var inst_51473 = cljs.core.seq(inst_51472);
var inst_51474 = inst_51473;
var inst_51475 = null;
var inst_51476 = (0);
var inst_51477 = (0);
var state_51597__$1 = (function (){var statearr_51658 = state_51597;
(statearr_51658[(14)] = inst_51474);

(statearr_51658[(15)] = inst_51475);

(statearr_51658[(16)] = inst_51476);

(statearr_51658[(17)] = inst_51477);

return statearr_51658;
})();
var statearr_51659_52940 = state_51597__$1;
(statearr_51659_52940[(2)] = null);

(statearr_51659_52940[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (14))){
var state_51597__$1 = state_51597;
var statearr_51660_52941 = state_51597__$1;
(statearr_51660_52941[(2)] = null);

(statearr_51660_52941[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (45))){
var inst_51587 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51661_52942 = state_51597__$1;
(statearr_51661_52942[(2)] = inst_51587);

(statearr_51661_52942[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (26))){
var inst_51529 = (state_51597[(29)]);
var inst_51583 = (state_51597[(2)]);
var inst_51584 = cljs.core.seq(inst_51529);
var state_51597__$1 = (function (){var statearr_51662 = state_51597;
(statearr_51662[(31)] = inst_51583);

return statearr_51662;
})();
if(inst_51584){
var statearr_51663_52943 = state_51597__$1;
(statearr_51663_52943[(1)] = (42));

} else {
var statearr_51664_52944 = state_51597__$1;
(statearr_51664_52944[(1)] = (43));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (16))){
var inst_51496 = (state_51597[(7)]);
var inst_51498 = cljs.core.chunked_seq_QMARK_(inst_51496);
var state_51597__$1 = state_51597;
if(inst_51498){
var statearr_51665_52945 = state_51597__$1;
(statearr_51665_52945[(1)] = (19));

} else {
var statearr_51666_52946 = state_51597__$1;
(statearr_51666_52946[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (38))){
var inst_51576 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51667_52951 = state_51597__$1;
(statearr_51667_52951[(2)] = inst_51576);

(statearr_51667_52951[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (30))){
var state_51597__$1 = state_51597;
var statearr_51668_52955 = state_51597__$1;
(statearr_51668_52955[(2)] = null);

(statearr_51668_52955[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (10))){
var inst_51475 = (state_51597[(15)]);
var inst_51477 = (state_51597[(17)]);
var inst_51485 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_51475,inst_51477);
var inst_51486 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_51485,(0),null);
var inst_51487 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_51485,(1),null);
var state_51597__$1 = (function (){var statearr_51669 = state_51597;
(statearr_51669[(26)] = inst_51486);

return statearr_51669;
})();
if(cljs.core.truth_(inst_51487)){
var statearr_51670_52959 = state_51597__$1;
(statearr_51670_52959[(1)] = (13));

} else {
var statearr_51671_52960 = state_51597__$1;
(statearr_51671_52960[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (18))){
var inst_51522 = (state_51597[(2)]);
var state_51597__$1 = state_51597;
var statearr_51672_52964 = state_51597__$1;
(statearr_51672_52964[(2)] = inst_51522);

(statearr_51672_52964[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (42))){
var state_51597__$1 = state_51597;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51597__$1,(45),dchan);
} else {
if((state_val_51598 === (37))){
var inst_51556 = (state_51597[(25)]);
var inst_51565 = (state_51597[(23)]);
var inst_51465 = (state_51597[(11)]);
var inst_51565__$1 = cljs.core.first(inst_51556);
var inst_51566 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_51565__$1,inst_51465,done);
var state_51597__$1 = (function (){var statearr_51673 = state_51597;
(statearr_51673[(23)] = inst_51565__$1);

return statearr_51673;
})();
if(cljs.core.truth_(inst_51566)){
var statearr_51674_52968 = state_51597__$1;
(statearr_51674_52968[(1)] = (39));

} else {
var statearr_51675_52969 = state_51597__$1;
(statearr_51675_52969[(1)] = (40));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51598 === (8))){
var inst_51476 = (state_51597[(16)]);
var inst_51477 = (state_51597[(17)]);
var inst_51479 = (inst_51477 < inst_51476);
var inst_51480 = inst_51479;
var state_51597__$1 = state_51597;
if(cljs.core.truth_(inst_51480)){
var statearr_51676_52974 = state_51597__$1;
(statearr_51676_52974[(1)] = (10));

} else {
var statearr_51677_52975 = state_51597__$1;
(statearr_51677_52975[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___52882,cs,m,dchan,dctr,done))
;
return ((function (switch__50901__auto__,c__51002__auto___52882,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__50902__auto__ = null;
var cljs$core$async$mult_$_state_machine__50902__auto____0 = (function (){
var statearr_51678 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_51678[(0)] = cljs$core$async$mult_$_state_machine__50902__auto__);

(statearr_51678[(1)] = (1));

return statearr_51678;
});
var cljs$core$async$mult_$_state_machine__50902__auto____1 = (function (state_51597){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51597);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51679){if((e51679 instanceof Object)){
var ex__50905__auto__ = e51679;
var statearr_51680_52976 = state_51597;
(statearr_51680_52976[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51597);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51679;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__52979 = state_51597;
state_51597 = G__52979;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__50902__auto__ = function(state_51597){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__50902__auto____1.call(this,state_51597);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__50902__auto____0;
cljs$core$async$mult_$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__50902__auto____1;
return cljs$core$async$mult_$_state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___52882,cs,m,dchan,dctr,done))
})();
var state__51004__auto__ = (function (){var statearr_51681 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51681[(6)] = c__51002__auto___52882);

return statearr_51681;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___52882,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__51683 = arguments.length;
switch (G__51683) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.admix_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.unmix_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4434__auto__.call(null,m));
} else {
var m__4431__auto__ = (cljs.core.async.unmix_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4431__auto__.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4434__auto__.call(null,m,state_map));
} else {
var m__4431__auto__ = (cljs.core.async.toggle_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4431__auto__.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4434__auto__.call(null,m,mode));
} else {
var m__4431__auto__ = (cljs.core.async.solo_mode_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4431__auto__.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___52995 = arguments.length;
var i__4731__auto___52996 = (0);
while(true){
if((i__4731__auto___52996 < len__4730__auto___52995)){
args__4736__auto__.push((arguments[i__4731__auto___52996]));

var G__52997 = (i__4731__auto___52996 + (1));
i__4731__auto___52996 = G__52997;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((3) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4737__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__51688){
var map__51689 = p__51688;
var map__51689__$1 = (((((!((map__51689 == null))))?(((((map__51689.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__51689.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__51689):map__51689);
var opts = map__51689__$1;
var statearr_51691_52998 = state;
(statearr_51691_52998[(1)] = cont_block);


var temp__5735__auto__ = cljs.core.async.do_alts(((function (map__51689,map__51689__$1,opts){
return (function (val){
var statearr_51692_52999 = state;
(statearr_51692_52999[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
});})(map__51689,map__51689__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__5735__auto__)){
var cb = temp__5735__auto__;
var statearr_51693_53000 = state;
(statearr_51693_53000[(2)] = cljs.core.deref(cb));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

/** @this {Function} */
cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq51684){
var G__51685 = cljs.core.first(seq51684);
var seq51684__$1 = cljs.core.next(seq51684);
var G__51686 = cljs.core.first(seq51684__$1);
var seq51684__$2 = cljs.core.next(seq51684__$1);
var G__51687 = cljs.core.first(seq51684__$2);
var seq51684__$3 = cljs.core.next(seq51684__$2);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__51685,G__51686,G__51687,seq51684__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"pause","pause",-2095325672),null,new cljs.core.Keyword(null,"mute","mute",1151223646),null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,new cljs.core.Keyword(null,"solo","solo",-316350075));
var solo_mode = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"mute","mute",1151223646));
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv(((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref(cs);
var mode = cljs.core.deref(solo_mode);
var solos = pick(new cljs.core.Keyword(null,"solo","solo",-316350075),chs);
var pauses = pick(new cljs.core.Keyword(null,"pause","pause",-2095325672),chs);
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"solos","solos",1441458643),solos,new cljs.core.Keyword(null,"mutes","mutes",1068806309),pick(new cljs.core.Keyword(null,"mute","mute",1151223646),chs),new cljs.core.Keyword(null,"reads","reads",-1215067361),cljs.core.conj.cljs$core$IFn$_invoke$arity$2(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,new cljs.core.Keyword(null,"pause","pause",-2095325672))) && ((!(cljs.core.empty_QMARK_(solos))))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async51694 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async51694 = (function (change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta51695){
this.change = change;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta51695 = meta51695;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_51696,meta51695__$1){
var self__ = this;
var _51696__$1 = this;
return (new cljs.core.async.t_cljs$core$async51694(self__.change,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta51695__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_51696){
var self__ = this;
var _51696__$1 = this;
return self__.meta51695;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.solo_modes.cljs$core$IFn$_invoke$arity$1 ? self__.solo_modes.cljs$core$IFn$_invoke$arity$1(mode) : self__.solo_modes.call(null,mode)))){
} else {
throw (new Error(["Assert failed: ",["mode must be one of: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(self__.solo_modes)].join(''),"\n","(solo-modes mode)"].join('')));
}

cljs.core.reset_BANG_(self__.solo_mode,mode);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"change","change",477485025,null),new cljs.core.Symbol(null,"solo-mode","solo-mode",2031788074,null),new cljs.core.Symbol(null,"pick","pick",1300068175,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"calc-state","calc-state",-349968968,null),new cljs.core.Symbol(null,"out","out",729986010,null),new cljs.core.Symbol(null,"changed","changed",-2083710852,null),new cljs.core.Symbol(null,"solo-modes","solo-modes",882180540,null),new cljs.core.Symbol(null,"attrs","attrs",-450137186,null),new cljs.core.Symbol(null,"meta51695","meta51695",663199467,null)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async51694.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async51694.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async51694";

cljs.core.async.t_cljs$core$async51694.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async51694");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async51694.
 */
cljs.core.async.__GT_t_cljs$core$async51694 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async51694(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta51695){
return (new cljs.core.async.t_cljs$core$async51694(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta51695));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async51694(change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__51002__auto___53019 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53019,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53019,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_51798){
var state_val_51799 = (state_51798[(1)]);
if((state_val_51799 === (7))){
var inst_51713 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
var statearr_51800_53020 = state_51798__$1;
(statearr_51800_53020[(2)] = inst_51713);

(statearr_51800_53020[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (20))){
var inst_51725 = (state_51798[(7)]);
var state_51798__$1 = state_51798;
var statearr_51801_53021 = state_51798__$1;
(statearr_51801_53021[(2)] = inst_51725);

(statearr_51801_53021[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (27))){
var state_51798__$1 = state_51798;
var statearr_51802_53022 = state_51798__$1;
(statearr_51802_53022[(2)] = null);

(statearr_51802_53022[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (1))){
var inst_51700 = (state_51798[(8)]);
var inst_51700__$1 = calc_state();
var inst_51702 = (inst_51700__$1 == null);
var inst_51703 = cljs.core.not(inst_51702);
var state_51798__$1 = (function (){var statearr_51803 = state_51798;
(statearr_51803[(8)] = inst_51700__$1);

return statearr_51803;
})();
if(inst_51703){
var statearr_51804_53023 = state_51798__$1;
(statearr_51804_53023[(1)] = (2));

} else {
var statearr_51805_53024 = state_51798__$1;
(statearr_51805_53024[(1)] = (3));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (24))){
var inst_51758 = (state_51798[(9)]);
var inst_51749 = (state_51798[(10)]);
var inst_51772 = (state_51798[(11)]);
var inst_51772__$1 = (inst_51749.cljs$core$IFn$_invoke$arity$1 ? inst_51749.cljs$core$IFn$_invoke$arity$1(inst_51758) : inst_51749.call(null,inst_51758));
var state_51798__$1 = (function (){var statearr_51806 = state_51798;
(statearr_51806[(11)] = inst_51772__$1);

return statearr_51806;
})();
if(cljs.core.truth_(inst_51772__$1)){
var statearr_51807_53026 = state_51798__$1;
(statearr_51807_53026[(1)] = (29));

} else {
var statearr_51808_53027 = state_51798__$1;
(statearr_51808_53027[(1)] = (30));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (4))){
var inst_51716 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
if(cljs.core.truth_(inst_51716)){
var statearr_51809_53028 = state_51798__$1;
(statearr_51809_53028[(1)] = (8));

} else {
var statearr_51810_53029 = state_51798__$1;
(statearr_51810_53029[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (15))){
var inst_51743 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
if(cljs.core.truth_(inst_51743)){
var statearr_51811_53030 = state_51798__$1;
(statearr_51811_53030[(1)] = (19));

} else {
var statearr_51812_53032 = state_51798__$1;
(statearr_51812_53032[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (21))){
var inst_51748 = (state_51798[(12)]);
var inst_51748__$1 = (state_51798[(2)]);
var inst_51749 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_51748__$1,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_51750 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_51748__$1,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_51751 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_51748__$1,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var state_51798__$1 = (function (){var statearr_51813 = state_51798;
(statearr_51813[(13)] = inst_51750);

(statearr_51813[(12)] = inst_51748__$1);

(statearr_51813[(10)] = inst_51749);

return statearr_51813;
})();
return cljs.core.async.ioc_alts_BANG_(state_51798__$1,(22),inst_51751);
} else {
if((state_val_51799 === (31))){
var inst_51780 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
if(cljs.core.truth_(inst_51780)){
var statearr_51814_53034 = state_51798__$1;
(statearr_51814_53034[(1)] = (32));

} else {
var statearr_51815_53035 = state_51798__$1;
(statearr_51815_53035[(1)] = (33));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (32))){
var inst_51757 = (state_51798[(14)]);
var state_51798__$1 = state_51798;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51798__$1,(35),out,inst_51757);
} else {
if((state_val_51799 === (33))){
var inst_51748 = (state_51798[(12)]);
var inst_51725 = inst_51748;
var state_51798__$1 = (function (){var statearr_51816 = state_51798;
(statearr_51816[(7)] = inst_51725);

return statearr_51816;
})();
var statearr_51817_53041 = state_51798__$1;
(statearr_51817_53041[(2)] = null);

(statearr_51817_53041[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (13))){
var inst_51725 = (state_51798[(7)]);
var inst_51732 = inst_51725.cljs$lang$protocol_mask$partition0$;
var inst_51733 = (inst_51732 & (64));
var inst_51734 = inst_51725.cljs$core$ISeq$;
var inst_51735 = (cljs.core.PROTOCOL_SENTINEL === inst_51734);
var inst_51736 = ((inst_51733) || (inst_51735));
var state_51798__$1 = state_51798;
if(cljs.core.truth_(inst_51736)){
var statearr_51818_53043 = state_51798__$1;
(statearr_51818_53043[(1)] = (16));

} else {
var statearr_51819_53044 = state_51798__$1;
(statearr_51819_53044[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (22))){
var inst_51757 = (state_51798[(14)]);
var inst_51758 = (state_51798[(9)]);
var inst_51756 = (state_51798[(2)]);
var inst_51757__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_51756,(0),null);
var inst_51758__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_51756,(1),null);
var inst_51759 = (inst_51757__$1 == null);
var inst_51760 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_51758__$1,change);
var inst_51761 = ((inst_51759) || (inst_51760));
var state_51798__$1 = (function (){var statearr_51820 = state_51798;
(statearr_51820[(14)] = inst_51757__$1);

(statearr_51820[(9)] = inst_51758__$1);

return statearr_51820;
})();
if(cljs.core.truth_(inst_51761)){
var statearr_51821_53045 = state_51798__$1;
(statearr_51821_53045[(1)] = (23));

} else {
var statearr_51822_53046 = state_51798__$1;
(statearr_51822_53046[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (36))){
var inst_51748 = (state_51798[(12)]);
var inst_51725 = inst_51748;
var state_51798__$1 = (function (){var statearr_51823 = state_51798;
(statearr_51823[(7)] = inst_51725);

return statearr_51823;
})();
var statearr_51824_53048 = state_51798__$1;
(statearr_51824_53048[(2)] = null);

(statearr_51824_53048[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (29))){
var inst_51772 = (state_51798[(11)]);
var state_51798__$1 = state_51798;
var statearr_51825_53049 = state_51798__$1;
(statearr_51825_53049[(2)] = inst_51772);

(statearr_51825_53049[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (6))){
var state_51798__$1 = state_51798;
var statearr_51826_53051 = state_51798__$1;
(statearr_51826_53051[(2)] = false);

(statearr_51826_53051[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (28))){
var inst_51768 = (state_51798[(2)]);
var inst_51769 = calc_state();
var inst_51725 = inst_51769;
var state_51798__$1 = (function (){var statearr_51827 = state_51798;
(statearr_51827[(7)] = inst_51725);

(statearr_51827[(15)] = inst_51768);

return statearr_51827;
})();
var statearr_51828_53055 = state_51798__$1;
(statearr_51828_53055[(2)] = null);

(statearr_51828_53055[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (25))){
var inst_51794 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
var statearr_51829_53056 = state_51798__$1;
(statearr_51829_53056[(2)] = inst_51794);

(statearr_51829_53056[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (34))){
var inst_51792 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
var statearr_51830_53057 = state_51798__$1;
(statearr_51830_53057[(2)] = inst_51792);

(statearr_51830_53057[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (17))){
var state_51798__$1 = state_51798;
var statearr_51831_53058 = state_51798__$1;
(statearr_51831_53058[(2)] = false);

(statearr_51831_53058[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (3))){
var state_51798__$1 = state_51798;
var statearr_51832_53059 = state_51798__$1;
(statearr_51832_53059[(2)] = false);

(statearr_51832_53059[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (12))){
var inst_51796 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51798__$1,inst_51796);
} else {
if((state_val_51799 === (2))){
var inst_51700 = (state_51798[(8)]);
var inst_51705 = inst_51700.cljs$lang$protocol_mask$partition0$;
var inst_51706 = (inst_51705 & (64));
var inst_51707 = inst_51700.cljs$core$ISeq$;
var inst_51708 = (cljs.core.PROTOCOL_SENTINEL === inst_51707);
var inst_51709 = ((inst_51706) || (inst_51708));
var state_51798__$1 = state_51798;
if(cljs.core.truth_(inst_51709)){
var statearr_51833_53060 = state_51798__$1;
(statearr_51833_53060[(1)] = (5));

} else {
var statearr_51834_53061 = state_51798__$1;
(statearr_51834_53061[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (23))){
var inst_51757 = (state_51798[(14)]);
var inst_51763 = (inst_51757 == null);
var state_51798__$1 = state_51798;
if(cljs.core.truth_(inst_51763)){
var statearr_51835_53062 = state_51798__$1;
(statearr_51835_53062[(1)] = (26));

} else {
var statearr_51836_53063 = state_51798__$1;
(statearr_51836_53063[(1)] = (27));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (35))){
var inst_51783 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
if(cljs.core.truth_(inst_51783)){
var statearr_51837_53065 = state_51798__$1;
(statearr_51837_53065[(1)] = (36));

} else {
var statearr_51838_53066 = state_51798__$1;
(statearr_51838_53066[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (19))){
var inst_51725 = (state_51798[(7)]);
var inst_51745 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_51725);
var state_51798__$1 = state_51798;
var statearr_51839_53067 = state_51798__$1;
(statearr_51839_53067[(2)] = inst_51745);

(statearr_51839_53067[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (11))){
var inst_51725 = (state_51798[(7)]);
var inst_51729 = (inst_51725 == null);
var inst_51730 = cljs.core.not(inst_51729);
var state_51798__$1 = state_51798;
if(inst_51730){
var statearr_51840_53068 = state_51798__$1;
(statearr_51840_53068[(1)] = (13));

} else {
var statearr_51841_53069 = state_51798__$1;
(statearr_51841_53069[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (9))){
var inst_51700 = (state_51798[(8)]);
var state_51798__$1 = state_51798;
var statearr_51842_53070 = state_51798__$1;
(statearr_51842_53070[(2)] = inst_51700);

(statearr_51842_53070[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (5))){
var state_51798__$1 = state_51798;
var statearr_51843_53071 = state_51798__$1;
(statearr_51843_53071[(2)] = true);

(statearr_51843_53071[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (14))){
var state_51798__$1 = state_51798;
var statearr_51844_53072 = state_51798__$1;
(statearr_51844_53072[(2)] = false);

(statearr_51844_53072[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (26))){
var inst_51758 = (state_51798[(9)]);
var inst_51765 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_51758);
var state_51798__$1 = state_51798;
var statearr_51845_53078 = state_51798__$1;
(statearr_51845_53078[(2)] = inst_51765);

(statearr_51845_53078[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (16))){
var state_51798__$1 = state_51798;
var statearr_51846_53081 = state_51798__$1;
(statearr_51846_53081[(2)] = true);

(statearr_51846_53081[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (38))){
var inst_51788 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
var statearr_51847_53082 = state_51798__$1;
(statearr_51847_53082[(2)] = inst_51788);

(statearr_51847_53082[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (30))){
var inst_51750 = (state_51798[(13)]);
var inst_51758 = (state_51798[(9)]);
var inst_51749 = (state_51798[(10)]);
var inst_51775 = cljs.core.empty_QMARK_(inst_51749);
var inst_51776 = (inst_51750.cljs$core$IFn$_invoke$arity$1 ? inst_51750.cljs$core$IFn$_invoke$arity$1(inst_51758) : inst_51750.call(null,inst_51758));
var inst_51777 = cljs.core.not(inst_51776);
var inst_51778 = ((inst_51775) && (inst_51777));
var state_51798__$1 = state_51798;
var statearr_51848_53083 = state_51798__$1;
(statearr_51848_53083[(2)] = inst_51778);

(statearr_51848_53083[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (10))){
var inst_51700 = (state_51798[(8)]);
var inst_51721 = (state_51798[(2)]);
var inst_51722 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_51721,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_51723 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_51721,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_51724 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_51721,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var inst_51725 = inst_51700;
var state_51798__$1 = (function (){var statearr_51849 = state_51798;
(statearr_51849[(7)] = inst_51725);

(statearr_51849[(16)] = inst_51723);

(statearr_51849[(17)] = inst_51722);

(statearr_51849[(18)] = inst_51724);

return statearr_51849;
})();
var statearr_51850_53084 = state_51798__$1;
(statearr_51850_53084[(2)] = null);

(statearr_51850_53084[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (18))){
var inst_51740 = (state_51798[(2)]);
var state_51798__$1 = state_51798;
var statearr_51851_53085 = state_51798__$1;
(statearr_51851_53085[(2)] = inst_51740);

(statearr_51851_53085[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (37))){
var state_51798__$1 = state_51798;
var statearr_51852_53086 = state_51798__$1;
(statearr_51852_53086[(2)] = null);

(statearr_51852_53086[(1)] = (38));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51799 === (8))){
var inst_51700 = (state_51798[(8)]);
var inst_51718 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_51700);
var state_51798__$1 = state_51798;
var statearr_51853_53088 = state_51798__$1;
(statearr_51853_53088[(2)] = inst_51718);

(statearr_51853_53088[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53019,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__50901__auto__,c__51002__auto___53019,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__50902__auto__ = null;
var cljs$core$async$mix_$_state_machine__50902__auto____0 = (function (){
var statearr_51854 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_51854[(0)] = cljs$core$async$mix_$_state_machine__50902__auto__);

(statearr_51854[(1)] = (1));

return statearr_51854;
});
var cljs$core$async$mix_$_state_machine__50902__auto____1 = (function (state_51798){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51798);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51855){if((e51855 instanceof Object)){
var ex__50905__auto__ = e51855;
var statearr_51856_53089 = state_51798;
(statearr_51856_53089[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51798);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51855;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53091 = state_51798;
state_51798 = G__53091;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__50902__auto__ = function(state_51798){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__50902__auto____1.call(this,state_51798);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__50902__auto____0;
cljs$core$async$mix_$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__50902__auto____1;
return cljs$core$async$mix_$_state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53019,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__51004__auto__ = (function (){var statearr_51857 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51857[(6)] = c__51002__auto___53019);

return statearr_51857;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53019,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4434__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__4431__auto__ = (cljs.core.async.sub_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4431__auto__.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4434__auto__.call(null,p,v,ch));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4431__auto__.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__51859 = arguments.length;
switch (G__51859) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4434__auto__.call(null,p));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4431__auto__.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4434__auto__.call(null,p,v));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4431__auto__.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__51862 = arguments.length;
switch (G__51862) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__4131__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(mults),topic);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,((function (or__4131__auto__,mults){
return (function (p1__51860_SHARP_){
if(cljs.core.truth_((p1__51860_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__51860_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__51860_SHARP_.call(null,topic)))){
return p1__51860_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__51860_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
});})(or__4131__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async51863 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async51863 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta51864){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta51864 = meta51864;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_51865,meta51864__$1){
var self__ = this;
var _51865__$1 = this;
return (new cljs.core.async.t_cljs$core$async51863(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta51864__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_51865){
var self__ = this;
var _51865__$1 = this;
return self__.meta51864;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5735__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(self__.mults),topic);
if(cljs.core.truth_(temp__5735__auto__)){
var m = temp__5735__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_(self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async51863.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async51863.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"topic-fn","topic-fn",-862449736,null),new cljs.core.Symbol(null,"buf-fn","buf-fn",-1200281591,null),new cljs.core.Symbol(null,"mults","mults",-461114485,null),new cljs.core.Symbol(null,"ensure-mult","ensure-mult",1796584816,null),new cljs.core.Symbol(null,"meta51864","meta51864",1553979364,null)], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async51863.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async51863.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async51863";

cljs.core.async.t_cljs$core$async51863.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async51863");
});})(mults,ensure_mult))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async51863.
 */
cljs.core.async.__GT_t_cljs$core$async51863 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async51863(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta51864){
return (new cljs.core.async.t_cljs$core$async51863(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta51864));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async51863(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__51002__auto___53108 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53108,mults,ensure_mult,p){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53108,mults,ensure_mult,p){
return (function (state_51937){
var state_val_51938 = (state_51937[(1)]);
if((state_val_51938 === (7))){
var inst_51933 = (state_51937[(2)]);
var state_51937__$1 = state_51937;
var statearr_51939_53109 = state_51937__$1;
(statearr_51939_53109[(2)] = inst_51933);

(statearr_51939_53109[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (20))){
var state_51937__$1 = state_51937;
var statearr_51940_53110 = state_51937__$1;
(statearr_51940_53110[(2)] = null);

(statearr_51940_53110[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (1))){
var state_51937__$1 = state_51937;
var statearr_51941_53111 = state_51937__$1;
(statearr_51941_53111[(2)] = null);

(statearr_51941_53111[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (24))){
var inst_51916 = (state_51937[(7)]);
var inst_51925 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_51916);
var state_51937__$1 = state_51937;
var statearr_51942_53113 = state_51937__$1;
(statearr_51942_53113[(2)] = inst_51925);

(statearr_51942_53113[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (4))){
var inst_51868 = (state_51937[(8)]);
var inst_51868__$1 = (state_51937[(2)]);
var inst_51869 = (inst_51868__$1 == null);
var state_51937__$1 = (function (){var statearr_51943 = state_51937;
(statearr_51943[(8)] = inst_51868__$1);

return statearr_51943;
})();
if(cljs.core.truth_(inst_51869)){
var statearr_51944_53114 = state_51937__$1;
(statearr_51944_53114[(1)] = (5));

} else {
var statearr_51945_53115 = state_51937__$1;
(statearr_51945_53115[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (15))){
var inst_51910 = (state_51937[(2)]);
var state_51937__$1 = state_51937;
var statearr_51946_53116 = state_51937__$1;
(statearr_51946_53116[(2)] = inst_51910);

(statearr_51946_53116[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (21))){
var inst_51930 = (state_51937[(2)]);
var state_51937__$1 = (function (){var statearr_51947 = state_51937;
(statearr_51947[(9)] = inst_51930);

return statearr_51947;
})();
var statearr_51948_53117 = state_51937__$1;
(statearr_51948_53117[(2)] = null);

(statearr_51948_53117[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (13))){
var inst_51892 = (state_51937[(10)]);
var inst_51894 = cljs.core.chunked_seq_QMARK_(inst_51892);
var state_51937__$1 = state_51937;
if(inst_51894){
var statearr_51949_53119 = state_51937__$1;
(statearr_51949_53119[(1)] = (16));

} else {
var statearr_51950_53120 = state_51937__$1;
(statearr_51950_53120[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (22))){
var inst_51922 = (state_51937[(2)]);
var state_51937__$1 = state_51937;
if(cljs.core.truth_(inst_51922)){
var statearr_51951_53121 = state_51937__$1;
(statearr_51951_53121[(1)] = (23));

} else {
var statearr_51952_53123 = state_51937__$1;
(statearr_51952_53123[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (6))){
var inst_51868 = (state_51937[(8)]);
var inst_51916 = (state_51937[(7)]);
var inst_51918 = (state_51937[(11)]);
var inst_51916__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_51868) : topic_fn.call(null,inst_51868));
var inst_51917 = cljs.core.deref(mults);
var inst_51918__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_51917,inst_51916__$1);
var state_51937__$1 = (function (){var statearr_51953 = state_51937;
(statearr_51953[(7)] = inst_51916__$1);

(statearr_51953[(11)] = inst_51918__$1);

return statearr_51953;
})();
if(cljs.core.truth_(inst_51918__$1)){
var statearr_51954_53124 = state_51937__$1;
(statearr_51954_53124[(1)] = (19));

} else {
var statearr_51955_53125 = state_51937__$1;
(statearr_51955_53125[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (25))){
var inst_51927 = (state_51937[(2)]);
var state_51937__$1 = state_51937;
var statearr_51956_53129 = state_51937__$1;
(statearr_51956_53129[(2)] = inst_51927);

(statearr_51956_53129[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (17))){
var inst_51892 = (state_51937[(10)]);
var inst_51901 = cljs.core.first(inst_51892);
var inst_51902 = cljs.core.async.muxch_STAR_(inst_51901);
var inst_51903 = cljs.core.async.close_BANG_(inst_51902);
var inst_51904 = cljs.core.next(inst_51892);
var inst_51878 = inst_51904;
var inst_51879 = null;
var inst_51880 = (0);
var inst_51881 = (0);
var state_51937__$1 = (function (){var statearr_51957 = state_51937;
(statearr_51957[(12)] = inst_51880);

(statearr_51957[(13)] = inst_51878);

(statearr_51957[(14)] = inst_51879);

(statearr_51957[(15)] = inst_51903);

(statearr_51957[(16)] = inst_51881);

return statearr_51957;
})();
var statearr_51958_53137 = state_51937__$1;
(statearr_51958_53137[(2)] = null);

(statearr_51958_53137[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (3))){
var inst_51935 = (state_51937[(2)]);
var state_51937__$1 = state_51937;
return cljs.core.async.impl.ioc_helpers.return_chan(state_51937__$1,inst_51935);
} else {
if((state_val_51938 === (12))){
var inst_51912 = (state_51937[(2)]);
var state_51937__$1 = state_51937;
var statearr_51959_53138 = state_51937__$1;
(statearr_51959_53138[(2)] = inst_51912);

(statearr_51959_53138[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (2))){
var state_51937__$1 = state_51937;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_51937__$1,(4),ch);
} else {
if((state_val_51938 === (23))){
var state_51937__$1 = state_51937;
var statearr_51960_53139 = state_51937__$1;
(statearr_51960_53139[(2)] = null);

(statearr_51960_53139[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (19))){
var inst_51868 = (state_51937[(8)]);
var inst_51918 = (state_51937[(11)]);
var inst_51920 = cljs.core.async.muxch_STAR_(inst_51918);
var state_51937__$1 = state_51937;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_51937__$1,(22),inst_51920,inst_51868);
} else {
if((state_val_51938 === (11))){
var inst_51878 = (state_51937[(13)]);
var inst_51892 = (state_51937[(10)]);
var inst_51892__$1 = cljs.core.seq(inst_51878);
var state_51937__$1 = (function (){var statearr_51961 = state_51937;
(statearr_51961[(10)] = inst_51892__$1);

return statearr_51961;
})();
if(inst_51892__$1){
var statearr_51962_53143 = state_51937__$1;
(statearr_51962_53143[(1)] = (13));

} else {
var statearr_51963_53147 = state_51937__$1;
(statearr_51963_53147[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (9))){
var inst_51914 = (state_51937[(2)]);
var state_51937__$1 = state_51937;
var statearr_51964_53148 = state_51937__$1;
(statearr_51964_53148[(2)] = inst_51914);

(statearr_51964_53148[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (5))){
var inst_51875 = cljs.core.deref(mults);
var inst_51876 = cljs.core.vals(inst_51875);
var inst_51877 = cljs.core.seq(inst_51876);
var inst_51878 = inst_51877;
var inst_51879 = null;
var inst_51880 = (0);
var inst_51881 = (0);
var state_51937__$1 = (function (){var statearr_51965 = state_51937;
(statearr_51965[(12)] = inst_51880);

(statearr_51965[(13)] = inst_51878);

(statearr_51965[(14)] = inst_51879);

(statearr_51965[(16)] = inst_51881);

return statearr_51965;
})();
var statearr_51966_53149 = state_51937__$1;
(statearr_51966_53149[(2)] = null);

(statearr_51966_53149[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (14))){
var state_51937__$1 = state_51937;
var statearr_51970_53153 = state_51937__$1;
(statearr_51970_53153[(2)] = null);

(statearr_51970_53153[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (16))){
var inst_51892 = (state_51937[(10)]);
var inst_51896 = cljs.core.chunk_first(inst_51892);
var inst_51897 = cljs.core.chunk_rest(inst_51892);
var inst_51898 = cljs.core.count(inst_51896);
var inst_51878 = inst_51897;
var inst_51879 = inst_51896;
var inst_51880 = inst_51898;
var inst_51881 = (0);
var state_51937__$1 = (function (){var statearr_51971 = state_51937;
(statearr_51971[(12)] = inst_51880);

(statearr_51971[(13)] = inst_51878);

(statearr_51971[(14)] = inst_51879);

(statearr_51971[(16)] = inst_51881);

return statearr_51971;
})();
var statearr_51972_53154 = state_51937__$1;
(statearr_51972_53154[(2)] = null);

(statearr_51972_53154[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (10))){
var inst_51880 = (state_51937[(12)]);
var inst_51878 = (state_51937[(13)]);
var inst_51879 = (state_51937[(14)]);
var inst_51881 = (state_51937[(16)]);
var inst_51886 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_51879,inst_51881);
var inst_51887 = cljs.core.async.muxch_STAR_(inst_51886);
var inst_51888 = cljs.core.async.close_BANG_(inst_51887);
var inst_51889 = (inst_51881 + (1));
var tmp51967 = inst_51880;
var tmp51968 = inst_51878;
var tmp51969 = inst_51879;
var inst_51878__$1 = tmp51968;
var inst_51879__$1 = tmp51969;
var inst_51880__$1 = tmp51967;
var inst_51881__$1 = inst_51889;
var state_51937__$1 = (function (){var statearr_51973 = state_51937;
(statearr_51973[(17)] = inst_51888);

(statearr_51973[(12)] = inst_51880__$1);

(statearr_51973[(13)] = inst_51878__$1);

(statearr_51973[(14)] = inst_51879__$1);

(statearr_51973[(16)] = inst_51881__$1);

return statearr_51973;
})();
var statearr_51974_53165 = state_51937__$1;
(statearr_51974_53165[(2)] = null);

(statearr_51974_53165[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (18))){
var inst_51907 = (state_51937[(2)]);
var state_51937__$1 = state_51937;
var statearr_51975_53172 = state_51937__$1;
(statearr_51975_53172[(2)] = inst_51907);

(statearr_51975_53172[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_51938 === (8))){
var inst_51880 = (state_51937[(12)]);
var inst_51881 = (state_51937[(16)]);
var inst_51883 = (inst_51881 < inst_51880);
var inst_51884 = inst_51883;
var state_51937__$1 = state_51937;
if(cljs.core.truth_(inst_51884)){
var statearr_51976_53173 = state_51937__$1;
(statearr_51976_53173[(1)] = (10));

} else {
var statearr_51977_53174 = state_51937__$1;
(statearr_51977_53174[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53108,mults,ensure_mult,p))
;
return ((function (switch__50901__auto__,c__51002__auto___53108,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_51978 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_51978[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_51978[(1)] = (1));

return statearr_51978;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_51937){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_51937);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e51979){if((e51979 instanceof Object)){
var ex__50905__auto__ = e51979;
var statearr_51980_53175 = state_51937;
(statearr_51980_53175[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_51937);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e51979;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53176 = state_51937;
state_51937 = G__53176;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_51937){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_51937);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53108,mults,ensure_mult,p))
})();
var state__51004__auto__ = (function (){var statearr_51981 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_51981[(6)] = c__51002__auto___53108);

return statearr_51981;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53108,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__51983 = arguments.length;
switch (G__51983) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__51985 = arguments.length;
switch (G__51985) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__51987 = arguments.length;
switch (G__51987) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2(((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__51002__auto___53192 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53192,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53192,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_52026){
var state_val_52027 = (state_52026[(1)]);
if((state_val_52027 === (7))){
var state_52026__$1 = state_52026;
var statearr_52028_53193 = state_52026__$1;
(statearr_52028_53193[(2)] = null);

(statearr_52028_53193[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (1))){
var state_52026__$1 = state_52026;
var statearr_52029_53194 = state_52026__$1;
(statearr_52029_53194[(2)] = null);

(statearr_52029_53194[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (4))){
var inst_51990 = (state_52026[(7)]);
var inst_51992 = (inst_51990 < cnt);
var state_52026__$1 = state_52026;
if(cljs.core.truth_(inst_51992)){
var statearr_52030_53195 = state_52026__$1;
(statearr_52030_53195[(1)] = (6));

} else {
var statearr_52031_53196 = state_52026__$1;
(statearr_52031_53196[(1)] = (7));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (15))){
var inst_52022 = (state_52026[(2)]);
var state_52026__$1 = state_52026;
var statearr_52032_53197 = state_52026__$1;
(statearr_52032_53197[(2)] = inst_52022);

(statearr_52032_53197[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (13))){
var inst_52015 = cljs.core.async.close_BANG_(out);
var state_52026__$1 = state_52026;
var statearr_52033_53198 = state_52026__$1;
(statearr_52033_53198[(2)] = inst_52015);

(statearr_52033_53198[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (6))){
var state_52026__$1 = state_52026;
var statearr_52034_53199 = state_52026__$1;
(statearr_52034_53199[(2)] = null);

(statearr_52034_53199[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (3))){
var inst_52024 = (state_52026[(2)]);
var state_52026__$1 = state_52026;
return cljs.core.async.impl.ioc_helpers.return_chan(state_52026__$1,inst_52024);
} else {
if((state_val_52027 === (12))){
var inst_52012 = (state_52026[(8)]);
var inst_52012__$1 = (state_52026[(2)]);
var inst_52013 = cljs.core.some(cljs.core.nil_QMARK_,inst_52012__$1);
var state_52026__$1 = (function (){var statearr_52035 = state_52026;
(statearr_52035[(8)] = inst_52012__$1);

return statearr_52035;
})();
if(cljs.core.truth_(inst_52013)){
var statearr_52036_53200 = state_52026__$1;
(statearr_52036_53200[(1)] = (13));

} else {
var statearr_52037_53201 = state_52026__$1;
(statearr_52037_53201[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (2))){
var inst_51989 = cljs.core.reset_BANG_(dctr,cnt);
var inst_51990 = (0);
var state_52026__$1 = (function (){var statearr_52038 = state_52026;
(statearr_52038[(7)] = inst_51990);

(statearr_52038[(9)] = inst_51989);

return statearr_52038;
})();
var statearr_52039_53208 = state_52026__$1;
(statearr_52039_53208[(2)] = null);

(statearr_52039_53208[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (11))){
var inst_51990 = (state_52026[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_52026,(10),Object,null,(9));
var inst_51999 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_51990) : chs__$1.call(null,inst_51990));
var inst_52000 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_51990) : done.call(null,inst_51990));
var inst_52001 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_51999,inst_52000);
var state_52026__$1 = state_52026;
var statearr_52040_53209 = state_52026__$1;
(statearr_52040_53209[(2)] = inst_52001);


cljs.core.async.impl.ioc_helpers.process_exception(state_52026__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (9))){
var inst_51990 = (state_52026[(7)]);
var inst_52003 = (state_52026[(2)]);
var inst_52004 = (inst_51990 + (1));
var inst_51990__$1 = inst_52004;
var state_52026__$1 = (function (){var statearr_52041 = state_52026;
(statearr_52041[(7)] = inst_51990__$1);

(statearr_52041[(10)] = inst_52003);

return statearr_52041;
})();
var statearr_52042_53210 = state_52026__$1;
(statearr_52042_53210[(2)] = null);

(statearr_52042_53210[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (5))){
var inst_52010 = (state_52026[(2)]);
var state_52026__$1 = (function (){var statearr_52043 = state_52026;
(statearr_52043[(11)] = inst_52010);

return statearr_52043;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_52026__$1,(12),dchan);
} else {
if((state_val_52027 === (14))){
var inst_52012 = (state_52026[(8)]);
var inst_52017 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_52012);
var state_52026__$1 = state_52026;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52026__$1,(16),out,inst_52017);
} else {
if((state_val_52027 === (16))){
var inst_52019 = (state_52026[(2)]);
var state_52026__$1 = (function (){var statearr_52044 = state_52026;
(statearr_52044[(12)] = inst_52019);

return statearr_52044;
})();
var statearr_52045_53211 = state_52026__$1;
(statearr_52045_53211[(2)] = null);

(statearr_52045_53211[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (10))){
var inst_51994 = (state_52026[(2)]);
var inst_51995 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_52026__$1 = (function (){var statearr_52046 = state_52026;
(statearr_52046[(13)] = inst_51994);

return statearr_52046;
})();
var statearr_52047_53215 = state_52026__$1;
(statearr_52047_53215[(2)] = inst_51995);


cljs.core.async.impl.ioc_helpers.process_exception(state_52026__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52027 === (8))){
var inst_52008 = (state_52026[(2)]);
var state_52026__$1 = state_52026;
var statearr_52048_53216 = state_52026__$1;
(statearr_52048_53216[(2)] = inst_52008);

(statearr_52048_53216[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53192,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__50901__auto__,c__51002__auto___53192,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_52049 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_52049[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_52049[(1)] = (1));

return statearr_52049;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_52026){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_52026);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e52050){if((e52050 instanceof Object)){
var ex__50905__auto__ = e52050;
var statearr_52051_53220 = state_52026;
(statearr_52051_53220[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_52026);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52050;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53221 = state_52026;
state_52026 = G__53221;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_52026){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_52026);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53192,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__51004__auto__ = (function (){var statearr_52052 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_52052[(6)] = c__51002__auto___53192);

return statearr_52052;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53192,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__52055 = arguments.length;
switch (G__52055) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__51002__auto___53225 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53225,out){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53225,out){
return (function (state_52087){
var state_val_52088 = (state_52087[(1)]);
if((state_val_52088 === (7))){
var inst_52067 = (state_52087[(7)]);
var inst_52066 = (state_52087[(8)]);
var inst_52066__$1 = (state_52087[(2)]);
var inst_52067__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_52066__$1,(0),null);
var inst_52068 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_52066__$1,(1),null);
var inst_52069 = (inst_52067__$1 == null);
var state_52087__$1 = (function (){var statearr_52089 = state_52087;
(statearr_52089[(9)] = inst_52068);

(statearr_52089[(7)] = inst_52067__$1);

(statearr_52089[(8)] = inst_52066__$1);

return statearr_52089;
})();
if(cljs.core.truth_(inst_52069)){
var statearr_52090_53226 = state_52087__$1;
(statearr_52090_53226[(1)] = (8));

} else {
var statearr_52091_53227 = state_52087__$1;
(statearr_52091_53227[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52088 === (1))){
var inst_52056 = cljs.core.vec(chs);
var inst_52057 = inst_52056;
var state_52087__$1 = (function (){var statearr_52092 = state_52087;
(statearr_52092[(10)] = inst_52057);

return statearr_52092;
})();
var statearr_52093_53230 = state_52087__$1;
(statearr_52093_53230[(2)] = null);

(statearr_52093_53230[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52088 === (4))){
var inst_52057 = (state_52087[(10)]);
var state_52087__$1 = state_52087;
return cljs.core.async.ioc_alts_BANG_(state_52087__$1,(7),inst_52057);
} else {
if((state_val_52088 === (6))){
var inst_52083 = (state_52087[(2)]);
var state_52087__$1 = state_52087;
var statearr_52094_53231 = state_52087__$1;
(statearr_52094_53231[(2)] = inst_52083);

(statearr_52094_53231[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52088 === (3))){
var inst_52085 = (state_52087[(2)]);
var state_52087__$1 = state_52087;
return cljs.core.async.impl.ioc_helpers.return_chan(state_52087__$1,inst_52085);
} else {
if((state_val_52088 === (2))){
var inst_52057 = (state_52087[(10)]);
var inst_52059 = cljs.core.count(inst_52057);
var inst_52060 = (inst_52059 > (0));
var state_52087__$1 = state_52087;
if(cljs.core.truth_(inst_52060)){
var statearr_52096_53232 = state_52087__$1;
(statearr_52096_53232[(1)] = (4));

} else {
var statearr_52097_53233 = state_52087__$1;
(statearr_52097_53233[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52088 === (11))){
var inst_52057 = (state_52087[(10)]);
var inst_52076 = (state_52087[(2)]);
var tmp52095 = inst_52057;
var inst_52057__$1 = tmp52095;
var state_52087__$1 = (function (){var statearr_52098 = state_52087;
(statearr_52098[(10)] = inst_52057__$1);

(statearr_52098[(11)] = inst_52076);

return statearr_52098;
})();
var statearr_52099_53234 = state_52087__$1;
(statearr_52099_53234[(2)] = null);

(statearr_52099_53234[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52088 === (9))){
var inst_52067 = (state_52087[(7)]);
var state_52087__$1 = state_52087;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52087__$1,(11),out,inst_52067);
} else {
if((state_val_52088 === (5))){
var inst_52081 = cljs.core.async.close_BANG_(out);
var state_52087__$1 = state_52087;
var statearr_52100_53243 = state_52087__$1;
(statearr_52100_53243[(2)] = inst_52081);

(statearr_52100_53243[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52088 === (10))){
var inst_52079 = (state_52087[(2)]);
var state_52087__$1 = state_52087;
var statearr_52101_53245 = state_52087__$1;
(statearr_52101_53245[(2)] = inst_52079);

(statearr_52101_53245[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52088 === (8))){
var inst_52068 = (state_52087[(9)]);
var inst_52057 = (state_52087[(10)]);
var inst_52067 = (state_52087[(7)]);
var inst_52066 = (state_52087[(8)]);
var inst_52071 = (function (){var cs = inst_52057;
var vec__52062 = inst_52066;
var v = inst_52067;
var c = inst_52068;
return ((function (cs,vec__52062,v,c,inst_52068,inst_52057,inst_52067,inst_52066,state_val_52088,c__51002__auto___53225,out){
return (function (p1__52053_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__52053_SHARP_);
});
;})(cs,vec__52062,v,c,inst_52068,inst_52057,inst_52067,inst_52066,state_val_52088,c__51002__auto___53225,out))
})();
var inst_52072 = cljs.core.filterv(inst_52071,inst_52057);
var inst_52057__$1 = inst_52072;
var state_52087__$1 = (function (){var statearr_52102 = state_52087;
(statearr_52102[(10)] = inst_52057__$1);

return statearr_52102;
})();
var statearr_52103_53248 = state_52087__$1;
(statearr_52103_53248[(2)] = null);

(statearr_52103_53248[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53225,out))
;
return ((function (switch__50901__auto__,c__51002__auto___53225,out){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_52104 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_52104[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_52104[(1)] = (1));

return statearr_52104;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_52087){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_52087);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e52105){if((e52105 instanceof Object)){
var ex__50905__auto__ = e52105;
var statearr_52106_53252 = state_52087;
(statearr_52106_53252[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_52087);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52105;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53253 = state_52087;
state_52087 = G__53253;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_52087){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_52087);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53225,out))
})();
var state__51004__auto__ = (function (){var statearr_52107 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_52107[(6)] = c__51002__auto___53225);

return statearr_52107;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53225,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__52109 = arguments.length;
switch (G__52109) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__51002__auto___53255 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53255,out){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53255,out){
return (function (state_52133){
var state_val_52134 = (state_52133[(1)]);
if((state_val_52134 === (7))){
var inst_52115 = (state_52133[(7)]);
var inst_52115__$1 = (state_52133[(2)]);
var inst_52116 = (inst_52115__$1 == null);
var inst_52117 = cljs.core.not(inst_52116);
var state_52133__$1 = (function (){var statearr_52135 = state_52133;
(statearr_52135[(7)] = inst_52115__$1);

return statearr_52135;
})();
if(inst_52117){
var statearr_52136_53256 = state_52133__$1;
(statearr_52136_53256[(1)] = (8));

} else {
var statearr_52137_53257 = state_52133__$1;
(statearr_52137_53257[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52134 === (1))){
var inst_52110 = (0);
var state_52133__$1 = (function (){var statearr_52138 = state_52133;
(statearr_52138[(8)] = inst_52110);

return statearr_52138;
})();
var statearr_52139_53258 = state_52133__$1;
(statearr_52139_53258[(2)] = null);

(statearr_52139_53258[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52134 === (4))){
var state_52133__$1 = state_52133;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_52133__$1,(7),ch);
} else {
if((state_val_52134 === (6))){
var inst_52128 = (state_52133[(2)]);
var state_52133__$1 = state_52133;
var statearr_52140_53259 = state_52133__$1;
(statearr_52140_53259[(2)] = inst_52128);

(statearr_52140_53259[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52134 === (3))){
var inst_52130 = (state_52133[(2)]);
var inst_52131 = cljs.core.async.close_BANG_(out);
var state_52133__$1 = (function (){var statearr_52141 = state_52133;
(statearr_52141[(9)] = inst_52130);

return statearr_52141;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_52133__$1,inst_52131);
} else {
if((state_val_52134 === (2))){
var inst_52110 = (state_52133[(8)]);
var inst_52112 = (inst_52110 < n);
var state_52133__$1 = state_52133;
if(cljs.core.truth_(inst_52112)){
var statearr_52142_53260 = state_52133__$1;
(statearr_52142_53260[(1)] = (4));

} else {
var statearr_52143_53261 = state_52133__$1;
(statearr_52143_53261[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52134 === (11))){
var inst_52110 = (state_52133[(8)]);
var inst_52120 = (state_52133[(2)]);
var inst_52121 = (inst_52110 + (1));
var inst_52110__$1 = inst_52121;
var state_52133__$1 = (function (){var statearr_52144 = state_52133;
(statearr_52144[(8)] = inst_52110__$1);

(statearr_52144[(10)] = inst_52120);

return statearr_52144;
})();
var statearr_52145_53262 = state_52133__$1;
(statearr_52145_53262[(2)] = null);

(statearr_52145_53262[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52134 === (9))){
var state_52133__$1 = state_52133;
var statearr_52146_53263 = state_52133__$1;
(statearr_52146_53263[(2)] = null);

(statearr_52146_53263[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52134 === (5))){
var state_52133__$1 = state_52133;
var statearr_52147_53265 = state_52133__$1;
(statearr_52147_53265[(2)] = null);

(statearr_52147_53265[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52134 === (10))){
var inst_52125 = (state_52133[(2)]);
var state_52133__$1 = state_52133;
var statearr_52148_53267 = state_52133__$1;
(statearr_52148_53267[(2)] = inst_52125);

(statearr_52148_53267[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52134 === (8))){
var inst_52115 = (state_52133[(7)]);
var state_52133__$1 = state_52133;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52133__$1,(11),out,inst_52115);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53255,out))
;
return ((function (switch__50901__auto__,c__51002__auto___53255,out){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_52149 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_52149[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_52149[(1)] = (1));

return statearr_52149;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_52133){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_52133);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e52150){if((e52150 instanceof Object)){
var ex__50905__auto__ = e52150;
var statearr_52151_53270 = state_52133;
(statearr_52151_53270[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_52133);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52150;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53272 = state_52133;
state_52133 = G__53272;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_52133){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_52133);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53255,out))
})();
var state__51004__auto__ = (function (){var statearr_52152 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_52152[(6)] = c__51002__auto___53255);

return statearr_52152;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53255,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async52154 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async52154 = (function (f,ch,meta52155){
this.f = f;
this.ch = ch;
this.meta52155 = meta52155;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_52156,meta52155__$1){
var self__ = this;
var _52156__$1 = this;
return (new cljs.core.async.t_cljs$core$async52154(self__.f,self__.ch,meta52155__$1));
});

cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_52156){
var self__ = this;
var _52156__$1 = this;
return self__.meta52155;
});

cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async52157 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async52157 = (function (f,ch,meta52155,_,fn1,meta52158){
this.f = f;
this.ch = ch;
this.meta52155 = meta52155;
this._ = _;
this.fn1 = fn1;
this.meta52158 = meta52158;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async52157.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_52159,meta52158__$1){
var self__ = this;
var _52159__$1 = this;
return (new cljs.core.async.t_cljs$core$async52157(self__.f,self__.ch,self__.meta52155,self__._,self__.fn1,meta52158__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async52157.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_52159){
var self__ = this;
var _52159__$1 = this;
return self__.meta52158;
});})(___$1))
;

cljs.core.async.t_cljs$core$async52157.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52157.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async52157.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async52157.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__52153_SHARP_){
var G__52160 = (((p1__52153_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__52153_SHARP_) : self__.f.call(null,p1__52153_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__52160) : f1.call(null,G__52160));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async52157.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta52155","meta52155",998432677,null),cljs.core.with_meta(new cljs.core.Symbol(null,"_","_",-1201019570,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core.async","t_cljs$core$async52154","cljs.core.async/t_cljs$core$async52154",-958856962,null)], null)),new cljs.core.Symbol(null,"fn1","fn1",895834444,null),new cljs.core.Symbol(null,"meta52158","meta52158",1584344087,null)], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async52157.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async52157.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async52157";

cljs.core.async.t_cljs$core$async52157.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async52157");
});})(___$1))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async52157.
 */
cljs.core.async.__GT_t_cljs$core$async52157 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async52157(f__$1,ch__$1,meta52155__$1,___$2,fn1__$1,meta52158){
return (new cljs.core.async.t_cljs$core$async52157(f__$1,ch__$1,meta52155__$1,___$2,fn1__$1,meta52158));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async52157(self__.f,self__.ch,self__.meta52155,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__4120__auto__ = ret;
if(cljs.core.truth_(and__4120__auto__)){
return (!((cljs.core.deref(ret) == null)));
} else {
return and__4120__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__52161 = cljs.core.deref(ret);
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__52161) : self__.f.call(null,G__52161));
})());
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52154.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async52154.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta52155","meta52155",998432677,null)], null);
});

cljs.core.async.t_cljs$core$async52154.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async52154.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async52154";

cljs.core.async.t_cljs$core$async52154.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async52154");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async52154.
 */
cljs.core.async.__GT_t_cljs$core$async52154 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async52154(f__$1,ch__$1,meta52155){
return (new cljs.core.async.t_cljs$core$async52154(f__$1,ch__$1,meta52155));
});

}

return (new cljs.core.async.t_cljs$core$async52154(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async52162 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async52162 = (function (f,ch,meta52163){
this.f = f;
this.ch = ch;
this.meta52163 = meta52163;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async52162.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_52164,meta52163__$1){
var self__ = this;
var _52164__$1 = this;
return (new cljs.core.async.t_cljs$core$async52162(self__.f,self__.ch,meta52163__$1));
});

cljs.core.async.t_cljs$core$async52162.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_52164){
var self__ = this;
var _52164__$1 = this;
return self__.meta52163;
});

cljs.core.async.t_cljs$core$async52162.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52162.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async52162.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52162.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async52162.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52162.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
});

cljs.core.async.t_cljs$core$async52162.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta52163","meta52163",933862317,null)], null);
});

cljs.core.async.t_cljs$core$async52162.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async52162.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async52162";

cljs.core.async.t_cljs$core$async52162.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async52162");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async52162.
 */
cljs.core.async.__GT_t_cljs$core$async52162 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async52162(f__$1,ch__$1,meta52163){
return (new cljs.core.async.t_cljs$core$async52162(f__$1,ch__$1,meta52163));
});

}

return (new cljs.core.async.t_cljs$core$async52162(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async52165 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async52165 = (function (p,ch,meta52166){
this.p = p;
this.ch = ch;
this.meta52166 = meta52166;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_52167,meta52166__$1){
var self__ = this;
var _52167__$1 = this;
return (new cljs.core.async.t_cljs$core$async52165(self__.p,self__.ch,meta52166__$1));
});

cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_52167){
var self__ = this;
var _52167__$1 = this;
return self__.meta52166;
});

cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async52165.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
});

cljs.core.async.t_cljs$core$async52165.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"p","p",1791580836,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta52166","meta52166",-808419972,null)], null);
});

cljs.core.async.t_cljs$core$async52165.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async52165.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async52165";

cljs.core.async.t_cljs$core$async52165.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async52165");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async52165.
 */
cljs.core.async.__GT_t_cljs$core$async52165 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async52165(p__$1,ch__$1,meta52166){
return (new cljs.core.async.t_cljs$core$async52165(p__$1,ch__$1,meta52166));
});

}

return (new cljs.core.async.t_cljs$core$async52165(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__52169 = arguments.length;
switch (G__52169) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__51002__auto___53337 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53337,out){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53337,out){
return (function (state_52190){
var state_val_52191 = (state_52190[(1)]);
if((state_val_52191 === (7))){
var inst_52186 = (state_52190[(2)]);
var state_52190__$1 = state_52190;
var statearr_52192_53338 = state_52190__$1;
(statearr_52192_53338[(2)] = inst_52186);

(statearr_52192_53338[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52191 === (1))){
var state_52190__$1 = state_52190;
var statearr_52193_53339 = state_52190__$1;
(statearr_52193_53339[(2)] = null);

(statearr_52193_53339[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52191 === (4))){
var inst_52172 = (state_52190[(7)]);
var inst_52172__$1 = (state_52190[(2)]);
var inst_52173 = (inst_52172__$1 == null);
var state_52190__$1 = (function (){var statearr_52194 = state_52190;
(statearr_52194[(7)] = inst_52172__$1);

return statearr_52194;
})();
if(cljs.core.truth_(inst_52173)){
var statearr_52195_53340 = state_52190__$1;
(statearr_52195_53340[(1)] = (5));

} else {
var statearr_52196_53342 = state_52190__$1;
(statearr_52196_53342[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52191 === (6))){
var inst_52172 = (state_52190[(7)]);
var inst_52177 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_52172) : p.call(null,inst_52172));
var state_52190__$1 = state_52190;
if(cljs.core.truth_(inst_52177)){
var statearr_52197_53343 = state_52190__$1;
(statearr_52197_53343[(1)] = (8));

} else {
var statearr_52198_53348 = state_52190__$1;
(statearr_52198_53348[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52191 === (3))){
var inst_52188 = (state_52190[(2)]);
var state_52190__$1 = state_52190;
return cljs.core.async.impl.ioc_helpers.return_chan(state_52190__$1,inst_52188);
} else {
if((state_val_52191 === (2))){
var state_52190__$1 = state_52190;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_52190__$1,(4),ch);
} else {
if((state_val_52191 === (11))){
var inst_52180 = (state_52190[(2)]);
var state_52190__$1 = state_52190;
var statearr_52199_53366 = state_52190__$1;
(statearr_52199_53366[(2)] = inst_52180);

(statearr_52199_53366[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52191 === (9))){
var state_52190__$1 = state_52190;
var statearr_52200_53374 = state_52190__$1;
(statearr_52200_53374[(2)] = null);

(statearr_52200_53374[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52191 === (5))){
var inst_52175 = cljs.core.async.close_BANG_(out);
var state_52190__$1 = state_52190;
var statearr_52201_53384 = state_52190__$1;
(statearr_52201_53384[(2)] = inst_52175);

(statearr_52201_53384[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52191 === (10))){
var inst_52183 = (state_52190[(2)]);
var state_52190__$1 = (function (){var statearr_52202 = state_52190;
(statearr_52202[(8)] = inst_52183);

return statearr_52202;
})();
var statearr_52203_53397 = state_52190__$1;
(statearr_52203_53397[(2)] = null);

(statearr_52203_53397[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52191 === (8))){
var inst_52172 = (state_52190[(7)]);
var state_52190__$1 = state_52190;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52190__$1,(11),out,inst_52172);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53337,out))
;
return ((function (switch__50901__auto__,c__51002__auto___53337,out){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_52204 = [null,null,null,null,null,null,null,null,null];
(statearr_52204[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_52204[(1)] = (1));

return statearr_52204;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_52190){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_52190);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e52205){if((e52205 instanceof Object)){
var ex__50905__auto__ = e52205;
var statearr_52206_53431 = state_52190;
(statearr_52206_53431[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_52190);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52205;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53437 = state_52190;
state_52190 = G__53437;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_52190){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_52190);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53337,out))
})();
var state__51004__auto__ = (function (){var statearr_52207 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_52207[(6)] = c__51002__auto___53337);

return statearr_52207;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53337,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__52209 = arguments.length;
switch (G__52209) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__51002__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto__){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto__){
return (function (state_52271){
var state_val_52272 = (state_52271[(1)]);
if((state_val_52272 === (7))){
var inst_52267 = (state_52271[(2)]);
var state_52271__$1 = state_52271;
var statearr_52273_53442 = state_52271__$1;
(statearr_52273_53442[(2)] = inst_52267);

(statearr_52273_53442[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (20))){
var inst_52237 = (state_52271[(7)]);
var inst_52248 = (state_52271[(2)]);
var inst_52249 = cljs.core.next(inst_52237);
var inst_52223 = inst_52249;
var inst_52224 = null;
var inst_52225 = (0);
var inst_52226 = (0);
var state_52271__$1 = (function (){var statearr_52274 = state_52271;
(statearr_52274[(8)] = inst_52223);

(statearr_52274[(9)] = inst_52226);

(statearr_52274[(10)] = inst_52248);

(statearr_52274[(11)] = inst_52224);

(statearr_52274[(12)] = inst_52225);

return statearr_52274;
})();
var statearr_52275_53447 = state_52271__$1;
(statearr_52275_53447[(2)] = null);

(statearr_52275_53447[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (1))){
var state_52271__$1 = state_52271;
var statearr_52276_53448 = state_52271__$1;
(statearr_52276_53448[(2)] = null);

(statearr_52276_53448[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (4))){
var inst_52212 = (state_52271[(13)]);
var inst_52212__$1 = (state_52271[(2)]);
var inst_52213 = (inst_52212__$1 == null);
var state_52271__$1 = (function (){var statearr_52277 = state_52271;
(statearr_52277[(13)] = inst_52212__$1);

return statearr_52277;
})();
if(cljs.core.truth_(inst_52213)){
var statearr_52278_53453 = state_52271__$1;
(statearr_52278_53453[(1)] = (5));

} else {
var statearr_52279_53454 = state_52271__$1;
(statearr_52279_53454[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (15))){
var state_52271__$1 = state_52271;
var statearr_52283_53459 = state_52271__$1;
(statearr_52283_53459[(2)] = null);

(statearr_52283_53459[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (21))){
var state_52271__$1 = state_52271;
var statearr_52284_53460 = state_52271__$1;
(statearr_52284_53460[(2)] = null);

(statearr_52284_53460[(1)] = (23));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (13))){
var inst_52223 = (state_52271[(8)]);
var inst_52226 = (state_52271[(9)]);
var inst_52224 = (state_52271[(11)]);
var inst_52225 = (state_52271[(12)]);
var inst_52233 = (state_52271[(2)]);
var inst_52234 = (inst_52226 + (1));
var tmp52280 = inst_52223;
var tmp52281 = inst_52224;
var tmp52282 = inst_52225;
var inst_52223__$1 = tmp52280;
var inst_52224__$1 = tmp52281;
var inst_52225__$1 = tmp52282;
var inst_52226__$1 = inst_52234;
var state_52271__$1 = (function (){var statearr_52285 = state_52271;
(statearr_52285[(14)] = inst_52233);

(statearr_52285[(8)] = inst_52223__$1);

(statearr_52285[(9)] = inst_52226__$1);

(statearr_52285[(11)] = inst_52224__$1);

(statearr_52285[(12)] = inst_52225__$1);

return statearr_52285;
})();
var statearr_52286_53462 = state_52271__$1;
(statearr_52286_53462[(2)] = null);

(statearr_52286_53462[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (22))){
var state_52271__$1 = state_52271;
var statearr_52287_53463 = state_52271__$1;
(statearr_52287_53463[(2)] = null);

(statearr_52287_53463[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (6))){
var inst_52212 = (state_52271[(13)]);
var inst_52221 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_52212) : f.call(null,inst_52212));
var inst_52222 = cljs.core.seq(inst_52221);
var inst_52223 = inst_52222;
var inst_52224 = null;
var inst_52225 = (0);
var inst_52226 = (0);
var state_52271__$1 = (function (){var statearr_52288 = state_52271;
(statearr_52288[(8)] = inst_52223);

(statearr_52288[(9)] = inst_52226);

(statearr_52288[(11)] = inst_52224);

(statearr_52288[(12)] = inst_52225);

return statearr_52288;
})();
var statearr_52289_53468 = state_52271__$1;
(statearr_52289_53468[(2)] = null);

(statearr_52289_53468[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (17))){
var inst_52237 = (state_52271[(7)]);
var inst_52241 = cljs.core.chunk_first(inst_52237);
var inst_52242 = cljs.core.chunk_rest(inst_52237);
var inst_52243 = cljs.core.count(inst_52241);
var inst_52223 = inst_52242;
var inst_52224 = inst_52241;
var inst_52225 = inst_52243;
var inst_52226 = (0);
var state_52271__$1 = (function (){var statearr_52290 = state_52271;
(statearr_52290[(8)] = inst_52223);

(statearr_52290[(9)] = inst_52226);

(statearr_52290[(11)] = inst_52224);

(statearr_52290[(12)] = inst_52225);

return statearr_52290;
})();
var statearr_52291_53469 = state_52271__$1;
(statearr_52291_53469[(2)] = null);

(statearr_52291_53469[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (3))){
var inst_52269 = (state_52271[(2)]);
var state_52271__$1 = state_52271;
return cljs.core.async.impl.ioc_helpers.return_chan(state_52271__$1,inst_52269);
} else {
if((state_val_52272 === (12))){
var inst_52257 = (state_52271[(2)]);
var state_52271__$1 = state_52271;
var statearr_52292_53475 = state_52271__$1;
(statearr_52292_53475[(2)] = inst_52257);

(statearr_52292_53475[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (2))){
var state_52271__$1 = state_52271;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_52271__$1,(4),in$);
} else {
if((state_val_52272 === (23))){
var inst_52265 = (state_52271[(2)]);
var state_52271__$1 = state_52271;
var statearr_52293_53476 = state_52271__$1;
(statearr_52293_53476[(2)] = inst_52265);

(statearr_52293_53476[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (19))){
var inst_52252 = (state_52271[(2)]);
var state_52271__$1 = state_52271;
var statearr_52294_53477 = state_52271__$1;
(statearr_52294_53477[(2)] = inst_52252);

(statearr_52294_53477[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (11))){
var inst_52223 = (state_52271[(8)]);
var inst_52237 = (state_52271[(7)]);
var inst_52237__$1 = cljs.core.seq(inst_52223);
var state_52271__$1 = (function (){var statearr_52295 = state_52271;
(statearr_52295[(7)] = inst_52237__$1);

return statearr_52295;
})();
if(inst_52237__$1){
var statearr_52296_53478 = state_52271__$1;
(statearr_52296_53478[(1)] = (14));

} else {
var statearr_52297_53479 = state_52271__$1;
(statearr_52297_53479[(1)] = (15));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (9))){
var inst_52259 = (state_52271[(2)]);
var inst_52260 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_52271__$1 = (function (){var statearr_52298 = state_52271;
(statearr_52298[(15)] = inst_52259);

return statearr_52298;
})();
if(cljs.core.truth_(inst_52260)){
var statearr_52299_53483 = state_52271__$1;
(statearr_52299_53483[(1)] = (21));

} else {
var statearr_52300_53484 = state_52271__$1;
(statearr_52300_53484[(1)] = (22));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (5))){
var inst_52215 = cljs.core.async.close_BANG_(out);
var state_52271__$1 = state_52271;
var statearr_52301_53485 = state_52271__$1;
(statearr_52301_53485[(2)] = inst_52215);

(statearr_52301_53485[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (14))){
var inst_52237 = (state_52271[(7)]);
var inst_52239 = cljs.core.chunked_seq_QMARK_(inst_52237);
var state_52271__$1 = state_52271;
if(inst_52239){
var statearr_52302_53490 = state_52271__$1;
(statearr_52302_53490[(1)] = (17));

} else {
var statearr_52303_53491 = state_52271__$1;
(statearr_52303_53491[(1)] = (18));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (16))){
var inst_52255 = (state_52271[(2)]);
var state_52271__$1 = state_52271;
var statearr_52304_53493 = state_52271__$1;
(statearr_52304_53493[(2)] = inst_52255);

(statearr_52304_53493[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52272 === (10))){
var inst_52226 = (state_52271[(9)]);
var inst_52224 = (state_52271[(11)]);
var inst_52231 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_52224,inst_52226);
var state_52271__$1 = state_52271;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52271__$1,(13),out,inst_52231);
} else {
if((state_val_52272 === (18))){
var inst_52237 = (state_52271[(7)]);
var inst_52246 = cljs.core.first(inst_52237);
var state_52271__$1 = state_52271;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52271__$1,(20),out,inst_52246);
} else {
if((state_val_52272 === (8))){
var inst_52226 = (state_52271[(9)]);
var inst_52225 = (state_52271[(12)]);
var inst_52228 = (inst_52226 < inst_52225);
var inst_52229 = inst_52228;
var state_52271__$1 = state_52271;
if(cljs.core.truth_(inst_52229)){
var statearr_52305_53514 = state_52271__$1;
(statearr_52305_53514[(1)] = (10));

} else {
var statearr_52306_53515 = state_52271__$1;
(statearr_52306_53515[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto__))
;
return ((function (switch__50901__auto__,c__51002__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__50902__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__50902__auto____0 = (function (){
var statearr_52307 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_52307[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__50902__auto__);

(statearr_52307[(1)] = (1));

return statearr_52307;
});
var cljs$core$async$mapcat_STAR__$_state_machine__50902__auto____1 = (function (state_52271){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_52271);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e52308){if((e52308 instanceof Object)){
var ex__50905__auto__ = e52308;
var statearr_52309_53523 = state_52271;
(statearr_52309_53523[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_52271);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52308;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53528 = state_52271;
state_52271 = G__53528;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__50902__auto__ = function(state_52271){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__50902__auto____1.call(this,state_52271);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__50902__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__50902__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto__))
})();
var state__51004__auto__ = (function (){var statearr_52310 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_52310[(6)] = c__51002__auto__);

return statearr_52310;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto__))
);

return c__51002__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__52312 = arguments.length;
switch (G__52312) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__52314 = arguments.length;
switch (G__52314) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__52316 = arguments.length;
switch (G__52316) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__51002__auto___53550 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53550,out){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53550,out){
return (function (state_52340){
var state_val_52341 = (state_52340[(1)]);
if((state_val_52341 === (7))){
var inst_52335 = (state_52340[(2)]);
var state_52340__$1 = state_52340;
var statearr_52342_53554 = state_52340__$1;
(statearr_52342_53554[(2)] = inst_52335);

(statearr_52342_53554[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52341 === (1))){
var inst_52317 = null;
var state_52340__$1 = (function (){var statearr_52343 = state_52340;
(statearr_52343[(7)] = inst_52317);

return statearr_52343;
})();
var statearr_52344_53555 = state_52340__$1;
(statearr_52344_53555[(2)] = null);

(statearr_52344_53555[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52341 === (4))){
var inst_52320 = (state_52340[(8)]);
var inst_52320__$1 = (state_52340[(2)]);
var inst_52321 = (inst_52320__$1 == null);
var inst_52322 = cljs.core.not(inst_52321);
var state_52340__$1 = (function (){var statearr_52345 = state_52340;
(statearr_52345[(8)] = inst_52320__$1);

return statearr_52345;
})();
if(inst_52322){
var statearr_52346_53556 = state_52340__$1;
(statearr_52346_53556[(1)] = (5));

} else {
var statearr_52347_53557 = state_52340__$1;
(statearr_52347_53557[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52341 === (6))){
var state_52340__$1 = state_52340;
var statearr_52348_53558 = state_52340__$1;
(statearr_52348_53558[(2)] = null);

(statearr_52348_53558[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52341 === (3))){
var inst_52337 = (state_52340[(2)]);
var inst_52338 = cljs.core.async.close_BANG_(out);
var state_52340__$1 = (function (){var statearr_52349 = state_52340;
(statearr_52349[(9)] = inst_52337);

return statearr_52349;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_52340__$1,inst_52338);
} else {
if((state_val_52341 === (2))){
var state_52340__$1 = state_52340;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_52340__$1,(4),ch);
} else {
if((state_val_52341 === (11))){
var inst_52320 = (state_52340[(8)]);
var inst_52329 = (state_52340[(2)]);
var inst_52317 = inst_52320;
var state_52340__$1 = (function (){var statearr_52350 = state_52340;
(statearr_52350[(10)] = inst_52329);

(statearr_52350[(7)] = inst_52317);

return statearr_52350;
})();
var statearr_52351_53559 = state_52340__$1;
(statearr_52351_53559[(2)] = null);

(statearr_52351_53559[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52341 === (9))){
var inst_52320 = (state_52340[(8)]);
var state_52340__$1 = state_52340;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52340__$1,(11),out,inst_52320);
} else {
if((state_val_52341 === (5))){
var inst_52320 = (state_52340[(8)]);
var inst_52317 = (state_52340[(7)]);
var inst_52324 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_52320,inst_52317);
var state_52340__$1 = state_52340;
if(inst_52324){
var statearr_52353_53563 = state_52340__$1;
(statearr_52353_53563[(1)] = (8));

} else {
var statearr_52354_53564 = state_52340__$1;
(statearr_52354_53564[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52341 === (10))){
var inst_52332 = (state_52340[(2)]);
var state_52340__$1 = state_52340;
var statearr_52355_53569 = state_52340__$1;
(statearr_52355_53569[(2)] = inst_52332);

(statearr_52355_53569[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52341 === (8))){
var inst_52317 = (state_52340[(7)]);
var tmp52352 = inst_52317;
var inst_52317__$1 = tmp52352;
var state_52340__$1 = (function (){var statearr_52356 = state_52340;
(statearr_52356[(7)] = inst_52317__$1);

return statearr_52356;
})();
var statearr_52357_53570 = state_52340__$1;
(statearr_52357_53570[(2)] = null);

(statearr_52357_53570[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53550,out))
;
return ((function (switch__50901__auto__,c__51002__auto___53550,out){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_52358 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_52358[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_52358[(1)] = (1));

return statearr_52358;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_52340){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_52340);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e52359){if((e52359 instanceof Object)){
var ex__50905__auto__ = e52359;
var statearr_52360_53579 = state_52340;
(statearr_52360_53579[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_52340);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52359;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53580 = state_52340;
state_52340 = G__53580;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_52340){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_52340);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53550,out))
})();
var state__51004__auto__ = (function (){var statearr_52361 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_52361[(6)] = c__51002__auto___53550);

return statearr_52361;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53550,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__52363 = arguments.length;
switch (G__52363) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__51002__auto___53583 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53583,out){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53583,out){
return (function (state_52401){
var state_val_52402 = (state_52401[(1)]);
if((state_val_52402 === (7))){
var inst_52397 = (state_52401[(2)]);
var state_52401__$1 = state_52401;
var statearr_52403_53584 = state_52401__$1;
(statearr_52403_53584[(2)] = inst_52397);

(statearr_52403_53584[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (1))){
var inst_52364 = (new Array(n));
var inst_52365 = inst_52364;
var inst_52366 = (0);
var state_52401__$1 = (function (){var statearr_52404 = state_52401;
(statearr_52404[(7)] = inst_52365);

(statearr_52404[(8)] = inst_52366);

return statearr_52404;
})();
var statearr_52405_53585 = state_52401__$1;
(statearr_52405_53585[(2)] = null);

(statearr_52405_53585[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (4))){
var inst_52369 = (state_52401[(9)]);
var inst_52369__$1 = (state_52401[(2)]);
var inst_52370 = (inst_52369__$1 == null);
var inst_52371 = cljs.core.not(inst_52370);
var state_52401__$1 = (function (){var statearr_52406 = state_52401;
(statearr_52406[(9)] = inst_52369__$1);

return statearr_52406;
})();
if(inst_52371){
var statearr_52407_53588 = state_52401__$1;
(statearr_52407_53588[(1)] = (5));

} else {
var statearr_52408_53589 = state_52401__$1;
(statearr_52408_53589[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (15))){
var inst_52391 = (state_52401[(2)]);
var state_52401__$1 = state_52401;
var statearr_52409_53591 = state_52401__$1;
(statearr_52409_53591[(2)] = inst_52391);

(statearr_52409_53591[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (13))){
var state_52401__$1 = state_52401;
var statearr_52410_53593 = state_52401__$1;
(statearr_52410_53593[(2)] = null);

(statearr_52410_53593[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (6))){
var inst_52366 = (state_52401[(8)]);
var inst_52387 = (inst_52366 > (0));
var state_52401__$1 = state_52401;
if(cljs.core.truth_(inst_52387)){
var statearr_52411_53594 = state_52401__$1;
(statearr_52411_53594[(1)] = (12));

} else {
var statearr_52412_53595 = state_52401__$1;
(statearr_52412_53595[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (3))){
var inst_52399 = (state_52401[(2)]);
var state_52401__$1 = state_52401;
return cljs.core.async.impl.ioc_helpers.return_chan(state_52401__$1,inst_52399);
} else {
if((state_val_52402 === (12))){
var inst_52365 = (state_52401[(7)]);
var inst_52389 = cljs.core.vec(inst_52365);
var state_52401__$1 = state_52401;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52401__$1,(15),out,inst_52389);
} else {
if((state_val_52402 === (2))){
var state_52401__$1 = state_52401;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_52401__$1,(4),ch);
} else {
if((state_val_52402 === (11))){
var inst_52381 = (state_52401[(2)]);
var inst_52382 = (new Array(n));
var inst_52365 = inst_52382;
var inst_52366 = (0);
var state_52401__$1 = (function (){var statearr_52413 = state_52401;
(statearr_52413[(7)] = inst_52365);

(statearr_52413[(10)] = inst_52381);

(statearr_52413[(8)] = inst_52366);

return statearr_52413;
})();
var statearr_52414_53600 = state_52401__$1;
(statearr_52414_53600[(2)] = null);

(statearr_52414_53600[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (9))){
var inst_52365 = (state_52401[(7)]);
var inst_52379 = cljs.core.vec(inst_52365);
var state_52401__$1 = state_52401;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52401__$1,(11),out,inst_52379);
} else {
if((state_val_52402 === (5))){
var inst_52369 = (state_52401[(9)]);
var inst_52365 = (state_52401[(7)]);
var inst_52374 = (state_52401[(11)]);
var inst_52366 = (state_52401[(8)]);
var inst_52373 = (inst_52365[inst_52366] = inst_52369);
var inst_52374__$1 = (inst_52366 + (1));
var inst_52375 = (inst_52374__$1 < n);
var state_52401__$1 = (function (){var statearr_52415 = state_52401;
(statearr_52415[(12)] = inst_52373);

(statearr_52415[(11)] = inst_52374__$1);

return statearr_52415;
})();
if(cljs.core.truth_(inst_52375)){
var statearr_52416_53604 = state_52401__$1;
(statearr_52416_53604[(1)] = (8));

} else {
var statearr_52417_53605 = state_52401__$1;
(statearr_52417_53605[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (14))){
var inst_52394 = (state_52401[(2)]);
var inst_52395 = cljs.core.async.close_BANG_(out);
var state_52401__$1 = (function (){var statearr_52419 = state_52401;
(statearr_52419[(13)] = inst_52394);

return statearr_52419;
})();
var statearr_52420_53606 = state_52401__$1;
(statearr_52420_53606[(2)] = inst_52395);

(statearr_52420_53606[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (10))){
var inst_52385 = (state_52401[(2)]);
var state_52401__$1 = state_52401;
var statearr_52421_53610 = state_52401__$1;
(statearr_52421_53610[(2)] = inst_52385);

(statearr_52421_53610[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52402 === (8))){
var inst_52365 = (state_52401[(7)]);
var inst_52374 = (state_52401[(11)]);
var tmp52418 = inst_52365;
var inst_52365__$1 = tmp52418;
var inst_52366 = inst_52374;
var state_52401__$1 = (function (){var statearr_52422 = state_52401;
(statearr_52422[(7)] = inst_52365__$1);

(statearr_52422[(8)] = inst_52366);

return statearr_52422;
})();
var statearr_52423_53611 = state_52401__$1;
(statearr_52423_53611[(2)] = null);

(statearr_52423_53611[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53583,out))
;
return ((function (switch__50901__auto__,c__51002__auto___53583,out){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_52424 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_52424[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_52424[(1)] = (1));

return statearr_52424;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_52401){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_52401);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e52425){if((e52425 instanceof Object)){
var ex__50905__auto__ = e52425;
var statearr_52426_53616 = state_52401;
(statearr_52426_53616[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_52401);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52425;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53617 = state_52401;
state_52401 = G__53617;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_52401){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_52401);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53583,out))
})();
var state__51004__auto__ = (function (){var statearr_52427 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_52427[(6)] = c__51002__auto___53583);

return statearr_52427;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53583,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__52429 = arguments.length;
switch (G__52429) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__51002__auto___53619 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__51002__auto___53619,out){
return (function (){
var f__51003__auto__ = (function (){var switch__50901__auto__ = ((function (c__51002__auto___53619,out){
return (function (state_52471){
var state_val_52472 = (state_52471[(1)]);
if((state_val_52472 === (7))){
var inst_52467 = (state_52471[(2)]);
var state_52471__$1 = state_52471;
var statearr_52473_53623 = state_52471__$1;
(statearr_52473_53623[(2)] = inst_52467);

(statearr_52473_53623[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (1))){
var inst_52430 = [];
var inst_52431 = inst_52430;
var inst_52432 = new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123);
var state_52471__$1 = (function (){var statearr_52474 = state_52471;
(statearr_52474[(7)] = inst_52431);

(statearr_52474[(8)] = inst_52432);

return statearr_52474;
})();
var statearr_52475_53624 = state_52471__$1;
(statearr_52475_53624[(2)] = null);

(statearr_52475_53624[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (4))){
var inst_52435 = (state_52471[(9)]);
var inst_52435__$1 = (state_52471[(2)]);
var inst_52436 = (inst_52435__$1 == null);
var inst_52437 = cljs.core.not(inst_52436);
var state_52471__$1 = (function (){var statearr_52476 = state_52471;
(statearr_52476[(9)] = inst_52435__$1);

return statearr_52476;
})();
if(inst_52437){
var statearr_52477_53626 = state_52471__$1;
(statearr_52477_53626[(1)] = (5));

} else {
var statearr_52478_53630 = state_52471__$1;
(statearr_52478_53630[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (15))){
var inst_52461 = (state_52471[(2)]);
var state_52471__$1 = state_52471;
var statearr_52479_53631 = state_52471__$1;
(statearr_52479_53631[(2)] = inst_52461);

(statearr_52479_53631[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (13))){
var state_52471__$1 = state_52471;
var statearr_52480_53632 = state_52471__$1;
(statearr_52480_53632[(2)] = null);

(statearr_52480_53632[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (6))){
var inst_52431 = (state_52471[(7)]);
var inst_52456 = inst_52431.length;
var inst_52457 = (inst_52456 > (0));
var state_52471__$1 = state_52471;
if(cljs.core.truth_(inst_52457)){
var statearr_52481_53633 = state_52471__$1;
(statearr_52481_53633[(1)] = (12));

} else {
var statearr_52482_53634 = state_52471__$1;
(statearr_52482_53634[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (3))){
var inst_52469 = (state_52471[(2)]);
var state_52471__$1 = state_52471;
return cljs.core.async.impl.ioc_helpers.return_chan(state_52471__$1,inst_52469);
} else {
if((state_val_52472 === (12))){
var inst_52431 = (state_52471[(7)]);
var inst_52459 = cljs.core.vec(inst_52431);
var state_52471__$1 = state_52471;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52471__$1,(15),out,inst_52459);
} else {
if((state_val_52472 === (2))){
var state_52471__$1 = state_52471;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_52471__$1,(4),ch);
} else {
if((state_val_52472 === (11))){
var inst_52435 = (state_52471[(9)]);
var inst_52439 = (state_52471[(10)]);
var inst_52449 = (state_52471[(2)]);
var inst_52450 = [];
var inst_52451 = inst_52450.push(inst_52435);
var inst_52431 = inst_52450;
var inst_52432 = inst_52439;
var state_52471__$1 = (function (){var statearr_52483 = state_52471;
(statearr_52483[(11)] = inst_52449);

(statearr_52483[(7)] = inst_52431);

(statearr_52483[(8)] = inst_52432);

(statearr_52483[(12)] = inst_52451);

return statearr_52483;
})();
var statearr_52484_53637 = state_52471__$1;
(statearr_52484_53637[(2)] = null);

(statearr_52484_53637[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (9))){
var inst_52431 = (state_52471[(7)]);
var inst_52447 = cljs.core.vec(inst_52431);
var state_52471__$1 = state_52471;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_52471__$1,(11),out,inst_52447);
} else {
if((state_val_52472 === (5))){
var inst_52435 = (state_52471[(9)]);
var inst_52432 = (state_52471[(8)]);
var inst_52439 = (state_52471[(10)]);
var inst_52439__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_52435) : f.call(null,inst_52435));
var inst_52440 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_52439__$1,inst_52432);
var inst_52441 = cljs.core.keyword_identical_QMARK_(inst_52432,new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123));
var inst_52442 = ((inst_52440) || (inst_52441));
var state_52471__$1 = (function (){var statearr_52485 = state_52471;
(statearr_52485[(10)] = inst_52439__$1);

return statearr_52485;
})();
if(cljs.core.truth_(inst_52442)){
var statearr_52486_53639 = state_52471__$1;
(statearr_52486_53639[(1)] = (8));

} else {
var statearr_52487_53640 = state_52471__$1;
(statearr_52487_53640[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (14))){
var inst_52464 = (state_52471[(2)]);
var inst_52465 = cljs.core.async.close_BANG_(out);
var state_52471__$1 = (function (){var statearr_52489 = state_52471;
(statearr_52489[(13)] = inst_52464);

return statearr_52489;
})();
var statearr_52490_53641 = state_52471__$1;
(statearr_52490_53641[(2)] = inst_52465);

(statearr_52490_53641[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (10))){
var inst_52454 = (state_52471[(2)]);
var state_52471__$1 = state_52471;
var statearr_52491_53642 = state_52471__$1;
(statearr_52491_53642[(2)] = inst_52454);

(statearr_52491_53642[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_52472 === (8))){
var inst_52431 = (state_52471[(7)]);
var inst_52435 = (state_52471[(9)]);
var inst_52439 = (state_52471[(10)]);
var inst_52444 = inst_52431.push(inst_52435);
var tmp52488 = inst_52431;
var inst_52431__$1 = tmp52488;
var inst_52432 = inst_52439;
var state_52471__$1 = (function (){var statearr_52492 = state_52471;
(statearr_52492[(14)] = inst_52444);

(statearr_52492[(7)] = inst_52431__$1);

(statearr_52492[(8)] = inst_52432);

return statearr_52492;
})();
var statearr_52493_53645 = state_52471__$1;
(statearr_52493_53645[(2)] = null);

(statearr_52493_53645[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__51002__auto___53619,out))
;
return ((function (switch__50901__auto__,c__51002__auto___53619,out){
return (function() {
var cljs$core$async$state_machine__50902__auto__ = null;
var cljs$core$async$state_machine__50902__auto____0 = (function (){
var statearr_52494 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_52494[(0)] = cljs$core$async$state_machine__50902__auto__);

(statearr_52494[(1)] = (1));

return statearr_52494;
});
var cljs$core$async$state_machine__50902__auto____1 = (function (state_52471){
while(true){
var ret_value__50903__auto__ = (function (){try{while(true){
var result__50904__auto__ = switch__50901__auto__(state_52471);
if(cljs.core.keyword_identical_QMARK_(result__50904__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__50904__auto__;
}
break;
}
}catch (e52495){if((e52495 instanceof Object)){
var ex__50905__auto__ = e52495;
var statearr_52496_53649 = state_52471;
(statearr_52496_53649[(5)] = ex__50905__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_52471);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e52495;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__50903__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__53650 = state_52471;
state_52471 = G__53650;
continue;
} else {
return ret_value__50903__auto__;
}
break;
}
});
cljs$core$async$state_machine__50902__auto__ = function(state_52471){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__50902__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__50902__auto____1.call(this,state_52471);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__50902__auto____0;
cljs$core$async$state_machine__50902__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__50902__auto____1;
return cljs$core$async$state_machine__50902__auto__;
})()
;})(switch__50901__auto__,c__51002__auto___53619,out))
})();
var state__51004__auto__ = (function (){var statearr_52497 = (f__51003__auto__.cljs$core$IFn$_invoke$arity$0 ? f__51003__auto__.cljs$core$IFn$_invoke$arity$0() : f__51003__auto__.call(null));
(statearr_52497[(6)] = c__51002__auto___53619);

return statearr_52497;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__51004__auto__);
});})(c__51002__auto___53619,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;


//# sourceMappingURL=cljs.core.async.js.map
