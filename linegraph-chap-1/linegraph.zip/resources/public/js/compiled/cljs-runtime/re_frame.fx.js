goog.provide('re_frame.fx');
goog.require('cljs.core');
goog.require('re_frame.router');
goog.require('re_frame.db');
goog.require('re_frame.interceptor');
goog.require('re_frame.interop');
goog.require('re_frame.events');
goog.require('re_frame.registrar');
goog.require('re_frame.loggers');
goog.require('re_frame.trace');
re_frame.fx.kind = new cljs.core.Keyword(null,"fx","fx",-1237829572);
if(cljs.core.truth_((re_frame.registrar.kinds.cljs$core$IFn$_invoke$arity$1 ? re_frame.registrar.kinds.cljs$core$IFn$_invoke$arity$1(re_frame.fx.kind) : re_frame.registrar.kinds.call(null,re_frame.fx.kind)))){
} else {
throw (new Error("Assert failed: (re-frame.registrar/kinds kind)"));
}
/**
 * Register the given effect `handler` for the given `id`.
 * 
 *   `id` is keyword, often namespaced.
 *   `handler` is a side-effecting function which takes a single argument and whose return
 *   value is ignored.
 * 
 *   Example Use
 *   -----------
 * 
 *   First, registration ... associate `:effect2` with a handler.
 * 
 *   (reg-fx
 *   :effect2
 *   (fn [value]
 *      ... do something side-effect-y))
 * 
 *   Then, later, if an event handler were to return this effects map ...
 * 
 *   {...
 * :effect2  [1 2]}
 * 
 * ... then the `handler` `fn` we registered previously, using `reg-fx`, will be
 * called with an argument of `[1 2]`.
 */
re_frame.fx.reg_fx = (function re_frame$fx$reg_fx(id,handler){
return re_frame.registrar.register_handler(re_frame.fx.kind,id,handler);
});
/**
 * An interceptor whose `:after` actions the contents of `:effects`. As a result,
 *   this interceptor is Domino 3.
 * 
 *   This interceptor is silently added (by reg-event-db etc) to the front of
 *   interceptor chains for all events.
 * 
 *   For each key in `:effects` (a map), it calls the registered `effects handler`
 *   (see `reg-fx` for registration of effect handlers).
 * 
 *   So, if `:effects` was:
 *    {:dispatch  [:hello 42]
 *     :db        {...}
 *     :undo      "set flag"}
 * 
 *   it will call the registered effect handlers for each of the map's keys:
 *   `:dispatch`, `:undo` and `:db`. When calling each handler, provides the map
 *   value for that key - so in the example above the effect handler for :dispatch
 *   will be given one arg `[:hello 42]`.
 * 
 *   You cannot rely on the ordering in which effects are executed.
 */
re_frame.fx.do_fx = re_frame.interceptor.__GT_interceptor.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"id","id",-1388402092),new cljs.core.Keyword(null,"do-fx","do-fx",1194163050),new cljs.core.Keyword(null,"after","after",594996914),(function re_frame$fx$do_fx_after(context){
if(re_frame.trace.is_trace_enabled_QMARK_()){
var _STAR_current_trace_STAR__orig_val__57828 = re_frame.trace._STAR_current_trace_STAR_;
var _STAR_current_trace_STAR__temp_val__57829 = re_frame.trace.start_trace(new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"op-type","op-type",-1636141668),new cljs.core.Keyword("event","do-fx","event/do-fx",1357330452)], null));
re_frame.trace._STAR_current_trace_STAR_ = _STAR_current_trace_STAR__temp_val__57829;

try{try{var seq__57830 = cljs.core.seq(new cljs.core.Keyword(null,"effects","effects",-282369292).cljs$core$IFn$_invoke$arity$1(context));
var chunk__57831 = null;
var count__57832 = (0);
var i__57833 = (0);
while(true){
if((i__57833 < count__57832)){
var vec__57843 = chunk__57831.cljs$core$IIndexed$_nth$arity$2(null,i__57833);
var effect_key = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__57843,(0),null);
var effect_value = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__57843,(1),null);
var temp__5733__auto___57912 = re_frame.registrar.get_handler.cljs$core$IFn$_invoke$arity$3(re_frame.fx.kind,effect_key,false);
if(cljs.core.truth_(temp__5733__auto___57912)){
var effect_fn_57913 = temp__5733__auto___57912;
(effect_fn_57913.cljs$core$IFn$_invoke$arity$1 ? effect_fn_57913.cljs$core$IFn$_invoke$arity$1(effect_value) : effect_fn_57913.call(null,effect_value));
} else {
re_frame.loggers.console.cljs$core$IFn$_invoke$arity$variadic(new cljs.core.Keyword(null,"error","error",-978969032),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["re-frame: no handler registered for effect:",effect_key,". Ignoring."], 0));
}


var G__57914 = seq__57830;
var G__57915 = chunk__57831;
var G__57916 = count__57832;
var G__57917 = (i__57833 + (1));
seq__57830 = G__57914;
chunk__57831 = G__57915;
count__57832 = G__57916;
i__57833 = G__57917;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__57830);
if(temp__5735__auto__){
var seq__57830__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__57830__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__57830__$1);
var G__57918 = cljs.core.chunk_rest(seq__57830__$1);
var G__57919 = c__4550__auto__;
var G__57920 = cljs.core.count(c__4550__auto__);
var G__57921 = (0);
seq__57830 = G__57918;
chunk__57831 = G__57919;
count__57832 = G__57920;
i__57833 = G__57921;
continue;
} else {
var vec__57850 = cljs.core.first(seq__57830__$1);
var effect_key = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__57850,(0),null);
var effect_value = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__57850,(1),null);
var temp__5733__auto___57922 = re_frame.registrar.get_handler.cljs$core$IFn$_invoke$arity$3(re_frame.fx.kind,effect_key,false);
if(cljs.core.truth_(temp__5733__auto___57922)){
var effect_fn_57923 = temp__5733__auto___57922;
(effect_fn_57923.cljs$core$IFn$_invoke$arity$1 ? effect_fn_57923.cljs$core$IFn$_invoke$arity$1(effect_value) : effect_fn_57923.call(null,effect_value));
} else {
re_frame.loggers.console.cljs$core$IFn$_invoke$arity$variadic(new cljs.core.Keyword(null,"error","error",-978969032),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["re-frame: no handler registered for effect:",effect_key,". Ignoring."], 0));
}


var G__57924 = cljs.core.next(seq__57830__$1);
var G__57925 = null;
var G__57926 = (0);
var G__57927 = (0);
seq__57830 = G__57924;
chunk__57831 = G__57925;
count__57832 = G__57926;
i__57833 = G__57927;
continue;
}
} else {
return null;
}
}
break;
}
}finally {if(re_frame.trace.is_trace_enabled_QMARK_()){
var end__57565__auto___57928 = re_frame.interop.now();
var duration__57566__auto___57929 = (end__57565__auto___57928 - new cljs.core.Keyword(null,"start","start",-355208981).cljs$core$IFn$_invoke$arity$1(re_frame.trace._STAR_current_trace_STAR_));
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(re_frame.trace.traces,cljs.core.conj,cljs.core.assoc.cljs$core$IFn$_invoke$arity$variadic(re_frame.trace._STAR_current_trace_STAR_,new cljs.core.Keyword(null,"duration","duration",1444101068),duration__57566__auto___57929,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"end","end",-268185958),re_frame.interop.now()], 0)));

re_frame.trace.run_tracing_callbacks_BANG_(end__57565__auto___57928);
} else {
}
}}finally {re_frame.trace._STAR_current_trace_STAR_ = _STAR_current_trace_STAR__orig_val__57828;
}} else {
var seq__57853 = cljs.core.seq(new cljs.core.Keyword(null,"effects","effects",-282369292).cljs$core$IFn$_invoke$arity$1(context));
var chunk__57854 = null;
var count__57855 = (0);
var i__57856 = (0);
while(true){
if((i__57856 < count__57855)){
var vec__57866 = chunk__57854.cljs$core$IIndexed$_nth$arity$2(null,i__57856);
var effect_key = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__57866,(0),null);
var effect_value = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__57866,(1),null);
var temp__5733__auto___57934 = re_frame.registrar.get_handler.cljs$core$IFn$_invoke$arity$3(re_frame.fx.kind,effect_key,false);
if(cljs.core.truth_(temp__5733__auto___57934)){
var effect_fn_57935 = temp__5733__auto___57934;
(effect_fn_57935.cljs$core$IFn$_invoke$arity$1 ? effect_fn_57935.cljs$core$IFn$_invoke$arity$1(effect_value) : effect_fn_57935.call(null,effect_value));
} else {
re_frame.loggers.console.cljs$core$IFn$_invoke$arity$variadic(new cljs.core.Keyword(null,"error","error",-978969032),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["re-frame: no handler registered for effect:",effect_key,". Ignoring."], 0));
}


var G__57940 = seq__57853;
var G__57941 = chunk__57854;
var G__57942 = count__57855;
var G__57943 = (i__57856 + (1));
seq__57853 = G__57940;
chunk__57854 = G__57941;
count__57855 = G__57942;
i__57856 = G__57943;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__57853);
if(temp__5735__auto__){
var seq__57853__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__57853__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__57853__$1);
var G__57948 = cljs.core.chunk_rest(seq__57853__$1);
var G__57949 = c__4550__auto__;
var G__57950 = cljs.core.count(c__4550__auto__);
var G__57951 = (0);
seq__57853 = G__57948;
chunk__57854 = G__57949;
count__57855 = G__57950;
i__57856 = G__57951;
continue;
} else {
var vec__57872 = cljs.core.first(seq__57853__$1);
var effect_key = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__57872,(0),null);
var effect_value = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__57872,(1),null);
var temp__5733__auto___57956 = re_frame.registrar.get_handler.cljs$core$IFn$_invoke$arity$3(re_frame.fx.kind,effect_key,false);
if(cljs.core.truth_(temp__5733__auto___57956)){
var effect_fn_57957 = temp__5733__auto___57956;
(effect_fn_57957.cljs$core$IFn$_invoke$arity$1 ? effect_fn_57957.cljs$core$IFn$_invoke$arity$1(effect_value) : effect_fn_57957.call(null,effect_value));
} else {
re_frame.loggers.console.cljs$core$IFn$_invoke$arity$variadic(new cljs.core.Keyword(null,"error","error",-978969032),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["re-frame: no handler registered for effect:",effect_key,". Ignoring."], 0));
}


var G__57958 = cljs.core.next(seq__57853__$1);
var G__57959 = null;
var G__57960 = (0);
var G__57961 = (0);
seq__57853 = G__57958;
chunk__57854 = G__57959;
count__57855 = G__57960;
i__57856 = G__57961;
continue;
}
} else {
return null;
}
}
break;
}
}
})], 0));
re_frame.fx.reg_fx(new cljs.core.Keyword(null,"dispatch-later","dispatch-later",291951390),(function (value){
var seq__57876 = cljs.core.seq(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(cljs.core.nil_QMARK_,value));
var chunk__57877 = null;
var count__57878 = (0);
var i__57879 = (0);
while(true){
if((i__57879 < count__57878)){
var map__57888 = chunk__57877.cljs$core$IIndexed$_nth$arity$2(null,i__57879);
var map__57888__$1 = (((((!((map__57888 == null))))?(((((map__57888.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__57888.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__57888):map__57888);
var effect = map__57888__$1;
var ms = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__57888__$1,new cljs.core.Keyword(null,"ms","ms",-1152709733));
var dispatch = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__57888__$1,new cljs.core.Keyword(null,"dispatch","dispatch",1319337009));
if(((cljs.core.empty_QMARK_(dispatch)) || ((!(typeof ms === 'number'))))){
re_frame.loggers.console.cljs$core$IFn$_invoke$arity$variadic(new cljs.core.Keyword(null,"error","error",-978969032),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["re-frame: ignoring bad :dispatch-later value:",effect], 0));
} else {
re_frame.interop.set_timeout_BANG_(((function (seq__57876,chunk__57877,count__57878,i__57879,map__57888,map__57888__$1,effect,ms,dispatch){
return (function (){
return re_frame.router.dispatch(dispatch);
});})(seq__57876,chunk__57877,count__57878,i__57879,map__57888,map__57888__$1,effect,ms,dispatch))
,ms);
}


var G__57964 = seq__57876;
var G__57965 = chunk__57877;
var G__57966 = count__57878;
var G__57967 = (i__57879 + (1));
seq__57876 = G__57964;
chunk__57877 = G__57965;
count__57878 = G__57966;
i__57879 = G__57967;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__57876);
if(temp__5735__auto__){
var seq__57876__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__57876__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__57876__$1);
var G__57968 = cljs.core.chunk_rest(seq__57876__$1);
var G__57969 = c__4550__auto__;
var G__57970 = cljs.core.count(c__4550__auto__);
var G__57971 = (0);
seq__57876 = G__57968;
chunk__57877 = G__57969;
count__57878 = G__57970;
i__57879 = G__57971;
continue;
} else {
var map__57892 = cljs.core.first(seq__57876__$1);
var map__57892__$1 = (((((!((map__57892 == null))))?(((((map__57892.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__57892.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__57892):map__57892);
var effect = map__57892__$1;
var ms = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__57892__$1,new cljs.core.Keyword(null,"ms","ms",-1152709733));
var dispatch = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__57892__$1,new cljs.core.Keyword(null,"dispatch","dispatch",1319337009));
if(((cljs.core.empty_QMARK_(dispatch)) || ((!(typeof ms === 'number'))))){
re_frame.loggers.console.cljs$core$IFn$_invoke$arity$variadic(new cljs.core.Keyword(null,"error","error",-978969032),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["re-frame: ignoring bad :dispatch-later value:",effect], 0));
} else {
re_frame.interop.set_timeout_BANG_(((function (seq__57876,chunk__57877,count__57878,i__57879,map__57892,map__57892__$1,effect,ms,dispatch,seq__57876__$1,temp__5735__auto__){
return (function (){
return re_frame.router.dispatch(dispatch);
});})(seq__57876,chunk__57877,count__57878,i__57879,map__57892,map__57892__$1,effect,ms,dispatch,seq__57876__$1,temp__5735__auto__))
,ms);
}


var G__57973 = cljs.core.next(seq__57876__$1);
var G__57974 = null;
var G__57975 = (0);
var G__57976 = (0);
seq__57876 = G__57973;
chunk__57877 = G__57974;
count__57878 = G__57975;
i__57879 = G__57976;
continue;
}
} else {
return null;
}
}
break;
}
}));
re_frame.fx.reg_fx(new cljs.core.Keyword(null,"dispatch","dispatch",1319337009),(function (value){
if((!(cljs.core.vector_QMARK_(value)))){
return re_frame.loggers.console.cljs$core$IFn$_invoke$arity$variadic(new cljs.core.Keyword(null,"error","error",-978969032),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["re-frame: ignoring bad :dispatch value. Expected a vector, but got:",value], 0));
} else {
return re_frame.router.dispatch(value);
}
}));
re_frame.fx.reg_fx(new cljs.core.Keyword(null,"dispatch-n","dispatch-n",-504469236),(function (value){
if((!(cljs.core.sequential_QMARK_(value)))){
return re_frame.loggers.console.cljs$core$IFn$_invoke$arity$variadic(new cljs.core.Keyword(null,"error","error",-978969032),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["re-frame: ignoring bad :dispatch-n value. Expected a collection, but got:",value], 0));
} else {
var seq__57895 = cljs.core.seq(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(cljs.core.nil_QMARK_,value));
var chunk__57896 = null;
var count__57897 = (0);
var i__57898 = (0);
while(true){
if((i__57898 < count__57897)){
var event = chunk__57896.cljs$core$IIndexed$_nth$arity$2(null,i__57898);
re_frame.router.dispatch(event);


var G__57977 = seq__57895;
var G__57978 = chunk__57896;
var G__57979 = count__57897;
var G__57980 = (i__57898 + (1));
seq__57895 = G__57977;
chunk__57896 = G__57978;
count__57897 = G__57979;
i__57898 = G__57980;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__57895);
if(temp__5735__auto__){
var seq__57895__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__57895__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__57895__$1);
var G__57981 = cljs.core.chunk_rest(seq__57895__$1);
var G__57982 = c__4550__auto__;
var G__57983 = cljs.core.count(c__4550__auto__);
var G__57984 = (0);
seq__57895 = G__57981;
chunk__57896 = G__57982;
count__57897 = G__57983;
i__57898 = G__57984;
continue;
} else {
var event = cljs.core.first(seq__57895__$1);
re_frame.router.dispatch(event);


var G__57985 = cljs.core.next(seq__57895__$1);
var G__57986 = null;
var G__57987 = (0);
var G__57988 = (0);
seq__57895 = G__57985;
chunk__57896 = G__57986;
count__57897 = G__57987;
i__57898 = G__57988;
continue;
}
} else {
return null;
}
}
break;
}
}
}));
re_frame.fx.reg_fx(new cljs.core.Keyword(null,"deregister-event-handler","deregister-event-handler",-1096518994),(function (value){
var clear_event = cljs.core.partial.cljs$core$IFn$_invoke$arity$2(re_frame.registrar.clear_handlers,re_frame.events.kind);
if(cljs.core.sequential_QMARK_(value)){
var seq__57902 = cljs.core.seq(value);
var chunk__57903 = null;
var count__57904 = (0);
var i__57905 = (0);
while(true){
if((i__57905 < count__57904)){
var event = chunk__57903.cljs$core$IIndexed$_nth$arity$2(null,i__57905);
(clear_event.cljs$core$IFn$_invoke$arity$1 ? clear_event.cljs$core$IFn$_invoke$arity$1(event) : clear_event.call(null,event));


var G__57991 = seq__57902;
var G__57992 = chunk__57903;
var G__57993 = count__57904;
var G__57994 = (i__57905 + (1));
seq__57902 = G__57991;
chunk__57903 = G__57992;
count__57904 = G__57993;
i__57905 = G__57994;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__57902);
if(temp__5735__auto__){
var seq__57902__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__57902__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__57902__$1);
var G__57996 = cljs.core.chunk_rest(seq__57902__$1);
var G__57997 = c__4550__auto__;
var G__57998 = cljs.core.count(c__4550__auto__);
var G__57999 = (0);
seq__57902 = G__57996;
chunk__57903 = G__57997;
count__57904 = G__57998;
i__57905 = G__57999;
continue;
} else {
var event = cljs.core.first(seq__57902__$1);
(clear_event.cljs$core$IFn$_invoke$arity$1 ? clear_event.cljs$core$IFn$_invoke$arity$1(event) : clear_event.call(null,event));


var G__58000 = cljs.core.next(seq__57902__$1);
var G__58001 = null;
var G__58002 = (0);
var G__58003 = (0);
seq__57902 = G__58000;
chunk__57903 = G__58001;
count__57904 = G__58002;
i__57905 = G__58003;
continue;
}
} else {
return null;
}
}
break;
}
} else {
return (clear_event.cljs$core$IFn$_invoke$arity$1 ? clear_event.cljs$core$IFn$_invoke$arity$1(value) : clear_event.call(null,value));
}
}));
re_frame.fx.reg_fx(new cljs.core.Keyword(null,"db","db",993250759),(function (value){
if((!((cljs.core.deref(re_frame.db.app_db) === value)))){
return cljs.core.reset_BANG_(re_frame.db.app_db,value);
} else {
return null;
}
}));

//# sourceMappingURL=re_frame.fx.js.map
