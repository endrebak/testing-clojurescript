goog.provide('shadow.resource');
goog.require('cljs.core');

//# sourceMappingURL=shadow.resource.js.map
