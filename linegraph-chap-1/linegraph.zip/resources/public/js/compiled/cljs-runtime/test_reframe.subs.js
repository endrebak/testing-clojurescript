goog.provide('test_reframe.subs');
goog.require('cljs.core');
goog.require('re_frame.core');
var G__46111_46120 = new cljs.core.Keyword("test-reframe.subs","name","test-reframe.subs/name",-1627046385);
var G__46112_46121 = ((function (G__46111_46120){
return (function (db){
return new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(db);
});})(G__46111_46120))
;
(re_frame.core.reg_sub.cljs$core$IFn$_invoke$arity$2 ? re_frame.core.reg_sub.cljs$core$IFn$_invoke$arity$2(G__46111_46120,G__46112_46121) : re_frame.core.reg_sub.call(null,G__46111_46120,G__46112_46121));
var G__46113_46122 = new cljs.core.Keyword("test-reframe.subs","click","test-reframe.subs/click",924477855);
var G__46114_46123 = ((function (G__46113_46122){
return (function (db){
return new cljs.core.Keyword(null,"click","click",1912301393).cljs$core$IFn$_invoke$arity$1(db);
});})(G__46113_46122))
;
(re_frame.core.reg_sub.cljs$core$IFn$_invoke$arity$2 ? re_frame.core.reg_sub.cljs$core$IFn$_invoke$arity$2(G__46113_46122,G__46114_46123) : re_frame.core.reg_sub.call(null,G__46113_46122,G__46114_46123));
var G__46118_46124 = new cljs.core.Keyword("test-reframe.subs","data","test-reframe.subs/data",1191230813);
var G__46119_46125 = ((function (G__46118_46124){
return (function (db){
return new cljs.core.Keyword(null,"data","data",-232669377).cljs$core$IFn$_invoke$arity$1(db);
});})(G__46118_46124))
;
(re_frame.core.reg_sub.cljs$core$IFn$_invoke$arity$2 ? re_frame.core.reg_sub.cljs$core$IFn$_invoke$arity$2(G__46118_46124,G__46119_46125) : re_frame.core.reg_sub.call(null,G__46118_46124,G__46119_46125));

//# sourceMappingURL=test_reframe.subs.js.map
