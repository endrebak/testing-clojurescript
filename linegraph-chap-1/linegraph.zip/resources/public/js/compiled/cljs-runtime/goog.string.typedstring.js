goog.provide("goog.string.TypedString");
/** @interface */ goog.string.TypedString = function() {
};
/** @type {boolean} */ goog.string.TypedString.prototype.implementsGoogStringTypedString;
/**
 * @return {string}
 */
goog.string.TypedString.prototype.getTypedStringValue;

//# sourceMappingURL=goog.string.typedstring.js.map
