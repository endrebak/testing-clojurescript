goog.provide('test_reframe.d3');
goog.require('cljs.core');
goog.require('cljs.test');
var module$node_modules$d3$dist$d3_node=shadow.js.require("module$node_modules$d3$dist$d3_node", {});
goog.require('test_reframe.db');
goog.require('reagent.core');
test_reframe.d3.window_width = (window.innerWidth * 0.9);
test_reframe.d3.margins = new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"top","top",-1856271961),(15),new cljs.core.Keyword(null,"right","right",-452581833),(15),new cljs.core.Keyword(null,"bottom","bottom",-1550509018),(40),new cljs.core.Keyword(null,"left","left",-399115937),(60)], null);
test_reframe.d3.dimensions = new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"width","width",-384071477),test_reframe.d3.window_width,new cljs.core.Keyword(null,"height","height",1025178622),(400),new cljs.core.Keyword(null,"bounded-width","bounded-width",-381986820),((test_reframe.d3.window_width - (function (){var G__50902 = new cljs.core.Keyword(null,"left","left",-399115937);
return (test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1(G__50902) : test_reframe.d3.margins.call(null,G__50902));
})()) - (function (){var G__50903 = new cljs.core.Keyword(null,"right","right",-452581833);
return (test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1(G__50903) : test_reframe.d3.margins.call(null,G__50903));
})()),new cljs.core.Keyword(null,"bounded-height","bounded-height",-373822791),(((400) - (function (){var G__50904 = new cljs.core.Keyword(null,"top","top",-1856271961);
return (test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1(G__50904) : test_reframe.d3.margins.call(null,G__50904));
})()) - (function (){var G__50905 = new cljs.core.Keyword(null,"bottom","bottom",-1550509018);
return (test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1(G__50905) : test_reframe.d3.margins.call(null,G__50905));
})())], null);
test_reframe.d3.date_parser = module$node_modules$d3$dist$d3_node.timeParse("%Y-%m-%d");
test_reframe.d3.y_accessor = (function test_reframe$d3$y_accessor(d){
return d.temperatureMax;
});
test_reframe.d3.x_accessor = (function test_reframe$d3$x_accessor(d){
var G__50906 = d.date;
return (test_reframe.d3.date_parser.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.date_parser.cljs$core$IFn$_invoke$arity$1(G__50906) : test_reframe.d3.date_parser.call(null,G__50906));
});
test_reframe.d3.y_scale = module$node_modules$d3$dist$d3_node.scaleLinear().domain(module$node_modules$d3$dist$d3_node.extent(test_reframe.db.app_state,test_reframe.d3.y_accessor)).range([(function (){var G__50907 = new cljs.core.Keyword(null,"bounded-height","bounded-height",-373822791);
return (test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1(G__50907) : test_reframe.d3.dimensions.call(null,G__50907));
})(),(0)]);
test_reframe.d3.x_scale = module$node_modules$d3$dist$d3_node.scaleTime().domain(module$node_modules$d3$dist$d3_node.extent(test_reframe.db.app_state,test_reframe.d3.x_accessor)).range([(0),(function (){var G__50908 = new cljs.core.Keyword(null,"bounded-width","bounded-width",-381986820);
return (test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1(G__50908) : test_reframe.d3.dimensions.call(null,G__50908));
})()]);
test_reframe.d3.line_generator = module$node_modules$d3$dist$d3_node.line().x((function (p1__50909_SHARP_){
var G__50911 = test_reframe.d3.x_accessor(p1__50909_SHARP_);
return (test_reframe.d3.x_scale.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.x_scale.cljs$core$IFn$_invoke$arity$1(G__50911) : test_reframe.d3.x_scale.call(null,G__50911));
})).y((function (p1__50910_SHARP_){
var G__50912 = test_reframe.d3.y_accessor(p1__50910_SHARP_);
return (test_reframe.d3.y_scale.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.y_scale.cljs$core$IFn$_invoke$arity$1(G__50912) : test_reframe.d3.y_scale.call(null,G__50912));
}));
test_reframe.d3.y_axis_generator = module$node_modules$d3$dist$d3_node.axisLeft().scale(test_reframe.d3.y_scale);
test_reframe.d3.x_axis_generator = module$node_modules$d3$dist$d3_node.axisBottom().scale(test_reframe.d3.x_scale);
test_reframe.d3.wrapper = (function test_reframe$d3$wrapper(){
return module$node_modules$d3$dist$d3_node.select("#wrapper").append("svg").attr("width",(function (){var G__50913 = new cljs.core.Keyword(null,"width","width",-384071477);
return (test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1(G__50913) : test_reframe.d3.dimensions.call(null,G__50913));
})()).attr("height",(function (){var G__50914 = new cljs.core.Keyword(null,"height","height",1025178622);
return (test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1(G__50914) : test_reframe.d3.dimensions.call(null,G__50914));
})());
});
test_reframe.d3.bounds = (function test_reframe$d3$bounds(wrapper){
return wrapper.append("g").style("transform",["translate(",cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var G__50917 = new cljs.core.Keyword(null,"left","left",-399115937);
return (test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1(G__50917) : test_reframe.d3.margins.call(null,G__50917));
})()),"px, ",cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var G__50918 = new cljs.core.Keyword(null,"top","top",-1856271961);
return (test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.margins.cljs$core$IFn$_invoke$arity$1(G__50918) : test_reframe.d3.margins.call(null,G__50918));
})()),"px)"].join(''));
});
test_reframe.d3.x_axis = (function test_reframe$d3$x_axis(bounds){
console.log(["translateY(",cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var G__50920 = new cljs.core.Keyword(null,"bounded-height","bounded-height",-373822791);
return (test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1(G__50920) : test_reframe.d3.dimensions.call(null,G__50920));
})()),"px)"].join(''));

return bounds.append("g").call(test_reframe.d3.x_axis_generator).style("transform",["translateY(",cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var G__50922 = new cljs.core.Keyword(null,"bounded-height","bounded-height",-373822791);
return (test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.dimensions.cljs$core$IFn$_invoke$arity$1(G__50922) : test_reframe.d3.dimensions.call(null,G__50922));
})()),"px)"].join(''));
});
test_reframe.d3.y_axis = (function test_reframe$d3$y_axis(bounds){
return bounds.append("g").call(test_reframe.d3.y_axis_generator);
});
test_reframe.d3.graph = (function test_reframe$d3$graph(bounds){
return bounds.append("path").attr("d",(test_reframe.d3.line_generator.cljs$core$IFn$_invoke$arity$1 ? test_reframe.d3.line_generator.cljs$core$IFn$_invoke$arity$1(test_reframe.db.app_state) : test_reframe.d3.line_generator.call(null,test_reframe.db.app_state))).attr("fill","none").attr("stroke","#af9358").attr("stroke-width",(2));
});
test_reframe.d3.d3_inner = (function test_reframe$d3$d3_inner(data){
return reagent.core.create_class(new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"reagent-render","reagent-render",-985383853),(function (data__$1){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div#wrapper","div#wrapper",220024300)], null);
}),new cljs.core.Keyword(null,"component-did-mount","component-did-mount",-1126910518),(function (data__$1){
var wrapper_50935 = test_reframe.d3.wrapper();
var bounds_50936 = test_reframe.d3.bounds(wrapper_50935);
var graph_50937 = test_reframe.d3.graph(bounds_50936);
var __50938 = test_reframe.d3.x_axis(bounds_50936);
var __50939__$1 = test_reframe.d3.y_axis(bounds_50936);

return test_reframe.d3.graph;
}),new cljs.core.Keyword(null,"component-did-update","component-did-update",-1468549173),(function (this$){
var vec__50923 = reagent.core.argv(this$);
var _ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__50923,(0),null);
var data__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__50923,(1),null);
var d3data = cljs.core.clj__GT_js(data__$1);
console.log("Update");

return module$node_modules$d3$dist$d3_node.selectAll("circle").data(d3data);
})], null));
});

//# sourceMappingURL=test_reframe.d3.js.map
