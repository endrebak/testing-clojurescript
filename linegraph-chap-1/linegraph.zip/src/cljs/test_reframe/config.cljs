(ns test-reframe.config)

(def debug?
  ^boolean goog.DEBUG)
